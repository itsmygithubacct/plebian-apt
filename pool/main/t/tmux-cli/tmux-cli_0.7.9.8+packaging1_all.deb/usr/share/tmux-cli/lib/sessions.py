"""Thin wrapper around ``tmux`` for session enumeration, lifecycle, and I/O.

Exposes high-level helpers for the dashboard server AND the ``tb`` CLI. The
older positional-return helpers (``exists``, ``new``, ``kill``, …) retain
their signatures because they're called by ``lib/server.py``; richer
variants sit alongside with clearer return shapes.
"""

from __future__ import annotations

import os
import secrets
import subprocess
import time
from typing import TypedDict

from .errors import UsageError
from .targeting import Target


# -----------------------------------------------------------------------------
# Data types
# -----------------------------------------------------------------------------

class Session(TypedDict):
    name: str
    windows: int
    attached: int
    created: int  # epoch seconds
    activity: int  # epoch seconds — last activity


class PaneInfo(TypedDict, total=False):
    session: str
    window: str     # window index
    window_name: str
    pane: str       # pane index
    pane_id: str    # stable tmux pane id (for example, "%3")
    command: str    # #{pane_current_command}
    pid: int
    cwd: str
    width: int
    height: int
    active: bool


_SESSION_FORMAT = (
    "#{session_name}\t#{session_windows}\t#{session_attached}"
    "\t#{session_created}\t#{session_activity}\t#{session_group}"
)
_PANE_FORMAT = (
    "#{session_name}\t#{window_index}\t#{window_name}\t#{pane_index}"
    "\t#{pane_id}\t#{pane_current_command}\t#{pane_pid}\t#{pane_current_path}"
    "\t#{pane_width}\t#{pane_height}\t#{?pane_active,1,0}"
)


# -----------------------------------------------------------------------------
# Server + session listing
# -----------------------------------------------------------------------------

def server_running() -> bool:
    """True iff a tmux server socket is reachable.

    ``tmux list-sessions`` exits 1 for *both* "no server socket" and "server
    up, zero sessions" — tmux conflates them because the server exits when
    the last session dies. We distinguish by looking at stderr: only the
    no-server case prints the ``no server running`` banner.
    """
    try:
        r = subprocess.run(
            ["tmux", "list-sessions"],
            capture_output=True, text=True, timeout=5,
        )
    except FileNotFoundError:
        return False
    except subprocess.TimeoutExpired:
        # Server socket exists but the process isn't responding (memory
        # pressure, stuck client). From the dashboard's perspective the
        # right answer is "no usable server" — same as "not running".
        return False
    if r.returncode == 0:
        return True
    stderr = (r.stderr or "").lower()
    # tmux reports a missing/unreachable server several ways depending on
    # whether the socket file is merely absent or a stale dead socket:
    #   "no server running on /tmp/tmux-1000/default"        (server exited)
    #   "error connecting to /tmp/.../default (No such file…)" (never started)
    #   "failed to connect to server"                         (older tmux)
    # Any of these means "no usable server". A non-zero exit with none of them
    # (e.g. "no sessions") means the server is up but empty.
    no_server_markers = ("no server", "error connecting",
                          "no such file", "failed to connect")
    return not any(marker in stderr for marker in no_server_markers)


def server_responsive(timeout: float = 2.0) -> bool:
    """Cheap liveness probe — ``tmux display-message`` with a short timeout.

    Distinguishes "tmux is up and answering" from "socket exists but the
    server isn't responding". Used by the dashboard to surface a banner
    when a memory-pressured server has gone unresponsive but the socket
    file is still on disk.
    """
    try:
        r = subprocess.run(
            ["tmux", "display-message", "-p", "ok"],
            capture_output=True, text=True, timeout=timeout,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
    return r.returncode == 0


def list_sessions() -> list[Session]:
    try:
        r = subprocess.run(
            ["tmux", "list-sessions", "-F", _SESSION_FORMAT],
            capture_output=True, text=True, timeout=5,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        # Treat a hung tmux server like an absent one. Memory-pressured
        # boxes can leave the server unresponsive for tens of seconds;
        # raising would take down /api/sessions and blank the dashboard.
        return []
    if r.returncode != 0:
        return []
    # ttyd_wrap.sh creates a per-viewer grouped session (same session group,
    # different name) so each browser tab can size its own windows. Those
    # viewer sessions shouldn't appear in the dashboard or CLI listing as
    # if they were separate work — collapse each session group to just its
    # primary (the entry whose name equals the group name). Viewer-only
    # groups (primary already dead but a viewer is hanging on because a
    # browser tab is still attached) are dropped from the listing entirely
    # so they stop polluting the session list under their `<base>-v<pid>-<rand>`
    # name; ttyd_wrap.sh also actively kills those viewers when the base
    # disappears, so this is a defensive filter for transient cases.
    raw: list[tuple[Session, str]] = []  # (row, group)
    for line in r.stdout.splitlines():
        parts = line.split("\t")
        if len(parts) != 6:
            continue
        name, windows, attached, created, activity, group = parts
        try:
            windows_i = int(windows)
            attached_i = int(attached)
            created_i = int(created)
            activity_i = int(activity)
        except ValueError:
            # A plugin format, older tmux build, or transient malformed row
            # must not take down the complete session snapshot.  Treat it the
            # same way as a row with the wrong field count and retain every
            # independently parseable session.
            continue
        raw.append((
            {
                "name": name,
                "windows": windows_i,
                "attached": attached_i,
                "created": created_i,
                "activity": activity_i,
            },
            group,
        ))
    out: list[Session] = []
    for row, group in raw:
        if not group:
            out.append(row)
        elif row["name"] == group:
            # Primary session keeps its spot. Viewers are dropped below.
            out.append(row)
    out.sort(key=lambda s: s["name"])
    return out


def list_panes() -> list[PaneInfo]:
    """All panes across all sessions — one row per pane."""
    try:
        r = subprocess.run(
            ["tmux", "list-panes", "-a", "-F", _PANE_FORMAT],
            capture_output=True, text=True, timeout=5,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []
    if r.returncode != 0:
        return []
    out: list[PaneInfo] = []
    for line in r.stdout.splitlines():
        parts = line.split("\t")
        if len(parts) != 11:
            continue
        sess, wi, wn, pi, pane_id, cmd, pid, cwd, w, h, active = parts
        try:
            pid_i = int(pid)
            width_i = int(w)
            height_i = int(h)
        except ValueError:
            # Preserve the rest of a multi-pane snapshot when one row is
            # malformed instead of surfacing an unexpected CLI exception.
            continue
        if active not in {"0", "1"}:
            continue
        out.append({
            "session": sess,
            "window": wi,
            "window_name": wn,
            "pane": pi,
            "pane_id": pane_id,
            "command": cmd,
            "pid": pid_i,
            "cwd": cwd,
            "width": width_i,
            "height": height_i,
            "active": active == "1",
        })
    return out


def exists(session: str) -> bool:
    try:
        r = subprocess.run(
            ["tmux", "has-session", "-t", f"={session}"],
            capture_output=True, timeout=5,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
    return r.returncode == 0


# -----------------------------------------------------------------------------
# Lifecycle
# -----------------------------------------------------------------------------

def _validate_name(name: str) -> None:
    if not name or any(c in name for c in " \t\n:."):
        raise UsageError(
            "session name must be non-empty and contain no whitespace, ':' or '.'",
        )
    # A leading '-' would be parsed as an option by tmux in the positional
    # ``new-session -s NAME`` / ``rename-session NEW`` slots; a leading '='
    # collides with the exact-match prefix that targeting uses (``=name``),
    # making the session unaddressable. Reject both.
    if name[0] in "-=":
        raise UsageError("session name must not start with '-' or '='")


def kill(session: str) -> tuple[bool, str]:
    try:
        r = subprocess.run(
            ["tmux", "kill-session", "-t", f"={session}"],
            capture_output=True, text=True, timeout=5,
        )
    except FileNotFoundError:
        return False, "tmux not found"
    except subprocess.TimeoutExpired:
        return False, "tmux timed out"
    if r.returncode == 0:
        try:
            from . import session_logs
            # Closing tmux sends EOF to every per-pane writer, which finalizes
            # its zstd archive. Only the disposable idle tail and wiring marker
            # are removed here; permanent capture data is never reaped.
            session_logs.discard_runtime(session)
        except Exception:
            pass
        return True, ""
    return False, (r.stderr or r.stdout).strip()


def new_session(name: str, cwd: str | None = None, cmd: str | None = None,
                width: int = 200, height: int = 50,
                enable_logging: bool = True) -> tuple[bool, str]:
    """Create a detached tmux session. The single canonical create path."""
    try:
        _validate_name(name)
    except UsageError as e:
        return False, str(e)
    if exists(name):
        return False, f"session '{name}' already exists"
    args = ["tmux", "new-session", "-d", "-s", name,
            "-x", str(width), "-y", str(height)]
    if cwd:
        args += ["-c", cwd]
    if cmd:
        args.append(cmd)
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=10)
    except FileNotFoundError:
        return False, "tmux not found"
    except subprocess.TimeoutExpired:
        return False, "tmux timed out"
    if r.returncode == 0:
        if enable_logging:
            try:
                from . import session_logs
                session_logs.ensure_logging(name)
            except Exception:
                pass
        return True, ""
    return False, (r.stderr or r.stdout).strip()


def rename(old: str, new_name: str) -> tuple[bool, str]:
    _validate_name(new_name)
    if not exists(old):
        return False, f"no such session: {old}"
    if exists(new_name):
        return False, f"session '{new_name}' already exists"
    try:
        r = subprocess.run(
            ["tmux", "rename-session", "-t", f"={old}", new_name],
            capture_output=True, text=True, timeout=5,
        )
    except FileNotFoundError:
        return False, "tmux not found"
    except subprocess.TimeoutExpired:
        return False, "tmux timed out"
    if r.returncode == 0:
        try:
            from . import session_logs
            # A renamed pane keeps its existing pipe command. Replace it with
            # a new per-pane capture. Replacement closes and finalizes the old
            # writer, creating an explicit history boundary at the rename.
            session_logs.discard_runtime(new_name)
            session_logs.ensure_logging(new_name)
            session_logs.discard_runtime(old)
        except Exception:
            # Session lifecycle remains authoritative; the dashboard's
            # periodic ensure/recovery pass will retry logging setup.
            pass
        return True, ""
    return False, (r.stderr or r.stdout).strip()


def select_target(target: Target) -> tuple[bool, str]:
    """Select a target window/pane before an interactive attach.

    ``tmux attach-session -t`` accepts a target *session*, so passing a
    ``session:window.pane`` expression directly does not provide a portable
    exact-pane attach. Keep attach itself session-scoped and select the
    requested window or pane first.
    """
    if not exists(target.session):
        return False, f"no such session: {target.session}"
    if target.window is None:
        return True, ""
    if target.pane is None:
        argv = ["tmux", "select-window", "-t", target.as_tmux_target()]
    else:
        argv = ["tmux", "select-pane", "-t", target.as_tmux_target()]
    try:
        result = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            timeout=5,
        )
    except FileNotFoundError:
        return False, "tmux not found"
    except subprocess.TimeoutExpired:
        return False, "tmux timed out"
    if result.returncode == 0:
        return True, ""
    return False, (result.stderr or result.stdout).strip()


# -----------------------------------------------------------------------------
# Capture / read
# -----------------------------------------------------------------------------

def capture_target(target: Target, lines: int = 2000,
                   ansi: bool = False) -> tuple[bool, str]:
    """Single canonical capture. Accepts a Target; works for any pane.

    The exact-target ``capture-pane`` call is itself a complete existence
    check. Avoiding a preceding ``has-session`` halves the subprocess traffic
    for polling and tailing clients while retaining tmux's precise error when
    a session or pane disappears between snapshots.
    """
    cmd = ["tmux", "capture-pane", "-t", target.as_tmux_target(),
           "-p", "-J", "-S", f"-{lines}"]
    if ansi:
        cmd.append("-e")
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
    except FileNotFoundError:
        return False, "tmux not found"
    except subprocess.TimeoutExpired:
        return False, "tmux timed out"
    if r.returncode != 0:
        return False, (r.stderr or r.stdout).strip()
    # ``-S -N`` moves the start N lines into history, but capture-pane's end
    # is always the bottom of the visible viewport: a sparse pane pads the
    # result with the blank rows below its cursor, and the viewport rides on
    # top of the N requested lines (so ``-n 8`` could print a full screen).
    # Trim the artifact blanks, then honor ``lines`` exactly.
    kept = r.stdout.split("\n")
    while kept and kept[-1].strip() == "":
        kept.pop()
    if lines > 0:
        kept = kept[-lines:]
    return True, "\n".join(kept) + "\n" if kept else ""


def session_activity(target: Target) -> int | None:
    try:
        r = subprocess.run(
            ["tmux", "display-message", "-p", "-t", target.as_tmux_target(),
             "#{session_activity}"],
            capture_output=True, text=True, timeout=5,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None
    if r.returncode != 0:
        return None
    try:
        return int(r.stdout.strip())
    except ValueError:
        return None


def pane_current_command(target: Target) -> str | None:
    try:
        r = subprocess.run(
            ["tmux", "display-message", "-p", "-t", target.as_tmux_target(),
             "#{pane_current_command}"],
            capture_output=True, text=True, timeout=5,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None
    if r.returncode != 0:
        return None
    return r.stdout.strip() or None


# -----------------------------------------------------------------------------
# Write: send-keys family
# -----------------------------------------------------------------------------

def enter_copy_mode(session: str) -> tuple[bool, str]:
    """Invoke the ``C-b [`` binding (put active pane into copy-mode)."""
    if not exists(session):
        return False, f"no such session: {session}"
    try:
        r = subprocess.run(
            ["tmux", "copy-mode", "-t", f"{session}:"],
            capture_output=True, text=True, timeout=5,
        )
    except FileNotFoundError:
        return False, "tmux not found"
    except subprocess.TimeoutExpired:
        return False, "tmux timed out"
    if r.returncode != 0:
        return False, (r.stderr or r.stdout).strip()
    return True, ""


def zoom_pane(session: str) -> tuple[bool, str]:
    """Toggle zoom on the active pane (``C-b z`` / ``resize-pane -Z``).

    tmux's pane-zoom feature makes the current pane fill its window; a
    second invocation restores the layout.
    """
    if not exists(session):
        return False, f"no such session: {session}"
    try:
        r = subprocess.run(
            ["tmux", "resize-pane", "-t", f"{session}:", "-Z"],
            capture_output=True, text=True, timeout=5,
        )
    except FileNotFoundError:
        return False, "tmux not found"
    except subprocess.TimeoutExpired:
        return False, "tmux timed out"
    if r.returncode != 0:
        return False, (r.stderr or r.stdout).strip()
    return True, ""


def send_literal(target: Target, text: str) -> tuple[bool, str]:
    """Send ``text`` verbatim. Newlines in ``text`` become literal newlines."""
    if not exists(target.session):
        return False, f"no such session: {target.session}"
    try:
        r = subprocess.run(
            ["tmux", "send-keys", "-t", target.as_tmux_target(), "-l", "--", text],
            capture_output=True, text=True, timeout=10,
        )
    except FileNotFoundError:
        return False, "tmux not found"
    except subprocess.TimeoutExpired:
        return False, "tmux timed out"
    if r.returncode != 0:
        return False, (r.stderr or r.stdout).strip()
    return True, ""


def send_keys(target: Target, *keys: str) -> tuple[bool, str]:
    """Send one or more tmux key names (e.g. ``Enter``, ``C-c``, ``F5``)."""
    if not exists(target.session):
        return False, f"no such session: {target.session}"
    try:
        r = subprocess.run(
            ["tmux", "send-keys", "-t", target.as_tmux_target(), *keys],
            capture_output=True, text=True, timeout=10,
        )
    except FileNotFoundError:
        return False, "tmux not found"
    except subprocess.TimeoutExpired:
        return False, "tmux timed out"
    if r.returncode != 0:
        return False, (r.stderr or r.stdout).strip()
    return True, ""


def type_line(target: Target, text: str) -> tuple[bool, str]:
    """Send ``text`` literally then press Enter."""
    ok, err = send_literal(target, text)
    if not ok:
        return ok, err
    return send_keys(target, "Enter")


def paste_buffer(target: Target, text: str) -> tuple[bool, str]:
    """Use load-buffer + paste-buffer for pasting arbitrary text (survives
    shell auto-indent / bracketed-paste hooks better than send-keys -l)."""
    if not exists(target.session):
        return False, f"no such session: {target.session}"
    # Use a private buffer name so concurrent ``tb paste`` calls cannot race
    # over tmux's global "most recent buffer" and paste each other's payload.
    buffer_name = f"tb-{os.getpid()}-{secrets.token_hex(8)}"

    def cleanup_buffer() -> None:
        try:
            subprocess.run(
                ["tmux", "delete-buffer", "-b", buffer_name],
                capture_output=True, text=True, timeout=5,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

    try:
        r = subprocess.run(
            ["tmux", "load-buffer", "-b", buffer_name, "-"],
            input=text, capture_output=True, text=True, timeout=10,
        )
    except FileNotFoundError:
        return False, "tmux not found"
    except subprocess.TimeoutExpired:
        return False, "tmux timed out"
    if r.returncode != 0:
        return False, (r.stderr or r.stdout).strip()
    try:
        r = subprocess.run(
            ["tmux", "paste-buffer", "-d", "-b", buffer_name,
             "-t", target.as_tmux_target()],
            capture_output=True, text=True, timeout=10,
        )
    except FileNotFoundError:
        cleanup_buffer()
        return False, "tmux not found"
    except subprocess.TimeoutExpired:
        cleanup_buffer()
        return False, "tmux timed out"
    if r.returncode != 0:
        cleanup_buffer()
        return False, (r.stderr or r.stdout).strip()
    return True, ""


# -----------------------------------------------------------------------------
# Wait / observe
# -----------------------------------------------------------------------------

def wait_idle(target: Target, idle_sec: float,
              timeout_sec: float = 0) -> tuple[bool, str]:
    """Block until pane has been quiet for ``idle_sec`` seconds.

    Quiet = no change in the captured pane content (the ``session_activity``
    timer alone skips output that tmux doesn't mark as activity).
    ``timeout_sec`` of 0 means no timeout.
    """
    if not exists(target.session):
        return False, f"no such session: {target.session}"

    deadline = time.monotonic() + timeout_sec if timeout_sec > 0 else None
    # Compare captured content directly rather than its ``hash()``: hash()
    # carries a (tiny) collision risk that would falsely read "quiet", and a
    # 200-line capture is cheap to hold. ``None`` sentinel forces the first
    # observation to count as a change.
    last_content = None
    last_change = time.monotonic()
    poll = 0.2
    while True:
        ok, content = capture_target(target, lines=200)
        if not ok:
            return False, content
        now = time.monotonic()
        if content != last_content:
            last_content = content
            last_change = now
        if now - last_change >= idle_sec:
            return True, ""
        if deadline and now >= deadline:
            return False, f"timed out after {timeout_sec}s"
        time.sleep(poll)




# ---------------------------------------------------------------------------
# Pane snapshots (for the dashboard preview tiles)
# ---------------------------------------------------------------------------
#
# Cheap "what's on this pane right now" capture for the index page.
# Trades freshness for cost: ``capture-pane`` per session per request
# would dominate the response time on hosts with many sessions, so
# results are cached for ``_SNAPSHOT_TTL_SEC`` and served stale
# before the cap. The 200 ms per-request budget limits worst-case
# damage when many sessions are stale at once.
#
# Why ``-e`` (ANSI preserved) but no ``-J`` (no joining wrapped lines):
# the dashboard renders a small monospace tile and we want what the
# user actually sees, not a reflowed canonical form. The tile is
# narrow enough that a hard wrap-at-N looks better than the joined
# alternative.

_SNAPSHOT_TTL_SEC = 10
_snapshot_cache: dict[str, tuple[int, str]] = {}


def capture_pane_snapshot(name: str, lines: int = 20) -> str:
    """Best-effort scrollback dump for the dashboard preview.

    Returns the raw ANSI-bearing text (last ``lines`` rows). Empty
    string on any failure — never raises into request flow."""
    try:
        r = subprocess.run(
            ["tmux", "capture-pane", "-e", "-p",
             "-t", name, "-S", f"-{lines}"],
            capture_output=True, text=True, timeout=2,
        )
        return r.stdout if r.returncode == 0 else ""
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return ""


def get_cached_snapshot(name: str, now: int | None = None,
                        lines: int = 20) -> str:
    """Cached accessor — re-captures only if entry is older than TTL."""
    now = now if now is not None else int(time.time())
    cached = _snapshot_cache.get(name)
    if cached and (now - cached[0]) < _SNAPSHOT_TTL_SEC:
        return cached[1]
    text = capture_pane_snapshot(name, lines=lines)
    _snapshot_cache[name] = (now, text)
    return text


def gc_snapshots(active_names: set[str]) -> None:
    """Drop cache entries for sessions that no longer exist."""
    for stale in [n for n in _snapshot_cache if n not in active_names]:
        _snapshot_cache.pop(stale, None)
