#!/usr/bin/env bash
# lib/update.sh — update the kilix checkout to the latest from upstream, rebuild
# the fork if it changed, and restart only when an active kiosk opts in.
# Sourced by `pleb`. KILIX_DIR/KILIX_BRANCH come from common.sh.

# shellcheck source=/dev/null
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/preserve.sh"
# shellcheck source=/dev/null
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/closure.sh"

_UPDATE_LOCK_FD=""
_UPDATE_LOCK_DIR=""
_UPDATE_LOCK_BORROWED=0
_UPDATE_TXN_DIR=""
_UPDATE_TXN_ACTIVE=0
_UPDATE_TXN_COMMITTED=0
_KILIX_TXN_LOCK_FD=""
_KILIX_TXN_LOCK_BORROWED=0
_PLEB_SELF_INITIAL_PRESERVE=""
declare -a _PLEB_SELF_PRESERVATIONS=()
_PLEB_SELF_MOVE_ACTIVE=0
_PLEB_SELF_BEFORE=""
_PLEB_SELF_BRANCH=""

_require_managed_source_layout() {
    # Every checkout this run may move must be a real directory, not a symlink
    # into a development tree.
    local dir name target
    for dir in "$PLEB_ROOT" "${PLEB_DIR:-}" "$KILIX_DIR" "$KILIX95_DIR"; do
        [ -n "$dir" ] || continue
        [[ "$dir" != *$'\n'* && "$dir" != *$'\r'* ]] \
            || die "refusing participating checkout path with a line break"
        _pleb_assert_no_symlink_components "$dir"
    done
    for name in pleb kilix kilix-desktops/kilix-95; do
        [ -L "$GPU_TERMINAL_SOURCE_HOME/$name" ] || continue
        target="$(realpath -m -- "$GPU_TERMINAL_SOURCE_HOME/$name")" \
            || die "could not resolve managed source entry: $GPU_TERMINAL_SOURCE_HOME/$name"
        for dir in "$PLEB_ROOT" "${PLEB_DIR:-}" "$KILIX_DIR" "$KILIX95_DIR"; do
            [ -n "$dir" ] && [ -d "$dir" ] || continue
            case "$(cd "$dir" && pwd -P)" in
                "$target"|"$target"/*)
                    die "refusing to update $dir: $GPU_TERMINAL_SOURCE_HOME/$name is a symlink into it" ;;
            esac
        done
    done
}

_release_kilix_transaction_lock() {
    if [ -n "${_KILIX_TXN_LOCK_FD:-}" ]; then
        if [ "${_KILIX_TXN_LOCK_BORROWED:-0}" != 1 ]; then
            flock -u "$_KILIX_TXN_LOCK_FD" 2>/dev/null || true
            exec {_KILIX_TXN_LOCK_FD}>&-
        fi
        _KILIX_TXN_LOCK_FD=""
        _KILIX_TXN_LOCK_BORROWED=0
    fi
}

_release_update_lock() {
    _release_kilix_transaction_lock
    if [ -n "${_UPDATE_LOCK_FD:-}" ]; then
        if [ "${_UPDATE_LOCK_BORROWED:-0}" != 1 ]; then
            flock -u "$_UPDATE_LOCK_FD" 2>/dev/null || true
            exec {_UPDATE_LOCK_FD}>&-
        fi
        _UPDATE_LOCK_FD=""
        _UPDATE_LOCK_BORROWED=0
    fi
    if [ -n "${_UPDATE_LOCK_DIR:-}" ]; then
        rmdir "$_UPDATE_LOCK_DIR" 2>/dev/null || true
        _UPDATE_LOCK_DIR=""
    fi
}

_acquire_kilix_transaction_lock() {
    local state lock_path fd fd_path path_identity fd_identity existed=0
    command -v flock >/dev/null 2>&1 \
        || die "flock is required to serialize Kilix build/update transactions"
    _validate_kilix_fork_stamp_path
    state="$KILIX_STATE_DIRECTORY"
    ( umask 077; mkdir -p -- "$state" ) \
        || die "could not create KILIX_STATE_DIRECTORY: $state"
    chmod 0700 -- "$state" \
        || die "could not protect KILIX_STATE_DIRECTORY: $state"
    lock_path="$(cd "$state" && pwd -P)/build-update.lock" \
        || die "could not resolve the Kilix transaction lock path"
    if [ -e "$lock_path" ] || [ -L "$lock_path" ]; then
        existed=1
        [ -f "$lock_path" ] && [ ! -L "$lock_path" ] \
            && [ "$(stat -c '%u:%a:%h' -- "$lock_path" 2>/dev/null)" \
                = "$(id -u):600:1" ] \
            || die "refusing unsafe Kilix transaction lock: $lock_path"
    fi
    if [ -n "${KILIX_TRANSACTION_LOCK_FD:-}" ]; then
        fd="$KILIX_TRANSACTION_LOCK_FD"
        [[ "$fd" =~ ^[0-9]+$ ]] \
            || die "KILIX_TRANSACTION_LOCK_FD must be a numeric inherited descriptor"
        fd_path="/proc/$$/fd/$fd"
        [ -e "$fd_path" ] \
            || die "KILIX_TRANSACTION_LOCK_FD=$fd is not open in this process"
        _KILIX_TXN_LOCK_FD="$fd"
        _KILIX_TXN_LOCK_BORROWED=1
    else
        exec {_KILIX_TXN_LOCK_FD}>"$lock_path" \
            || die "could not open the Kilix transaction lock: $lock_path"
        fd="$_KILIX_TXN_LOCK_FD"
        fd_path="/proc/$$/fd/$fd"
        _KILIX_TXN_LOCK_BORROWED=0
    fi
    [ "$existed" = 1 ] || chmod 0600 -- "$lock_path" \
        || die "could not protect the Kilix transaction lock: $lock_path"
    [ -f "$lock_path" ] && [ ! -L "$lock_path" ] \
        && [ "$(stat -c '%u:%a:%h' -- "$lock_path" 2>/dev/null)" \
            = "$(id -u):600:1" ] \
        || die "Kilix transaction lock is not a private regular file: $lock_path"
    path_identity="$(stat -c '%d:%i' -- "$lock_path" 2>/dev/null)" \
        || die "could not inspect the Kilix transaction lock"
    fd_identity="$(stat -Lc '%d:%i' -- "$fd_path" 2>/dev/null)" \
        || die "could not inspect the inherited Kilix transaction-lock descriptor"
    [ "$fd_identity" = "$path_identity" ] \
        || die "KILIX_TRANSACTION_LOCK_FD does not refer to $lock_path"
    # Blocking is correct here — a concurrent build or update must finish before
    # this one starts — but blocking in silence looks like a hang, so say so
    # first. Only announce when the lock is actually contended.
    if ! flock -n -x "$fd"; then
        log "waiting for the Kilix build/update lock ($lock_path)..."
        flock -x "$fd" || die "could not acquire the Kilix transaction lock"
    fi
    KILIX_TRANSACTION_LOCK_FD="$fd"
    KILIX_TRANSACTION_LOCK_PATH="$lock_path"
    export KILIX_TRANSACTION_LOCK_FD KILIX_TRANSACTION_LOCK_PATH
}

_acquire_update_lock() {
    local inherited_path expected_path
    # Reconcile every category before the first lock, cache, or rollback write.
    # Older managed installs may have created these under umask 022.
    ensure_pleb_private_storage
    if [ -n "${PLEB_UPDATE_LOCK_FD:-}" ]; then
        [[ "$PLEB_UPDATE_LOCK_FD" =~ ^[0-9]+$ ]] \
            || die "PLEB_UPDATE_LOCK_FD must be a numeric inherited file descriptor"
        [ -e "/proc/$$/fd/$PLEB_UPDATE_LOCK_FD" ] \
            || die "PLEB_UPDATE_LOCK_FD=$PLEB_UPDATE_LOCK_FD is not open in this process"
        inherited_path="$(readlink -f "/proc/$$/fd/$PLEB_UPDATE_LOCK_FD" 2>/dev/null || true)"
        expected_path="$(readlink -m "$PLEB_STATE_HOME/update.lock")"
        [ "$inherited_path" = "$expected_path" ] \
            || die "PLEB_UPDATE_LOCK_FD must refer to $expected_path (got: ${inherited_path:-unresolved})"
        command -v flock >/dev/null 2>&1 \
            || die "flock is required to validate PLEB_UPDATE_LOCK_FD"
        flock -n -x "$PLEB_UPDATE_LOCK_FD" \
            || die "could not acquire the inherited Pleb update lock on fd $PLEB_UPDATE_LOCK_FD"
        _UPDATE_LOCK_FD="$PLEB_UPDATE_LOCK_FD"
        _UPDATE_LOCK_BORROWED=1
    elif command -v flock >/dev/null 2>&1; then
        exec {_UPDATE_LOCK_FD}>>"$PLEB_STATE_HOME/update.lock"
        _UPDATE_LOCK_BORROWED=0
        flock -n "$_UPDATE_LOCK_FD" \
            || die "another 'pleb update' is already running (lock: $PLEB_STATE_HOME/update.lock)"
    else
        _UPDATE_LOCK_DIR="$PLEB_STATE_HOME/update.lock.d"
        mkdir "$_UPDATE_LOCK_DIR" 2>/dev/null \
            || die "another 'pleb update' is already running (lock: $_UPDATE_LOCK_DIR)"
    fi
    trap _release_update_lock EXIT
    trap 'exit 130' INT
    trap 'exit 143' TERM
}

_snapshot_update_path() {
    local path="$1" key="$2"
    if [ -e "$path" ] || [ -L "$path" ]; then
        cp -a -- "$path" "$_UPDATE_TXN_DIR/$key" \
            || die "could not snapshot update path: $path"
        : >"$_UPDATE_TXN_DIR/$key.present" \
            || die "could not mark update snapshot complete: $path"
    fi
}

_restore_update_path() {
    local path="$1" key="$2" kind="${3:-tree}" failed=0 tmp=""
    if [ "$kind" = file ]; then
        if [ -d "$path" ] && [ ! -L "$path" ]; then
            return 1
        fi
        if [ -f "$_UPDATE_TXN_DIR/$key.present" ]; then
            mkdir -p "$(dirname "$path")" || return 1
            tmp="$(mktemp "${path}.restore.XXXXXX")" || return 1
            rm -f -- "$tmp" || return 1
            if ! cp -a -- "$_UPDATE_TXN_DIR/$key" "$tmp" \
                || ! mv -Tf -- "$tmp" "$path"; then
                rm -f -- "$tmp"
                return 1
            fi
        else
            rm -f -- "$path" || failed=1
        fi
    else
        rm -rf -- "$path" || failed=1
        if [ -f "$_UPDATE_TXN_DIR/$key.present" ]; then
            mkdir -p "$(dirname "$path")" || failed=1
            cp -a -- "$_UPDATE_TXN_DIR/$key" "$path" || failed=1
        fi
    fi
    return "$failed"
}

_kilix_submodule_key() {
    local path="$1" key
    key="${path//\//-}"
    key="${key//./-}"
    printf 'submodule-%s\n' "$key"
}

_write_kilix_submodule_map() {
    local source="$1" output="$2" raw="" rc=0 setting path key
    local -A key_paths=()
    case "$source" in
        committed)
            raw="$(git -C "$KILIX_DIR" config --blob HEAD:.gitmodules \
                --get-regexp '^submodule\..*\.path$' 2>/dev/null)" || rc=$?
            ;;
        worktree)
            raw="$(git -C "$KILIX_DIR" config -f .gitmodules \
                --get-regexp '^submodule\..*\.path$' 2>/dev/null)" || rc=$?
            ;;
        *) return 1 ;;
    esac
    case "$rc" in
        0) ;;
        1) raw="" ;;
        *) return 1 ;;
    esac
    : >"$output" || return 1
    while read -r setting path; do
        [ -n "$setting" ] || continue
        case "$path" in
            ""|.|/*|../*|*/../*|*/..)
                err "refusing unsafe Kilix submodule path in .gitmodules: ${path:-<empty>}"
                return 1 ;;
        esac
        [[ "$path" != *$'\t'* && "$path" != *$'\n'* && "$path" != *$'\r'* ]] \
            || { err "refusing a Kilix submodule path with control characters"; return 1; }
        key="$(_kilix_submodule_key "$path")" || return 1
        if [[ ${key_paths[$key]+x} ]] && [ "${key_paths[$key]}" != "$path" ]; then
            err "Kilix submodule paths collide in rollback state: ${key_paths[$key]} and $path"
            return 1
        fi
        key_paths[$key]="$path"
        printf '%s\t%s\n' "$path" "$key" >>"$output" || return 1
    done <<<"$raw"
}

_union_kilix_submodule_maps() {
    local output="$1" input path key
    shift
    local -A seen=()
    : >"$output" || return 1
    for input in "$@"; do
        [ -f "$input" ] || return 1
        while IFS=$'\t' read -r path key; do
            [ -n "$path" ] || continue
            if [[ ! ${seen[$path]+x} ]]; then
                seen[$path]=1
                printf '%s\t%s\n' "$path" "$key" >>"$output" || return 1
            fi
        done <"$input"
    done
}

_record_checkout_position() {
    local dir="$1" key="$2"
    git -C "$dir" rev-parse --verify HEAD >"$_UPDATE_TXN_DIR/$key.head" \
        || die "could not record the pre-update $key commit"
    git -C "$dir" symbolic-ref --quiet --short HEAD >"$_UPDATE_TXN_DIR/$key.branch" \
        || : >"$_UPDATE_TXN_DIR/$key.branch"
}

_record_checkout_preservation() {
    local dir="$1" label="$2" key="$3" snapshot
    preserve_checkout "$dir" "$label" forward \
        || die "could not preserve $label checkout before update"
    snapshot="$PLEB_PRESERVE_RESULT"
    [ -n "$snapshot" ] || return 0
    printf '%s\n' "$snapshot" >"$_UPDATE_TXN_DIR/$key.preserve" \
        || die "could not record the $label preservation snapshot"
    printf '%s\n' "$snapshot" >>"$_UPDATE_TXN_DIR/$key.preserve-list" \
        || die "could not record the $label preservation list"
    if [ "$key" = pleb ]; then
        _PLEB_SELF_INITIAL_PRESERVE="$snapshot"
        _PLEB_SELF_PRESERVATIONS+=("$snapshot")
    fi
}

_capture_transaction_checkout_before_move() {
    local dir="$1" label="$2" key snapshot
    case "$label" in
        "kilix 95") key=kilix95 ;;
        *) key="$label" ;;
    esac
    preserve_checkout "$dir" "$label" forward \
        || die "could not preserve $label changes immediately before checkout"
    snapshot="$PLEB_PRESERVE_RESULT"
    if [ -n "$snapshot" ]; then
        prepare_preserved_checkout "$dir" "$snapshot" \
            || die "$label changed while preparing its preservation snapshot: $snapshot"
        if [ ! -f "$_UPDATE_TXN_DIR/$key.preserve" ]; then
            printf '%s\n' "$snapshot" >"$_UPDATE_TXN_DIR/$key.preserve" \
                || die "could not record the late $label rollback snapshot"
        fi
        printf '%s\n' "$snapshot" >>"$_UPDATE_TXN_DIR/$key.preserve-list" \
            || die "could not record the late $label preservation snapshot"
        fsync_update_record "$_UPDATE_TXN_DIR" \
            || die "could not make the late $label preservation record durable"
    fi
    _assert_still_clean "$dir" "$key" \
        || die "$label checkout changed immediately before its move"
}

_prepare_recorded_preservation() {
    local dir="$1" key="$2" snapshot
    [ -f "$_UPDATE_TXN_DIR/$key.preserve" ] || return 0
    snapshot="$(cat "$_UPDATE_TXN_DIR/$key.preserve")" || return 1
    prepare_preserved_checkout "$dir" "$snapshot"
}

_restore_recorded_preservation() {
    local dir="$1" key="$2" mode="$3" target="${4:-unknown}" snapshot
    [ -f "$_UPDATE_TXN_DIR/$key.preserve" ] || return 0
    snapshot="$(cat "$_UPDATE_TXN_DIR/$key.preserve")" || return 1
    restore_preserved_checkout "$dir" "$snapshot" "$mode" "$target"
}

_restore_recorded_preservations_after_success() {
    local dir="$1" key="$2" target="$3" snapshot
    [ -f "$_UPDATE_TXN_DIR/$key.preserve-list" ] || return 0
    while IFS= read -r snapshot; do
        [ -n "$snapshot" ] || continue
        restore_preserved_checkout "$dir" "$snapshot" success "$target" \
            || return 1
    done <"$_UPDATE_TXN_DIR/$key.preserve-list"
}

_preserve_before_forced_restore() {
    local dir="$1" label="$2" snapshot
    git -C "$dir" rev-parse --is-inside-work-tree >/dev/null 2>&1 || return 0
    preserve_checkout "$dir" "$label" rollback || return 1
    snapshot="$PLEB_PRESERVE_RESULT"
    [ -n "$snapshot" ] || return 0
    prepare_preserved_checkout "$dir" "$snapshot"
}

_preserve_pleb_before_move() {
    local snapshot
    preserve_checkout "$PLEB_ROOT" pleb forward \
        || die "could not preserve pleb checkout before self-update"
    snapshot="$PLEB_PRESERVE_RESULT"
    if [ -n "$snapshot" ]; then
        prepare_preserved_checkout "$PLEB_ROOT" "$snapshot" \
            || die "pleb checkout changed while preparing its preservation snapshot: $snapshot"
        _PLEB_SELF_PRESERVATIONS+=("$snapshot")
        [ -n "$_PLEB_SELF_INITIAL_PRESERVE" ] \
            || _PLEB_SELF_INITIAL_PRESERVE="$snapshot"
    fi
    _assert_still_clean "$PLEB_ROOT" pleb \
        || die "pleb checkout changed while its preservation snapshot was prepared"
}

_restore_pleb_preservations_after_success() {
    local target="$1" snapshot
    for snapshot in "${_PLEB_SELF_PRESERVATIONS[@]}"; do
        restore_preserved_checkout "$PLEB_ROOT" "$snapshot" success "$target" \
            || die "pleb updated, but operator paths could not be restored; preserved at $snapshot"
    done
    _PLEB_SELF_PRESERVATIONS=()
    _PLEB_SELF_INITIAL_PRESERVE=""
}

_assert_still_clean() {
    local dir="$1" label="$2" status ignore=none
    [ "$label" = kilix ] && ignore=all
    status="$(git -C "$dir" status --porcelain --untracked-files=normal \
        --ignore-submodules="$ignore" \
        2>/dev/null)" \
        || { err "could not re-check $label checkout at $dir"; return 1; }
    if [ -n "$status" ]; then
        err "$label checkout at $dir changed after the update safety gate; refusing to move it:"
        printf '%s\n' "$status" >&2
        return 1
    fi
}

_restore_checkout_position() {
    local dir="$1" key="$2" head branch log_file
    [ -f "$_UPDATE_TXN_DIR/$key.head" ] || return 0
    head="$(cat "$_UPDATE_TXN_DIR/$key.head")"
    branch="$(cat "$_UPDATE_TXN_DIR/$key.branch")"
    _assert_still_clean "$dir" "$key" || return 1
    # Never recurse: reconcile_kilix_submodules sets submodule.recurse=true on
    # Kilix, and a recursive checkout that dies inside a submodule (an embedded
    # gitdir with linked worktrees cannot be relocated) stops after rewriting
    # part of the parent tree while HEAD stays on the target. The rollback
    # restores each recorded submodule itself afterwards.
    log_file="$_UPDATE_TXN_DIR/$key.restore.log"
    if [ -n "$branch" ]; then
        git -C "$dir" -c submodule.recurse=false checkout -f "$branch" \
            >"$log_file" 2>&1 \
            && git -C "$dir" -c submodule.recurse=false reset --hard "$head" \
                >>"$log_file" 2>&1
    else
        git -C "$dir" -c submodule.recurse=false checkout -f --detach "$head" \
            >"$log_file" 2>&1 \
            && git -C "$dir" -c submodule.recurse=false reset --hard "$head" \
                >>"$log_file" 2>&1
    fi || {
        err "could not return $key to $head; git said: $(tail -n 3 -- "$log_file" | tr '\n' ' ')"
        return 1
    }
}

_deinit_new_kilix_submodule() {
    local path="$1" key="$2" initialized entry mode="" expected="" actual status
    initialized="$(cat "$_UPDATE_TXN_DIR/$key.initialized" 2>/dev/null || echo 0)"
    [ "$initialized" = 0 ] || return 0
    [ -e "$KILIX_DIR/$path" ] || [ -L "$KILIX_DIR/$path" ] || return 0
    entry="$(git -C "$KILIX_DIR" ls-files --stage -- "$path" 2>/dev/null \
        | awk 'NR == 1 { print $1 " " $2 }')"
    read -r mode expected <<<"$entry" || :
    if [ "$mode" != 160000 ] \
        || [ ! -f "$KILIX_DIR/$path/.git" ] \
        || [ -L "$KILIX_DIR/$path/.git" ]; then
        err "refusing to deinitialize $path: it is not an update-created submodule checkout"
        return 1
    fi
    actual="$(git -C "$KILIX_DIR/$path" rev-parse --verify HEAD 2>/dev/null)" \
        || { err "refusing to deinitialize $path: its checkout identity is unreadable"; return 1; }
    status="$(git -C "$KILIX_DIR/$path" status --porcelain \
        --untracked-files=all --ignored 2>/dev/null)" \
        || { err "refusing to deinitialize $path: its checkout state is unreadable"; return 1; }
    if [ "$actual" != "$expected" ] || [ -n "$status" ]; then
        err "refusing to deinitialize $path: it is not an exact clean checkout of $expected"
        return 1
    fi
    git -C "$KILIX_DIR" submodule deinit -f -- "$path" >/dev/null 2>&1
}

_record_created_kilix95_checkout() {
    [ "$(cat "$_UPDATE_TXN_DIR/kilix95.existed" 2>/dev/null || echo 1)" = 0 ] \
        || return 0
    [ -d "$KILIX95_DIR/.git" ] && [ ! -L "$KILIX95_DIR/.git" ] \
        || die "new Kilix 95 path is not a safe checkout: $KILIX95_DIR"
    git -C "$KILIX95_DIR" rev-parse --verify HEAD \
        >"$_UPDATE_TXN_DIR/kilix95.created-head" \
        || die "could not record the new Kilix 95 checkout identity"
    git -C "$KILIX95_DIR" config --get remote.origin.url \
        >"$_UPDATE_TXN_DIR/kilix95.created-origin" \
        || die "could not record the new Kilix 95 checkout origin"
    : >"$_UPDATE_TXN_DIR/kilix95.created" \
        || die "could not complete the new Kilix 95 checkout identity"
}

_remove_created_kilix95_checkout() {
    local expected actual expected_origin actual_origin status
    [ -e "$KILIX95_DIR" ] || [ -L "$KILIX95_DIR" ] || return 0
    if [ ! -f "$_UPDATE_TXN_DIR/kilix95.created" ] \
        || [ ! -d "$KILIX95_DIR/.git" ] \
        || [ -L "$KILIX95_DIR/.git" ]; then
        err "refusing Kilix 95 cleanup at $KILIX95_DIR: this update did not record creating that checkout"
        return 1
    fi
    expected="$(cat "$_UPDATE_TXN_DIR/kilix95.created-head")" || return 1
    expected_origin="$(cat "$_UPDATE_TXN_DIR/kilix95.created-origin")" || return 1
    actual="$(git -C "$KILIX95_DIR" rev-parse --verify HEAD 2>/dev/null)" || return 1
    actual_origin="$(git -C "$KILIX95_DIR" config --get remote.origin.url 2>/dev/null)" \
        || return 1
    status="$(git -C "$KILIX95_DIR" status --porcelain \
        --untracked-files=all --ignored 2>/dev/null)" || return 1
    if [ "$actual" != "$expected" ] || [ "$actual_origin" != "$expected_origin" ] \
        || [ -n "$status" ]; then
        err "refusing Kilix 95 cleanup at $KILIX95_DIR: the update-created checkout changed"
        return 1
    fi
    rm -rf -- "$KILIX95_DIR"
}

_validate_kilix_storage_root() {
    local storage source kilix_root=""
    storage="$(_pleb_normalized_absolute_path \
        "$(_pleb_storage_path_input "$KILIX_STORAGE_HOME")")"
    source="$(_pleb_normalized_absolute_path \
        "$(_pleb_storage_path_input "$GPU_TERMINAL_SOURCE_HOME")")"
    if [ -d "$KILIX_DIR" ]; then
        kilix_root="$(cd "$KILIX_DIR" && pwd -P)" \
            || die "could not resolve the physical Kilix checkout: $KILIX_DIR"
    fi
    [ "$KILIX_STORAGE_HOME" = "$storage" ] \
        || die "KILIX_STORAGE_HOME must be a normalized absolute path: $KILIX_STORAGE_HOME"
    case "$storage" in
        /|/bin|/boot|/dev|/etc|/home|/lib|/lib64|/media|/mnt|/opt|/proc|/root|/run|/sbin|/srv|/sys|/tmp|/usr|/var|"${HOME%/}")
            die "KILIX_STORAGE_HOME is too broad for Kilix writable state: $storage" ;;
    esac
    case "$storage" in
        "$source"|"$source"/*)
            die "KILIX_STORAGE_HOME must not place writable state in the source tree: $source" ;;
    esac
    if [ -n "$kilix_root" ]; then
        case "$storage" in
            "$kilix_root"|"$kilix_root"/*)
                die "KILIX_STORAGE_HOME must not place writable state in the Kilix checkout: $kilix_root" ;;
        esac
    fi
    KILIX_STORAGE_HOME="$storage"
}

_validate_kilix_build_transaction_path() {
    local storage build owner mode
    _validate_kilix_storage_root
    storage="$KILIX_STORAGE_HOME"
    build="$(_pleb_normalized_absolute_path \
        "$(_pleb_storage_path_input "$KILIX_BUILD_DIRECTORY")")"
    [ "$KILIX_BUILD_DIRECTORY" = "$build" ] \
        || die "KILIX_BUILD_DIRECTORY must be a normalized absolute path: $KILIX_BUILD_DIRECTORY"
    case "$build" in
        "$storage"/*) ;;
        *) die "KILIX_BUILD_DIRECTORY must be below KILIX_STORAGE_HOME: $build" ;;
    esac
    _pleb_assert_safe_storage_parent_chain "$build"
    _pleb_assert_no_symlink_components "$build"
    if [ -e "$build" ] || [ -L "$build" ]; then
        [ -d "$build" ] && [ ! -L "$build" ] \
            || die "refusing unsafe KILIX_BUILD_DIRECTORY: $build"
        owner="$(stat -c '%u' -- "$build" 2>/dev/null)" \
            || die "could not inspect KILIX_BUILD_DIRECTORY: $build"
        [ "$owner" = "$(id -u)" ] \
            || die "KILIX_BUILD_DIRECTORY is not owned by the current user: $build"
        mode="$(stat -c '%a' -- "$build" 2>/dev/null)" \
            || die "could not inspect KILIX_BUILD_DIRECTORY mode: $build"
        [ "$mode" = 700 ] \
            || die "KILIX_BUILD_DIRECTORY must have mode 0700: $build"
    fi
    KILIX_STORAGE_HOME="$storage"
    KILIX_BUILD_DIRECTORY="$build"
}

_kilix_generation_entry_identity() {
    local path="$1" output="$2" device inode target
    if [ -L "$path" ]; then
        target="$(readlink -- "$path")" || return 1
        [[ "$target" =~ ^generations/build\.[A-Za-z0-9]+$ ]] || return 1
        _kilix_generation_target_is_contained "$target" || return 1
        device="$(stat -c '%d' -- "$path")" || return 1
        inode="$(stat -c '%i' -- "$path")" || return 1
        printf 'symlink\t%s\t%s\t%s\n' "$device" "$inode" "$target" >"$output"
    elif [ -d "$path" ]; then
        device="$(stat -c '%d' -- "$path")" || return 1
        inode="$(stat -c '%i' -- "$path")" || return 1
        printf 'directory\t%s\t%s\n' "$device" "$inode" >"$output"
    elif [ -e "$path" ]; then
        return 1
    else
        printf '%s\n' absent >"$output"
    fi
}

_kilix_generation_target_is_contained() {
    local target="$1" build_root candidate candidate_root
    [[ "$target" =~ ^generations/build\.[A-Za-z0-9]+$ ]] || return 1
    candidate="$KILIX_BUILD_DIRECTORY/$target"
    [ -d "$candidate" ] && [ ! -L "$candidate" ] || return 1
    build_root="$(cd "$KILIX_BUILD_DIRECTORY" && pwd -P)" || return 1
    candidate_root="$(cd "$candidate" && pwd -P)" || return 1
    [ "$candidate_root" = "$build_root/$target" ]
}

_kilix_generation_target() {
    local entry="$1" target
    [ -L "$entry" ] || return 1
    target="$(readlink -- "$entry")" || return 1
    [[ "$target" =~ ^generations/build\.[A-Za-z0-9]+$ ]] || return 1
    printf '%s\n' "$target"
}

_kilix_generation_target_is_referenced() {
    local target="$1" ref
    for ref in "$KILIX_BUILD_DIRECTORY/current" \
               "$KILIX_BUILD_DIRECTORY/previous" \
               "$KILIX_BUILD_DIRECTORY/prepared" \
               "$KILIX_BUILD_DIRECTORY"/.current.* \
               "$KILIX_BUILD_DIRECTORY"/.prepared.* \
               "$KILIX_BUILD_DIRECTORY"/.previous.* \
               "$KILIX_BUILD_DIRECTORY"/.update-rollback.*/*.entry \
               "$KILIX_BUILD_DIRECTORY"/.pleb-update.*/previous \
               "$KILIX_BUILD_DIRECTORY"/.plebian-os-update.*/previous; do
        if [ -L "$ref" ] \
            && [ "$(readlink -- "$ref" 2>/dev/null || true)" = "$target" ]; then
            return 0
        fi
    done
    return 1
}

_kilix_generation_has_live_executable() {
    local candidate="$1" proc_exe executable inspected=0
    # Match Kilix's generation collector: /proc is the lease registry for
    # running engines. If it cannot be inspected, retaining disk is safer than
    # unlinking a generation that a live terminal still needs.
    [ -d /proc ] || return 0
    for proc_exe in /proc/[0-9]*/exe; do
        [ -L "$proc_exe" ] || continue
        executable="$(readlink -f -- "$proc_exe" 2>/dev/null || true)"
        [ -n "$executable" ] || continue
        inspected=1
        case "$executable" in
            "$candidate"|"$candidate"/*) return 0 ;;
        esac
    done
    [ "$inspected" = 1 ] || return 0
    return 1
}

_kilix_collect_unreferenced_generation() {
    local target="$1" path owner candidate_root
    [[ "$target" =~ ^generations/build\.[A-Za-z0-9]+$ ]] || return 1
    _kilix_generation_target_is_referenced "$target" && return 0
    path="$KILIX_BUILD_DIRECTORY/$target"
    [ -e "$path" ] || [ -L "$path" ] || return 0
    _kilix_generation_target_is_contained "$target" || return 1
    owner="$(stat -c '%u' -- "$path" 2>/dev/null)" || return 1
    [ "$owner" = "$(id -u)" ] || return 1
    candidate_root="$(cd "$path" && pwd -P)" || return 1
    if _kilix_generation_has_live_executable "$candidate_root"; then
        warn "retaining live Kilix generation: $candidate_root"
        return 0
    fi
    rm -rf -- "$path"
}

# Where the outgoing Kilix generation waits while this transaction is in
# flight. The shape is a contract with the engine's generation collector
# (kilix build.sh, generation_target_is_referenced): a `.update-rollback.*`
# directory below the build directory holding entries named `*.entry`. A
# nested `kilix --build` reclaims every generation it cannot see a reference
# to, so parking anywhere else has the collector delete the generation this
# transaction is holding for its own rollback — which then restores `previous`
# onto a deleted target and leaves the machine unable to update at all.
# Changing either half of this without the other reintroduces exactly that.
_KILIX_ENGINE_PARK_TEMPLATE=".update-rollback.XXXXXX"
_KILIX_ENGINE_PARK_ENTRY="previous.entry"

_kilix_engine_park_path() {
    local park owner mode
    park="$(cat "$_UPDATE_TXN_DIR/kilix-engine.park" 2>/dev/null || true)"
    [ -n "$park" ] || return 1
    [ "$(dirname "$park")" = "$KILIX_BUILD_DIRECTORY" ] || return 1
    [[ "$(basename "$park")" =~ ^\.update-rollback\.[A-Za-z0-9]+$ ]] || return 1
    [ -d "$park" ] && [ ! -L "$park" ] || return 1
    owner="$(stat -c '%u' -- "$park" 2>/dev/null)" || return 1
    mode="$(stat -c '%a' -- "$park" 2>/dev/null)" || return 1
    [ "$owner" = "$(id -u)" ] && [ "$mode" = 700 ] || return 1
    printf '%s\n' "$park"
}

# A `previous` entry naming a generation that is no longer on disk references
# nothing: there is no state left to roll back to, only an entry that fails
# every safety check and stops all three update paths. Pleb releases up to
# 0.1.8 parked outside the collector's contract, so a failed update that had
# rebuilt the engine could leave exactly that behind. Retire the stale entry
# instead of refusing, so the machine repairs itself on the next update rather
# than needing hand surgery in the build directory.
_repair_dangling_kilix_previous_entry() {
    local previous="$KILIX_BUILD_DIRECTORY/previous" target
    [ -L "$previous" ] || return 0
    target="$(readlink -- "$previous")" || return 0
    [[ "$target" =~ ^generations/build\.[A-Za-z0-9]+$ ]] || return 0
    [ -e "$KILIX_BUILD_DIRECTORY/$target" ] && return 0
    warn "previous Kilix generation $target is gone; retiring the stale entry"
    rm -f -- "$previous" \
        || die "could not retire the stale Kilix previous generation entry: $previous"
}

_snapshot_kilix_engine_generation() {
    local current="$KILIX_BUILD_DIRECTORY/current"
    local previous="$KILIX_BUILD_DIRECTORY/previous"
    _validate_kilix_build_transaction_path
    _repair_dangling_kilix_previous_entry
    _kilix_generation_entry_identity "$current" \
        "$_UPDATE_TXN_DIR/kilix-engine.current.identity" \
        || die "refusing unsafe Kilix current generation entry: $current"
    _kilix_generation_entry_identity "$previous" \
        "$_UPDATE_TXN_DIR/kilix-engine.previous.identity" \
        || die "refusing unsafe Kilix previous generation entry: $previous"
    if [ -L "$current" ]; then
        cp -a -- "$current" "$_UPDATE_TXN_DIR/kilix-engine.current.entry" \
            || die "could not snapshot the Kilix current generation entry"
    fi
    printf '%s\n' 0 >"$_UPDATE_TXN_DIR/kilix-engine.previous.parked"
}

_begin_kilix_engine_mutation() {
    local previous="$KILIX_BUILD_DIRECTORY/previous" park
    if [ -e "$previous" ] || [ -L "$previous" ]; then
        park="$(mktemp -d "$KILIX_BUILD_DIRECTORY/$_KILIX_ENGINE_PARK_TEMPLATE")" \
            || die "could not create Kilix generation rollback state"
        chmod 0700 -- "$park" \
            || die "could not protect Kilix generation rollback state"
        printf '%s\n' "$park" >"$_UPDATE_TXN_DIR/kilix-engine.park"
        mv -- "$previous" "$park/$_KILIX_ENGINE_PARK_ENTRY" \
            || die "could not park the previous Kilix generation"
        printf '%s\n' 1 >"$_UPDATE_TXN_DIR/kilix-engine.previous.parked"
    fi
}

_remove_kilix_generation_entry() {
    local entry="$1"
    if [ -d "$entry" ] && [ ! -L "$entry" ]; then
        # Current generation transactions publish symlinks. A directory here
        # is either legacy recovery state or content that appeared while the
        # transaction ran; retain it for inspection instead of recursing.
        return 1
    elif [ -e "$entry" ] || [ -L "$entry" ]; then
        rm -f -- "$entry"
    fi
}

_restore_kilix_engine_generation() {
    local current="$KILIX_BUILD_DIRECTORY/current"
    local previous="$KILIX_BUILD_DIRECTORY/previous"
    local old_current current_after previous_after park parked_entry parked
    local new_target=""
    old_current="$(cat "$_UPDATE_TXN_DIR/kilix-engine.current.identity")" \
        || return 1
    _kilix_generation_entry_identity "$current" \
        "$_UPDATE_TXN_DIR/kilix-engine.current.after" || return 1
    current_after="$(cat "$_UPDATE_TXN_DIR/kilix-engine.current.after")" \
        || return 1

    if [ "$current_after" != "$old_current" ]; then
        new_target="$(_kilix_generation_target "$current" 2>/dev/null || true)"
        if [ "$old_current" != absent ]; then
            _kilix_generation_entry_identity "$previous" \
                "$_UPDATE_TXN_DIR/kilix-engine.previous.after" || return 1
            previous_after="$(cat "$_UPDATE_TXN_DIR/kilix-engine.previous.after")" \
                || return 1
            if [ "$previous_after" = "$old_current" ]; then
                _remove_kilix_generation_entry "$current" || return 1
                mv -- "$previous" "$current" || return 1
            elif [ -L "$_UPDATE_TXN_DIR/kilix-engine.current.entry" ]; then
                _remove_kilix_generation_entry "$current" || return 1
                cp -a -- "$_UPDATE_TXN_DIR/kilix-engine.current.entry" "$current" \
                    || return 1
            else
                return 1
            fi
        else
            _remove_kilix_generation_entry "$current" || return 1
        fi
    fi

    parked="$(cat "$_UPDATE_TXN_DIR/kilix-engine.previous.parked" 2>/dev/null || echo 0)"
    if [ "$parked" = 1 ]; then
        park="$(_kilix_engine_park_path)" || return 1
        parked_entry="$park/$_KILIX_ENGINE_PARK_ENTRY"
        [ -e "$parked_entry" ] || [ -L "$parked_entry" ] || return 1
        [ ! -e "$previous" ] && [ ! -L "$previous" ] || return 1
        mv -- "$parked_entry" "$previous" || return 1
        rmdir -- "$park" || return 1
    else
        [ ! -e "$previous" ] && [ ! -L "$previous" ] || return 1
    fi
    [ -z "$new_target" ] \
        || _kilix_collect_unreferenced_generation "$new_target" || return 1
}

_commit_kilix_engine_generation() {
    local current="$KILIX_BUILD_DIRECTORY/current"
    local previous="$KILIX_BUILD_DIRECTORY/previous"
    local old_current current_after previous_after park parked_entry parked
    local retired_target=""
    old_current="$(cat "$_UPDATE_TXN_DIR/kilix-engine.current.identity")" \
        || return 1
    _kilix_generation_entry_identity "$current" \
        "$_UPDATE_TXN_DIR/kilix-engine.current.commit" || return 1
    current_after="$(cat "$_UPDATE_TXN_DIR/kilix-engine.current.commit")" \
        || return 1
    parked="$(cat "$_UPDATE_TXN_DIR/kilix-engine.previous.parked" 2>/dev/null || echo 0)"

    if [ "$current_after" = "$old_current" ]; then
        if [ "$parked" = 1 ]; then
            park="$(_kilix_engine_park_path)" || return 1
            [ ! -e "$previous" ] && [ ! -L "$previous" ] || return 1
            mv -- "$park/$_KILIX_ENGINE_PARK_ENTRY" "$previous" \
                || return 1
            rmdir -- "$park" || return 1
        else
            [ ! -e "$previous" ] && [ ! -L "$previous" ] || return 1
        fi
        return 0
    fi

    if [ "$old_current" != absent ]; then
        _kilix_generation_entry_identity "$previous" \
            "$_UPDATE_TXN_DIR/kilix-engine.previous.commit" || return 1
        previous_after="$(cat "$_UPDATE_TXN_DIR/kilix-engine.previous.commit")" \
            || return 1
        [ "$previous_after" = "$old_current" ] || return 1
    else
        [ ! -e "$previous" ] && [ ! -L "$previous" ] || return 1
    fi

    if [ "$parked" = 1 ]; then
        park="$(_kilix_engine_park_path)" || return 1
        parked_entry="$park/$_KILIX_ENGINE_PARK_ENTRY"
        retired_target="$(_kilix_generation_target "$parked_entry" \
            2>/dev/null || true)"
        if ! _remove_kilix_generation_entry "$parked_entry" \
            || ! rmdir -- "$park"; then
            warn "Kilix update committed, but old-generation recovery data remains at $park"
            return 0
        fi
        if [ -n "$retired_target" ] \
            && ! _kilix_collect_unreferenced_generation "$retired_target"; then
            warn "Kilix update committed, but superseded generation cleanup was incomplete: $retired_target"
        fi
    fi
}

_update_transaction_rollback() {
    local failed=0 stamp legacy_stamp path key
    local current_submodules="$_UPDATE_TXN_DIR/submodules.current"
    local rollback_submodules="$_UPDATE_TXN_DIR/submodules.rollback"
    stamp="$(_kilix_fork_stamp)"
    legacy_stamp="$PLEB_STATE_HOME/kilix-fork-built-ref"
    warn "update failed; restoring the previous coherent Kilix/Kilix 95 state"

    if ! _write_kilix_submodule_map worktree "$current_submodules"; then
        err "could not derive the current Kilix submodule set for rollback"
        return 1
    fi
    if ! _union_kilix_submodule_maps "$rollback_submodules" \
            "$_UPDATE_TXN_DIR/submodules" "$current_submodules"; then
        err "could not assemble the Kilix submodule rollback set"
        return 1
    fi

    # No forced checkout, submodule deinit, or provider-tree removal is allowed
    # until edits made during this run have their own verified, durable copy.
    # If preservation itself fails, leave the stack untouched for inspection.
    if ! _preserve_before_forced_restore "$KILIX_DIR" kilix; then
        err "could not preserve Kilix changes before rollback"
        return 1
    fi
    while IFS=$'\t' read -r path key; do
        [ -n "$path" ] || continue
        if git -C "$KILIX_DIR/$path" rev-parse --is-inside-work-tree >/dev/null 2>&1 \
            && ! _preserve_before_forced_restore "$KILIX_DIR/$path" "$key"; then
            err "could not preserve $path changes before rollback"
            return 1
        fi
    done <"$rollback_submodules"
    if [ -d "$KILIX95_DIR/.git" ] \
        && ! _preserve_before_forced_restore "$KILIX95_DIR" kilix95; then
        err "could not preserve Kilix 95 changes before rollback"
        return 1
    fi
    if [ -f "$_UPDATE_TXN_DIR/pleb.preserve" ] \
        && ! _preserve_before_forced_restore "$PLEB_ROOT" pleb; then
        err "could not preserve Pleb changes before rollback"
        return 1
    fi

    # Deinitialize submodules introduced by the failed parent update while the
    # new .gitmodules entry still exists. Restoring the parent first would
    # strand their worktrees/config when the old commit did not know the path.
    while IFS=$'\t' read -r path key; do
        [ -n "$path" ] || continue
        _deinit_new_kilix_submodule "$path" "$key" || failed=1
    done <"$rollback_submodules"
    _restore_checkout_position "$KILIX_DIR" kilix || failed=1
    while IFS=$'\t' read -r path key; do
        [ -n "$path" ] || continue
        if [ "$(cat "$_UPDATE_TXN_DIR/$key.initialized" 2>/dev/null || echo 0)" = 1 ] \
            && [ -f "$_UPDATE_TXN_DIR/$key.head" ]; then
            _restore_checkout_position "$KILIX_DIR/$path" "$key" || failed=1
        fi
    done <"$rollback_submodules"
    if [ "$(cat "$_UPDATE_TXN_DIR/kilix95.existed" 2>/dev/null || echo 1)" = 0 ]; then
        _remove_created_kilix95_checkout || failed=1
    elif [ -f "$_UPDATE_TXN_DIR/kilix95.head" ]; then
        _restore_checkout_position "$KILIX95_DIR" kilix95 || failed=1
    fi
    _restore_recorded_preservation "$KILIX_DIR" kilix rollback \
        "$(cat "$_UPDATE_TXN_DIR/kilix.head" 2>/dev/null || echo unknown)" \
        || failed=1
    while IFS=$'\t' read -r path key; do
        [ -n "$path" ] || continue
        if [ -f "$_UPDATE_TXN_DIR/$key.preserve" ]; then
            _restore_recorded_preservation "$KILIX_DIR/$path" "$key" rollback \
                "$(cat "$_UPDATE_TXN_DIR/$key.head" 2>/dev/null || echo unknown)" \
                || failed=1
        fi
    done <"$rollback_submodules"
    if [ -f "$_UPDATE_TXN_DIR/kilix95.preserve" ]; then
        _restore_recorded_preservation "$KILIX95_DIR" kilix95 rollback \
            "$(cat "$_UPDATE_TXN_DIR/kilix95.head" 2>/dev/null || echo unknown)" \
            || failed=1
    fi
    if [ -f "$_UPDATE_TXN_DIR/pleb.preserve" ]; then
        _restore_recorded_preservation "$PLEB_ROOT" pleb rollback \
            "$(git -C "$PLEB_ROOT" rev-parse HEAD 2>/dev/null || echo unknown)" \
            || failed=1
    fi
    _restore_kilix_engine_generation || failed=1
    _restore_update_path "$stamp" fork-stamp file || failed=1
    _restore_update_path "$legacy_stamp" legacy-fork-stamp file || failed=1
    _restore_update_path "$KILIX_TEMPS_BIN" kilix-temps-bin file || failed=1
    _restore_update_path "$KILIX_MEMORY_BIN" kilix-memory-bin file || failed=1
    _restore_update_path "$TMUX_TUI_BIN" tmux-tui-bin file || failed=1
    _restore_update_path "$TMUX_CLI_BIN" tmux-cli-bin file || failed=1
    _restore_update_path "$TMUX_TUI_STAMP" tmux-tui-stamp file || failed=1
    _restore_update_path \
        "$KILIX_PTY_BROKER_BUILD" kilix-pty-broker-build || failed=1

    if [ "$failed" = 0 ]; then
        log "restored the pre-update component commits and fork engine"
    else
        err "automatic update rollback was incomplete; inspect $_UPDATE_TXN_DIR before retrying"
    fi
    return "$failed"
}

_update_cleanup() {
    local rc=$? rollback_ok=1
    trap - EXIT INT TERM
    set +e
    if [ "${_UPDATE_TXN_ACTIVE:-0}" = 1 ] \
        && [ "${_UPDATE_TXN_COMMITTED:-0}" != 1 ]; then
        [ "$rc" -ne 0 ] || rc=1
        if ! _update_transaction_rollback; then
            rc=1
            rollback_ok=0
        fi
    fi
    if [ -n "${_UPDATE_TXN_DIR:-}" ] && [ "$rollback_ok" = 1 ]; then
        rm -rf -- "$_UPDATE_TXN_DIR"
        _UPDATE_TXN_DIR=""
    elif [ -n "${_UPDATE_TXN_DIR:-}" ]; then
        err "rollback recovery data retained at $_UPDATE_TXN_DIR"
    fi
    if [ "${_PLEB_SELF_MOVE_ACTIVE:-0}" = 1 ]; then
        [ "$rc" -ne 0 ] || rc=1
        warn "pleb self-update failed; restoring ${_PLEB_SELF_BEFORE:0:12}"
        if ! _pleb_self_update_restore "$_PLEB_SELF_BEFORE" "$_PLEB_SELF_BRANCH"; then
            err "automatic Pleb self-update rollback was incomplete; preserved data remains under $(_pleb_preservation_root)"
            rc=1
            rollback_ok=0
        elif [ -n "$_PLEB_SELF_INITIAL_PRESERVE" ] \
            && ! restore_preserved_checkout "$PLEB_ROOT" \
                "$_PLEB_SELF_INITIAL_PRESERVE" rollback "$_PLEB_SELF_BEFORE"; then
            err "Pleb commit was restored, but operator paths remain only at $_PLEB_SELF_INITIAL_PRESERVE"
            rc=1
            rollback_ok=0
        fi
        _PLEB_SELF_MOVE_ACTIVE=0
    fi
    _release_update_lock
    exit "$rc"
}

_update_transaction_begin() {
    _require_managed_source_layout
    local stamp legacy_stamp
    _validate_legacy_kilix_fork_stamp_path
    _acquire_kilix_transaction_lock
    _UPDATE_TXN_DIR="$(mktemp -d "$PLEB_STATE_HOME/update-rollback.XXXXXX")" \
        || die "could not create update rollback state"
    _UPDATE_TXN_ACTIVE=0
    _UPDATE_TXN_COMMITTED=0
    # Replace the lock-only EXIT trap. This cleanup always releases that same
    # lock, and rolls back only after the complete snapshot has been captured.
    trap _update_cleanup EXIT
    trap 'exit 130' INT
    trap 'exit 143' TERM
    chmod 0700 "$_UPDATE_TXN_DIR"

    _write_kilix_submodule_map committed "$_UPDATE_TXN_DIR/submodules" \
        || die "could not derive the committed Kilix submodule set"
    _write_kilix_submodule_map worktree "$_UPDATE_TXN_DIR/submodules.worktree" \
        || die "could not derive the working Kilix submodule set"
    _union_kilix_submodule_maps "$_UPDATE_TXN_DIR/submodules.participating" \
        "$_UPDATE_TXN_DIR/submodules" "$_UPDATE_TXN_DIR/submodules.worktree" \
        || die "could not assemble participating Kilix submodules"
    _record_checkout_position "$KILIX_DIR" kilix
    while IFS=$'\t' read -r path key; do
        [ -n "$path" ] || continue
        if git -C "$KILIX_DIR/$path" rev-parse --verify HEAD >/dev/null 2>&1; then
            printf '%s\n' 1 >"$_UPDATE_TXN_DIR/$key.initialized"
            _record_checkout_position "$KILIX_DIR/$path" "$key"
        else
            printf '%s\n' 0 >"$_UPDATE_TXN_DIR/$key.initialized"
        fi
    done <"$_UPDATE_TXN_DIR/submodules.participating"
    if [ -e "$KILIX95_DIR" ] || [ -L "$KILIX95_DIR" ]; then
        printf '%s\n' 1 >"$_UPDATE_TXN_DIR/kilix95.existed"
        if [ -d "$KILIX95_DIR/.git" ]; then
            _record_checkout_position "$KILIX95_DIR" kilix95
        fi
    else
        printf '%s\n' 0 >"$_UPDATE_TXN_DIR/kilix95.existed"
    fi
    # All preservation copies precede every update mutation. Only after every
    # snapshot path is recorded and the transaction record is fsynced do local
    # paths move aside and the engine transaction begin.
    _record_checkout_preservation "$KILIX_DIR" kilix kilix
    while IFS=$'\t' read -r path key; do
        [ -n "$path" ] || continue
        git -C "$KILIX_DIR/$path" rev-parse --is-inside-work-tree >/dev/null 2>&1 \
            || continue
        _record_checkout_preservation "$KILIX_DIR/$path" "$key" "$key"
    done <"$_UPDATE_TXN_DIR/submodules.participating"
    if [ -d "$KILIX95_DIR/.git" ]; then
        _record_checkout_preservation "$KILIX95_DIR" kilix95 kilix95
    fi
    if [ "${_PLEB_SELF_UPDATE_OK:-0}" = 1 ]; then
        _record_checkout_preservation "$PLEB_ROOT" pleb pleb
    fi

    stamp="$(_kilix_fork_stamp)"
    legacy_stamp="$PLEB_STATE_HOME/kilix-fork-built-ref"
    _snapshot_kilix_engine_generation
    _snapshot_update_path "$stamp" fork-stamp
    _snapshot_update_path "$legacy_stamp" legacy-fork-stamp
    _snapshot_update_path "$KILIX_TEMPS_BIN" kilix-temps-bin
    _snapshot_update_path "$KILIX_MEMORY_BIN" kilix-memory-bin
    _snapshot_update_path "$TMUX_TUI_BIN" tmux-tui-bin
    _snapshot_update_path "$TMUX_CLI_BIN" tmux-cli-bin
    _snapshot_update_path "$TMUX_TUI_STAMP" tmux-tui-stamp
    _snapshot_update_path \
        "$KILIX_PTY_BROKER_BUILD" kilix-pty-broker-build
    fsync_update_record "$_UPDATE_TXN_DIR" \
        || die "could not make the update rollback record durable"
    _UPDATE_TXN_ACTIVE=1
    _prepare_recorded_preservation "$KILIX_DIR" kilix \
        || die "could not prepare preserved Kilix paths for update"
    while IFS=$'\t' read -r path key; do
        [ -n "$path" ] || continue
        _prepare_recorded_preservation "$KILIX_DIR/$path" "$key" \
            || die "could not prepare preserved $path paths for update"
    done <"$_UPDATE_TXN_DIR/submodules.participating"
    _prepare_recorded_preservation "$KILIX95_DIR" kilix95 \
        || die "could not prepare preserved Kilix 95 paths for update"
    _prepare_recorded_preservation "$PLEB_ROOT" pleb \
        || die "could not prepare preserved Pleb paths for update"
    _begin_kilix_engine_mutation
    rm -f -- "$legacy_stamp" \
        || die "could not retire the legacy Pleb-side Kilix fork stamp"
}

_restore_transaction_preservations_after_success() {
    local path key target
    target="$(git -C "$KILIX_DIR" rev-parse HEAD 2>/dev/null || echo unknown)"
    _restore_recorded_preservations_after_success "$KILIX_DIR" kilix "$target" \
        || die "Kilix updated, but its preserved operator paths could not be restored"
    while IFS=$'\t' read -r path key; do
        [ -n "$path" ] || continue
        [ -f "$_UPDATE_TXN_DIR/$key.preserve" ] || continue
        target="$(git -C "$KILIX_DIR/$path" rev-parse HEAD 2>/dev/null || echo unknown)"
        _restore_recorded_preservations_after_success \
            "$KILIX_DIR/$path" "$key" "$target" \
            || die "$path updated, but its preserved operator paths could not be restored"
    done <"$_UPDATE_TXN_DIR/submodules.participating"
    if [ -f "$_UPDATE_TXN_DIR/kilix95.preserve" ]; then
        target="$(git -C "$KILIX95_DIR" rev-parse HEAD 2>/dev/null || echo unknown)"
        _restore_recorded_preservations_after_success \
            "$KILIX95_DIR" kilix95 "$target" \
            || die "Kilix 95 updated, but its preserved operator paths could not be restored"
    fi
}

_update_transaction_commit() {
    _commit_kilix_engine_generation \
        || die "could not commit the coherent Kilix generation transaction"
    _UPDATE_TXN_COMMITTED=1
    _UPDATE_TXN_ACTIVE=0
    rm -rf -- "$_UPDATE_TXN_DIR"
    _UPDATE_TXN_DIR=""
}

_do_restart() {
    log "restarting lightdm to relaunch the kiosk on the new kilix ..."
    if command -v systemd-run >/dev/null 2>&1; then
        run_root systemd-run --unit="pleb-restart-lightdm-$$" --collect \
            --description="Restart LightDM for Pleb update" \
            /bin/sh -c '
svc=lightdm
systemctl stop "$svc" --no-block >/dev/null 2>&1 || true
sleep 2
systemctl kill -s KILL "$svc" >/dev/null 2>&1 || true
systemctl reset-failed "$svc" >/dev/null 2>&1 || true
systemctl start "$svc"
'
    else
        warn "systemd-run not found; falling back to blocking LightDM restart"
        run_root systemctl restart lightdm
    fi
}

_pleb_autologin_enabled() {
    [ -f "$AUTOLOGIN_CONF" ] \
        && grep -qsE '^autologin-session=pleb$' "$AUTOLOGIN_CONF"
}

# offer (or, with --yes, force) a kiosk restart to pick up the new engine
_offer_restart() {
    if [ ! -f "$XSESSION_DST" ]; then
        log "kiosk not installed — the new kilix is used next time you launch it."
        return 0
    fi
    if ! _pleb_autologin_enabled && ! kiosk_is_on; then
        log "Pleb is installed but not configured as an active kiosk; not restarting LightDM."
        return 0
    fi
    if [ "${_UPDATE_RESTART:-ask}" = "no" ]; then
        log "not restarting (--no-restart). Apply later with: sudo systemctl restart lightdm"
        return 0
    fi
    if [ "${_UPDATE_RESTART:-ask}" = "yes" ] || [ "${_UPDATE_YES:-0}" = 1 ]; then
        _do_restart
        return
    fi
    if [ ! -t 0 ]; then
        warn "non-interactive; not restarting. Apply with: sudo systemctl restart lightdm"
        return 0
    fi
    ask "Restart the kilix kiosk now to use the new version? [y/N]"
    read -r ans
    case "$ans" in
        y|Y|yes|YES) _do_restart ;;
        *) log "not restarting. Apply later with: sudo systemctl restart lightdm" ;;
    esac
}

_update_kilix95() {
    if [ ! -d "$KILIX95_DIR/.git" ]; then
        if kilix95_required; then
            ensure_kilix95
            _record_created_kilix95_checkout
        else
            log "kilix 95 not installed; skipping optional desktop update"
        fi
        return 0
    fi

    local before after branch current
    if ! git -C "$KILIX95_DIR" config --get remote.origin.url >/dev/null; then
        if kilix95_required; then
            die "required kilix 95 checkout at $KILIX95_DIR has no origin remote"
        fi
        warn "optional kilix 95 checkout at $KILIX95_DIR has no origin; skipping it"
        return 0
    fi
    validate_checkout_origin "$KILIX95_DIR" "$KILIX95_REPO" "kilix 95"
    before="$(git -C "$KILIX95_DIR" rev-parse HEAD 2>/dev/null || echo unknown)"

    if [ -n "$KILIX95_REF" ]; then
        _capture_transaction_checkout_before_move "$KILIX95_DIR" "kilix 95"
        checkout_fetched_ref "$KILIX95_DIR" "$KILIX95_REF" "kilix 95" KILIX95_REF _capture_transaction_checkout_before_move
    else
        branch="${KILIX95_BRANCH:-$(git -C "$KILIX95_DIR" rev-parse --abbrev-ref HEAD 2>/dev/null)}"
        { [ -n "$branch" ] && [ "$branch" != HEAD ]; } || branch=main
        log "fetching latest kilix 95 ($branch) from origin"
        _capture_transaction_checkout_before_move "$KILIX95_DIR" "kilix 95"
        git -C "$KILIX95_DIR" fetch --prune origin "$branch" || die "kilix 95 fetch failed"
        if [ -n "$KILIX95_BRANCH" ]; then
            current="$(git -C "$KILIX95_DIR" rev-parse --abbrev-ref HEAD 2>/dev/null || echo HEAD)"
            if [ "$current" != "$KILIX95_BRANCH" ]; then
                _capture_transaction_checkout_before_move \
                    "$KILIX95_DIR" "kilix 95"
                if git -C "$KILIX95_DIR" show-ref --verify --quiet "refs/heads/$KILIX95_BRANCH"; then
                    git -C "$KILIX95_DIR" checkout "$KILIX95_BRANCH" \
                        || die "could not check out KILIX95_BRANCH=$KILIX95_BRANCH"
                else
                    git -C "$KILIX95_DIR" checkout --track -b "$KILIX95_BRANCH" "origin/$KILIX95_BRANCH" \
                        || die "could not track KILIX95_BRANCH=$KILIX95_BRANCH"
                fi
            fi
        fi
        _capture_transaction_checkout_before_move "$KILIX95_DIR" "kilix 95"
        if ! git -C "$KILIX95_DIR" merge --ff-only "origin/$branch"; then
            warn "cannot fast-forward $branch (local commits/changes in $KILIX95_DIR?)."
            warn "resolve there and re-run 'pleb update'."
            return 1
        fi
    fi

    after="$(git -C "$KILIX95_DIR" rev-parse HEAD 2>/dev/null || echo unknown)"
    if [ "$before" = "$after" ]; then
        log "kilix 95 already up to date at ${after:0:12}."
    else
        log "kilix 95 updated: ${before:0:12} -> ${after:0:12}"
    fi
}

# --- pleb's own checkout ------------------------------------------------------
# `pleb update` updated Kilix, Kilix 95 and the utility closures, and left the
# one component it lives in exactly where it was: two provisioned machines sat
# at the 0.1.7 Pleb commit through many updates, PLEB_REF exported or not. Only
# the root-only OS-layer updater could move it.
#
# The hazard is that the updater runs out of the tree it has to move, so the
# move happens LAST — after the Kilix transaction has committed and every other
# component is coherent. Nothing but the restart offer runs afterwards, so a
# changed lib/ or bin/ can only take effect on the next invocation, which is
# stated in the log rather than left to be discovered. (Git replaces files by
# rename, so the running shell keeps reading the inode it opened either way;
# ordering makes that a decision instead of a detail being relied upon.)
_PLEB_SELF_UPDATE_OK=0

_pleb_self_update_restore() {
    local head="$1" branch="$2" output
    _preserve_before_forced_restore "$PLEB_ROOT" pleb || return 1
    _assert_still_clean "$PLEB_ROOT" pleb || return 1
    # Never recurse, for the reason given in _restore_checkout_position.
    if [ -n "$branch" ]; then
        output="$(git -C "$PLEB_ROOT" -c submodule.recurse=false \
                checkout -f "$branch" 2>&1 \
            && git -C "$PLEB_ROOT" -c submodule.recurse=false \
                reset --hard "$head" 2>&1)"
    else
        output="$(git -C "$PLEB_ROOT" -c submodule.recurse=false \
                checkout -f --detach "$head" 2>&1 \
            && git -C "$PLEB_ROOT" -c submodule.recurse=false \
                reset --hard "$head" 2>&1)"
    fi || {
        err "could not return pleb to $head; git said: $(printf '%s\n' "$output" | tail -n 3 | tr '\n' ' ')"
        return 1
    }
}

# Everything the next `pleb` invocation needs before the moved checkout is
# accepted: the whole sourced set must parse, and the CLI must answer a command
# that touches every module. A tree that fails this is put back.
_pleb_self_update_runnable() {
    local script
    for script in bin/pleb bin/pleb-session lib/common.sh lib/storage.sh \
            lib/install.sh lib/autologin.sh lib/test.sh lib/kiosk.sh \
            lib/preserve.sh lib/update.sh; do
        if [ ! -f "$PLEB_ROOT/$script" ] || [ -L "$PLEB_ROOT/$script" ]; then
            warn "updated pleb is missing $script"
            return 1
        fi
        bash -n "$PLEB_ROOT/$script" \
            || { warn "updated pleb does not parse: $script"; return 1; }
    done
    [ -x "$PLEB_ROOT/bin/pleb" ] \
        || { warn "updated pleb has no executable bin/pleb"; return 1; }
    "$PLEB_ROOT/bin/pleb" version >/dev/null 2>&1 \
        || { warn "updated pleb could not answer 'pleb version'"; return 1; }
}

# Decide and validate up front. Local paths are preserved transactionally in
# _update_transaction_begin, after every participating checkout has passed its
# identity checks and before any of them is moved.
_prepare_pleb_self_update() {
    _require_managed_source_layout
    local root configured
    _PLEB_SELF_UPDATE_OK=0
    case "${PLEB_SELF_UPDATE:-1}" in
        1|yes|true|on) ;;
        0|no|false|off)
            log "pleb self-update disabled (PLEB_SELF_UPDATE=$PLEB_SELF_UPDATE)"
            return 0 ;;
        *) die "invalid PLEB_SELF_UPDATE=$PLEB_SELF_UPDATE (expected 0/1)" ;;
    esac
    if [ "${_UPDATE_LOCK_BORROWED:-0}" = 1 ] \
            && [ "${PLEB_RELEASE_HOP_APPLY:-0}" != 1 ]; then
        # The OS-layer updater hands its lock down and has already put the Pleb
        # checkout where its own release manifest wants it. Moving it underneath
        # the process that launched us would undo that run's pinned checkout.
        # A standalone named-release hop instead borrows the Pleb parent's
        # lock; that parent has selected pins but has not moved this checkout.
        log "an outer updater owns the pleb checkout for this run; not self-updating"
        return 0
    fi
    if [ ! -d "$PLEB_ROOT/.git" ]; then
        log "pleb at $PLEB_ROOT is not a git checkout; not self-updating"
        return 0
    fi
    root="$(cd "$PLEB_ROOT" && pwd -P)" \
        || die "could not resolve the running pleb checkout: $PLEB_ROOT"
    configured="$(cd "$PLEB_DIR" 2>/dev/null && pwd -P)" || configured=""
    if [ -n "$configured" ] && [ "$configured" != "$root" ]; then
        warn "PLEB_DIR=$PLEB_DIR is not the checkout this pleb runs from ($root)"
        warn "not self-updating; run 'pleb update' from $PLEB_DIR instead"
        return 0
    fi
    require_immutable_ref "$PLEB_REF" "$PLEB_ALLOW_MUTABLE_REF" \
        PLEB_REF PLEB_ALLOW_MUTABLE_REF
    validate_checkout_origin "$PLEB_ROOT" "$PLEB_REPO" "pleb"
    _PLEB_SELF_UPDATE_OK=1
}

# Standalone update delivery also calls this with --local-ref.
# shellcheck disable=SC2120
_update_pleb_self() {
    local before after branch current version local_ref="${1:-}"
    case "$local_ref" in ''|--local-ref) ;; *) die "invalid Pleb self-update mode" ;; esac
    [ "$_PLEB_SELF_UPDATE_OK" = 1 ] || return 0
    before="$(git -C "$PLEB_ROOT" rev-parse --verify HEAD 2>/dev/null)" \
        || die "could not read the current pleb commit at $PLEB_ROOT"
    branch="$(git -C "$PLEB_ROOT" symbolic-ref --quiet --short HEAD 2>/dev/null || true)"
    _PLEB_SELF_BEFORE="$before"
    _PLEB_SELF_BRANCH="$branch"
    _PLEB_SELF_MOVE_ACTIVE=1

    if [ -n "$PLEB_REF" ]; then
        _preserve_pleb_before_move
        if [ "$local_ref" = --local-ref ]; then
            # The target selector has already fetched and validated this exact
            # commit. Its standalone bootstrap must also work with --offline.
            [ "$(git -C "$PLEB_ROOT" rev-parse --verify "$PLEB_REF^{commit}" 2>/dev/null)" = "$PLEB_REF" ] \
                || die "selected Pleb ref is not present locally: $PLEB_REF"
            _assert_still_clean "$PLEB_ROOT" pleb \
                || die "pleb checkout changed while its preservation snapshot was prepared"
            git -C "$PLEB_ROOT" -c submodule.recurse=false checkout --detach "$PLEB_REF" \
                || die "could not check out selected Pleb ref $PLEB_REF"
        else
            checkout_fetched_ref "$PLEB_ROOT" "$PLEB_REF" "pleb" PLEB_REF _preserve_pleb_before_move
        fi
    else
        current="${PLEB_BRANCH:-$branch}"
        { [ -n "$current" ] && [ "$current" != HEAD ]; } || current=main
        log "fetching latest pleb ($current) from origin"
        _preserve_pleb_before_move
        git -C "$PLEB_ROOT" fetch --prune origin "$current" || die "pleb fetch failed"
        if [ -n "$PLEB_BRANCH" ] && [ "$branch" != "$PLEB_BRANCH" ]; then
            _preserve_pleb_before_move
            _assert_still_clean "$PLEB_ROOT" pleb \
                || die "pleb checkout changed while its preservation snapshot was prepared"
            if git -C "$PLEB_ROOT" show-ref --verify --quiet "refs/heads/$PLEB_BRANCH"; then
                git -C "$PLEB_ROOT" -c submodule.recurse=false checkout "$PLEB_BRANCH" \
                    || die "could not check out PLEB_BRANCH=$PLEB_BRANCH"
            else
                git -C "$PLEB_ROOT" -c submodule.recurse=false \
                    checkout --track -b "$PLEB_BRANCH" "origin/$PLEB_BRANCH" \
                    || die "could not track PLEB_BRANCH=$PLEB_BRANCH"
            fi
        fi
        # fast-forward only — never silently clobber local work
        _preserve_pleb_before_move
        _assert_still_clean "$PLEB_ROOT" pleb \
            || die "pleb checkout changed while its preservation snapshot was prepared"
        if ! git -C "$PLEB_ROOT" merge --ff-only "origin/$current"; then
            warn "cannot fast-forward $current (local commits/changes in $PLEB_ROOT?)."
            die "resolve there and re-run 'pleb update'."
        fi
    fi

    after="$(git -C "$PLEB_ROOT" rev-parse --verify HEAD 2>/dev/null)" \
        || die "could not verify the pleb commit after checkout"
    if [ "$before" = "$after" ]; then
        log "pleb already up to date at ${after:0:12}."
        _restore_pleb_preservations_after_success "$after"
        _PLEB_SELF_MOVE_ACTIVE=0
        return 0
    fi
    if ! _pleb_self_update_runnable; then
        warn "the updated pleb checkout is not runnable; restoring ${before:0:12}"
        _pleb_self_update_restore "$before" "$branch" \
            || die "could not restore pleb ${before:0:12}; preserved checkout data remains under $(_pleb_preservation_root)"
        if [ -n "$_PLEB_SELF_INITIAL_PRESERVE" ]; then
            restore_preserved_checkout "$PLEB_ROOT" \
                "$_PLEB_SELF_INITIAL_PRESERVE" rollback "$before" \
                || die "pleb commit was restored, but operator paths remain only at $_PLEB_SELF_INITIAL_PRESERVE"
        fi
        _PLEB_SELF_MOVE_ACTIVE=0
        die "pleb self-update rolled back; the previous version is still installed"
    fi
    _restore_pleb_preservations_after_success "$after"
    _PLEB_SELF_MOVE_ACTIVE=0
    version="$(cat "$PLEB_ROOT/VERSION" 2>/dev/null || echo unknown)"
    log "pleb updated: ${before:0:12} -> ${after:0:12} (VERSION $version)"
    log "the new pleb runs from the next 'pleb' command onwards."
    if [ -x "$SESSION_BIN_DST" ] && ! cmp -s "$PLEB_BIN_SRC" "$SESSION_BIN_DST"; then
        warn "the installed session launcher $SESSION_BIN_DST is now stale"
        warn "publish it with 'pleb install' before the next login"
        warn "run it as your desktop user; it asks for root only where it needs it"
    fi
}

_preserve_only_update_checkouts() {
    local map path key count=0 failed=""
    map="$(mktemp "$PLEB_STATE_HOME/preserve-only-submodules.XXXXXX")" \
        || die "could not create the preserve-only checkout map"
    _write_kilix_submodule_map worktree "$map" \
        || { rm -f -- "$map"; die "could not derive Kilix submodules for preservation"; }
    preserve_checkout "$KILIX_DIR" kilix preserve-only \
        || { rm -f -- "$map"; die "could not preserve Kilix checkout"; }
    [ -z "$PLEB_PRESERVE_RESULT" ] || ((count += 1))
    while IFS=$'\t' read -r path key; do
        [ -n "$path" ] || continue
        git -C "$KILIX_DIR/$path" rev-parse --is-inside-work-tree >/dev/null 2>&1 \
            || continue
        if ! preserve_checkout "$KILIX_DIR/$path" "$key" preserve-only; then
            failed="$path"
            break
        fi
        [ -z "$PLEB_PRESERVE_RESULT" ] || ((count += 1))
    done <"$map"
    rm -f -- "$map"
    [ -z "$failed" ] || die "could not preserve $failed checkout"
    if [ -d "$KILIX95_DIR/.git" ]; then
        preserve_checkout "$KILIX95_DIR" kilix95 preserve-only \
            || die "could not preserve Kilix 95 checkout"
        [ -z "$PLEB_PRESERVE_RESULT" ] || ((count += 1))
    fi
    if [ -d "$PLEB_ROOT/.git" ]; then
        preserve_checkout "$PLEB_ROOT" pleb preserve-only \
            || die "could not preserve Pleb checkout"
        [ -z "$PLEB_PRESERVE_RESULT" ] || ((count += 1))
    fi
    if [ "$count" = 0 ]; then
        log "no modified or untracked checkout paths needed preservation"
    else
        log "preserve-only completed: $count checkout snapshot(s) verified"
    fi
}

_kilix_go_ok_script() {
    cat <<'EOF'
command -v go >/dev/null 2>&1 || exit 1
min="${PLEBIAN_OS_KILIX_GO_MIN_VERSION:-1.26}"
exact="${PLEBIAN_OS_KILIX_GO_VERSION:-}"
expected_arch="${PLEBIAN_OS_KILIX_GO_EXPECTED_ARCH:-}"
expected_sha="${PLEBIAN_OS_KILIX_GO_EXPECTED_SHA:-}"
ver="$(go version 2>/dev/null | awk '{print $3}' | sed 's/^go//')"
[ -n "$ver" ] || exit 1
if [ -n "$exact" ]; then
    case "$exact" in go*) ;; *) exact="go$exact" ;; esac
    [ "go$ver" = "$exact" ] || exit 1
fi
if [ -n "$expected_sha" ]; then
    root="$(go env GOROOT 2>/dev/null)"
    binary="$(readlink -f "$(command -v go)" 2>/dev/null)"
    stamp="$root/.pleb-source"
    [ -n "$root" ] && [ "$binary" = "$root/bin/go" ] && [ -f "$stamp" ] || exit 1
    for trusted_path in "$root" "$root/bin" "$binary" "$stamp"; do
        owner="$(stat -c '%u' "$trusted_path" 2>/dev/null)" || exit 1
        mode="$(stat -c '%a' "$trusted_path" 2>/dev/null)" || exit 1
        [ "$owner" = 0 ] && (( (8#$mode & 8#22) == 0 )) || exit 1
    done
    source_version="$(sed -n '1p' "$stamp")"
    source_arch="$(sed -n '2p' "$stamp")"
    source_sha="$(sed -n '3p' "$stamp")"
    [ "$source_version" = "$exact" ] \
        && [ "$source_arch" = "$expected_arch" ] \
        && [ "${source_sha,,}" = "${expected_sha,,}" ] || exit 1
fi
awk -v have="$ver" -v min="$min" '
function splitver(v, out) {
    gsub(/[^0-9.].*$/, "", v)
    n = split(v, parts, ".")
    out[1] = (n >= 1 && parts[1] != "") ? parts[1] + 0 : 0
    out[2] = (n >= 2 && parts[2] != "") ? parts[2] + 0 : 0
    out[3] = (n >= 3 && parts[3] != "") ? parts[3] + 0 : 0
}
BEGIN {
    splitver(have, h)
    splitver(min, m)
    for (i = 1; i <= 3; i++) {
        if (h[i] > m[i]) exit 0
        if (h[i] < m[i]) exit 1
    }
    exit 0
}'
EOF
}

_ensure_go_for_kilix_build() {
    if [ -n "${PLEBIAN_OS_KILIX_GO_DEBIAN_VERSION:-}" ]; then
        # Closure files are sourced, not exported. Pass the exact package file
        # pins on, so the installer can fetch the same bytes from snapshot or
        # the release mirror once trixie-backports has replaced the upload.
        local -a debian_go_files=()
        local debian_go_key
        for debian_go_key in PLEBIAN_OS_KILIX_GO_DEB_AMD64_FILE \
                PLEBIAN_OS_KILIX_GO_DEB_AMD64_BYTES PLEBIAN_OS_KILIX_GO_DEB_AMD64_SHA256 \
                PLEBIAN_OS_KILIX_GO_DEB_SRC_FILE PLEBIAN_OS_KILIX_GO_DEB_SRC_BYTES \
                PLEBIAN_OS_KILIX_GO_DEB_SRC_SHA256 PLEBIAN_OS_KILIX_GO_DEB_SNAPSHOT \
                PLEBIAN_OS_KILIX_GO_DEB_MIRROR_URL; do
            debian_go_files+=("$debian_go_key=${!debian_go_key:-}")
        done
        env "${debian_go_files[@]}" "$PLEB_ROOT/scripts/install-debian-go.sh" \
            "${PLEBIAN_OS_KILIX_GO_VERSION:-}" "$PLEBIAN_OS_KILIX_GO_DEBIAN_VERSION" \
            || die "Debian Go toolchain install failed"
        export PATH="/usr/lib/go-1.27/bin:$PATH" GOROOT=/usr/lib/go-1.27 GOENV=off GOTOOLCHAIN=local
        return 0
    fi
    local min="${PLEBIAN_OS_KILIX_GO_MIN_VERSION:-1.26}"
    local version="${PLEBIAN_OS_KILIX_GO_VERSION:-}" arch sha=""
    local go_bin_dir="${GO_BIN_DIR:-/usr/local/bin}"
    case "$(uname -m)" in
        x86_64|amd64)
            arch=amd64
            sha="${PLEBIAN_OS_KILIX_GO_SHA256_AMD64:-}"
            ;;
        aarch64|arm64)
            arch=arm64
            sha="${PLEBIAN_OS_KILIX_GO_SHA256_ARM64:-}"
            ;;
        *) die "unsupported architecture for Go toolchain: $(uname -m)" ;;
    esac
    if [ -n "$version" ] && ! [[ "$version" =~ ^(go)?[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        die "invalid PLEBIAN_OS_KILIX_GO_VERSION=$version (expected an exact release such as go1.26.4)"
    fi
    if [ -n "$version" ] && [ -z "$sha" ]; then
        die "PLEBIAN_OS_KILIX_GO_VERSION=$version requires PLEBIAN_OS_KILIX_GO_SHA256_${arch^^}"
    fi
    if [ -z "$version" ] && [ -n "$sha" ]; then
        die "a pinned Go checksum requires PLEBIAN_OS_KILIX_GO_VERSION"
    fi
    if [ -n "$sha" ]; then
        sha="${sha,,}"
        [[ "$sha" =~ ^[0-9a-f]{64}$ ]] \
            || die "invalid PLEBIAN_OS_KILIX_GO_SHA256_${arch^^} (expected 64 hexadecimal characters)"
    fi
    export PATH="$go_bin_dir:$PATH"
    if env \
        "PLEBIAN_OS_KILIX_GO_MIN_VERSION=$min" \
        "PLEBIAN_OS_KILIX_GO_VERSION=$version" \
        "PLEBIAN_OS_KILIX_GO_EXPECTED_ARCH=$arch" \
        "PLEBIAN_OS_KILIX_GO_EXPECTED_SHA=$sha" \
        bash -c "$(_kilix_go_ok_script)"; then
        log "Go is ready: $(go version 2>/dev/null || true)"
        return 0
    fi
    [ -x "$PLEB_ROOT/scripts/install-go.sh" ] \
        || die "Go >= $min is required to rebuild the kilix fork, and $PLEB_ROOT/scripts/install-go.sh is missing"
    if [ -n "$version" ]; then
        log "installing pinned Go $version ($arch) for kilix fork build"
    else
        log "installing/upgrading Go for kilix fork build (>= $min; latest stable)"
    fi
    GO_VERSION="$version" GO_SHA256="$sha" "$PLEB_ROOT/scripts/install-go.sh" all \
        || die "Go toolchain install failed"
    hash -r 2>/dev/null || true
    env "PLEBIAN_OS_KILIX_GO_MIN_VERSION=$min" \
        "PLEBIAN_OS_KILIX_GO_VERSION=$version" \
        "PLEBIAN_OS_KILIX_GO_EXPECTED_ARCH=$arch" \
        "PLEBIAN_OS_KILIX_GO_EXPECTED_SHA=$sha" \
        bash -c "$(_kilix_go_ok_script)" \
        || die "Go toolchain is still below $min after install"
    log "Go is ready: $(go version 2>/dev/null || true)"
}

_kilix_fork_enabled() {
    case "${PLEBIAN_OS_BUILD_KILIX_FORK:-1}" in
        1|yes|true|on) return 0 ;;
        0|no|false|off) return 1 ;;
        *) die "invalid PLEBIAN_OS_BUILD_KILIX_FORK=${PLEBIAN_OS_BUILD_KILIX_FORK:-} (expected 0/1)" ;;
    esac
}

_kilix_fork_head() {
    git -C "$KILIX_DIR/src" rev-parse HEAD 2>/dev/null || true
}

_kilix_fork_root() {
    (cd "$KILIX_DIR" && pwd -P) 2>/dev/null || true
}

_kilix_fork_stamp() {
    # Kilix owns the build generation and its source-ref stamp.  Keep one
    # canonical record beside Kilix's other state so every updater snapshots,
    # restores, and validates the same file.
    printf '%s\n' "$KILIX_STATE_DIRECTORY/fork-built-ref"
}

_kilix_current_generation_is_canonical() {
    local current="$KILIX_BUILD_DIRECTORY/current" target generation owner
    [ -L "$current" ] || return 1
    target="$(readlink -- "$current")" || return 1
    [[ "$target" =~ ^generations/build\.[A-Za-z0-9]+$ ]] || return 1
    _kilix_generation_target_is_contained "$target" || return 1
    generation="$KILIX_BUILD_DIRECTORY/$target"
    owner="$(stat -c '%u' -- "$generation" 2>/dev/null)" || return 1
    [ "$owner" = "$(id -u)" ]
}

_kilix_probe_launcher() {
    if command -v timeout >/dev/null 2>&1; then
        timeout 15 "$1" --version >/dev/null 2>&1
    else
        "$1" --version >/dev/null 2>&1
    fi
}

_validate_kilix_fork_stamp_path() {
    local storage state normalized stamp owner mode links
    _validate_kilix_storage_root
    storage="$KILIX_STORAGE_HOME"
    state="$(_pleb_storage_path_input "$KILIX_STATE_DIRECTORY")"
    normalized="$(_pleb_normalized_absolute_path "$state")"
    [ "$state" = "$normalized" ] \
        || die "KILIX_STATE_DIRECTORY must be a normalized absolute path: $KILIX_STATE_DIRECTORY"
    case "$normalized" in
        "$storage"/*) ;;
        *) die "KILIX_STATE_DIRECTORY must be below KILIX_STORAGE_HOME: $normalized" ;;
    esac
    case "$normalized" in
        /|/bin|/boot|/dev|/etc|/home|/lib|/lib64|/media|/mnt|/opt|/proc|/root|/run|/sbin|/srv|/sys|/tmp|/usr|/var)
            die "KILIX_STATE_DIRECTORY is too broad for Kilix writable state: $normalized" ;;
    esac
    _pleb_assert_safe_storage_parent_chain "$state"
    _pleb_assert_no_symlink_components "$state"
    if [ -e "$state" ] || [ -L "$state" ]; then
        [ -d "$state" ] && [ ! -L "$state" ] \
            || die "refusing unsafe KILIX_STATE_DIRECTORY: $state"
        owner="$(stat -c '%u' "$state" 2>/dev/null)" \
            || die "could not inspect KILIX_STATE_DIRECTORY: $state"
        [ "$owner" = "$(id -u)" ] \
            || die "KILIX_STATE_DIRECTORY is not owned by the current user: $state"
        mode="$(stat -c '%a' "$state" 2>/dev/null)" \
            || die "could not inspect KILIX_STATE_DIRECTORY mode: $state"
        [ "$mode" = 700 ] \
            || die "KILIX_STATE_DIRECTORY must have mode 0700: $state"
    fi
    stamp="$state/fork-built-ref"
    if [ -e "$stamp" ] || [ -L "$stamp" ]; then
        [ -f "$stamp" ] && [ ! -L "$stamp" ] \
            || die "refusing unsafe Kilix fork-build stamp: $stamp"
        owner="$(stat -c '%u' "$stamp" 2>/dev/null)" \
            || die "could not inspect Kilix fork-build stamp: $stamp"
        [ "$owner" = "$(id -u)" ] \
            || die "Kilix fork-build stamp is not owned by the current user: $stamp"
        mode="$(stat -c '%a' "$stamp" 2>/dev/null)" \
            || die "could not inspect Kilix fork-build stamp mode: $stamp"
        [ "$mode" = 600 ] \
            || die "Kilix fork-build stamp must have mode 0600: $stamp"
        links="$(stat -c '%h' "$stamp" 2>/dev/null)" \
            || die "could not inspect Kilix fork-build stamp links: $stamp"
        [ "$links" = 1 ] \
            || die "Kilix fork-build stamp must have exactly one hard link: $stamp"
    fi
    KILIX_STATE_DIRECTORY="$normalized"
}

_validate_legacy_kilix_fork_stamp_path() {
    local stamp="$PLEB_STATE_HOME/kilix-fork-built-ref" owner links
    if [ -e "$stamp" ] || [ -L "$stamp" ]; then
        [ -f "$stamp" ] && [ ! -L "$stamp" ] \
            || die "refusing unsafe legacy Pleb-side Kilix fork stamp: $stamp"
        owner="$(stat -c '%u' -- "$stamp" 2>/dev/null)" \
            || die "could not inspect legacy Pleb-side Kilix fork stamp: $stamp"
        [ "$owner" = "$(id -u)" ] \
            || die "legacy Pleb-side Kilix fork stamp is not owned by the current user: $stamp"
        links="$(stat -c '%h' -- "$stamp" 2>/dev/null)" \
            || die "could not inspect legacy Pleb-side Kilix fork stamp links: $stamp"
        [ "$links" = 1 ] \
            || die "legacy Pleb-side Kilix fork stamp must have exactly one hard link: $stamp"
    fi
}

_kilix_fork_needs_rebuild() {
    _kilix_fork_enabled || return 1
    local fork kitten root head source_id_path stamp which_output engine
    fork="$KILIX_BUILD_DIRECTORY/current/src/kitty/launcher/kitty"
    kitten="$KILIX_BUILD_DIRECTORY/current/src/kitty/launcher/kitten"
    _kilix_current_generation_is_canonical || return 0
    [ -f "$fork" ] && [ ! -L "$fork" ] && [ -x "$fork" ] \
        && [ -f "$kitten" ] && [ ! -L "$kitten" ] && [ -x "$kitten" ] \
        || return 0
    _kilix_probe_launcher "$kitten" || return 0
    root="$(_kilix_fork_root)"
    [ -n "$root" ] || return 0
    head="$(_kilix_fork_head)"
    [ -n "$head" ] || return 0
    source_id_path="$KILIX_BUILD_DIRECTORY/current/source-id"
    [ -f "$source_id_path" ] && [ ! -L "$source_id_path" ] \
        || return 0
    printf '%s\n' "$head" | cmp -s - "$source_id_path" || return 0
    stamp="$(_kilix_fork_stamp)"
    [ -f "$stamp" ] && [ ! -L "$stamp" ] || return 0
    printf '%s\t%s\n' "$root" "$head" | cmp -s - "$stamp" || return 0
    which_output="$("$KILIX_DIR/kilix" --which 2>/dev/null)" || return 0
    engine="${which_output%%$'\n'*}"
    [ "$engine" = "$fork" ] || return 0
    return 1
}

_verify_kilix_fork_build() {
    local fork kitten root head source_id_path stamp which_output engine
    _validate_kilix_fork_stamp_path
    fork="$KILIX_BUILD_DIRECTORY/current/src/kitty/launcher/kitty"
    kitten="$KILIX_BUILD_DIRECTORY/current/src/kitty/launcher/kitten"
    _kilix_current_generation_is_canonical \
        || die "kilix fork build did not publish a contained current generation"
    [ -f "$fork" ] && [ ! -L "$fork" ] && [ -x "$fork" ] \
        || die "kilix fork build did not produce a regular executable $fork"
    [ -f "$kitten" ] && [ ! -L "$kitten" ] && [ -x "$kitten" ] \
        || die "kilix fork build did not produce a regular executable $kitten"
    _kilix_probe_launcher "$kitten" \
        || die "kilix fork kitten failed its post-build version probe"
    root="$(_kilix_fork_root)"
    [ -n "$root" ] || die "kilix fork build has no physical checkout root to verify"
    head="$(_kilix_fork_head)"
    [ -n "$head" ] || die "kilix fork build has no source commit to verify"
    source_id_path="$KILIX_BUILD_DIRECTORY/current/source-id"
    [ -f "$source_id_path" ] && [ ! -L "$source_id_path" ] \
        || die "kilix fork build has no safe source-id: $source_id_path"
    printf '%s\n' "$head" | cmp -s - "$source_id_path" \
        || die "kilix fork build source-id does not match the source checkout"
    stamp="$(_kilix_fork_stamp)"
    printf '%s\t%s\n' "$root" "$head" | cmp -s - "$stamp" \
        || die "kilix fork build stamp does not match the source checkout"
    which_output="$("$KILIX_DIR/kilix" --which 2>/dev/null)" \
        || die "kilix fork engine failed its post-build version probe"
    engine="${which_output%%$'\n'*}"
    [ "$engine" = "$fork" ] \
        || die "kilix is not using the fork engine after build (got: ${engine:-<empty>})"
}

_rebuild_kilix_fork() {
    _kilix_fork_enabled || {
        warn "PLEBIAN_OS_BUILD_KILIX_FORK=${PLEBIAN_OS_BUILD_KILIX_FORK:-0}; not rebuilding the fork"
        return 0
    }
    _ensure_go_for_kilix_build
    # Kilix owns the complete build manifest. Its verifier must be the final
    # dependency gate before --build (including pkg-config's libxxhash check).
    ensure_kilix_build_deps
    log "rebuilding kilix fork (go $(go version 2>/dev/null | awk '{print $3}')) ..."
    "$KILIX_DIR/kilix" --build || die "kilix fork build failed"
    _verify_kilix_fork_build
    log "fork rebuilt."
}

do_update() {
    _UPDATE_YES=0
    _UPDATE_RESTART=ask
    local preserve_only=0 hop_mode="" hop_target="" hop_tag="" dry_run=0 offline=0
    _PLEB_SELF_INITIAL_PRESERVE=""
    _PLEB_SELF_PRESERVATIONS=()
    _PLEB_SELF_MOVE_ACTIVE=0
    _PLEB_SELF_BEFORE=""
    _PLEB_SELF_BRANCH=""
    while [ $# -gt 0 ]; do
        case "$1" in
            -y|--yes) _UPDATE_YES=1; shift ;;
            --no-restart) _UPDATE_RESTART=no; shift ;;
            --restart) _UPDATE_RESTART=yes; shift ;;
            --preserve-only) preserve_only=1; shift ;;
            --to)
                [ "$#" -ge 2 ] || die "--to needs a release identifier"
                [ -z "$hop_mode" ] || die "select only one of --to, --latest, --show, or --rollback"
                hop_mode=to; hop_target="$2"; shift 2 ;;
            --to=*)
                [ -z "$hop_mode" ] || die "select only one of --to, --latest, --show, or --rollback"
                hop_mode=to; hop_target="${1#--to=}"; shift ;;
            --latest|--show|--rollback)
                [ -z "$hop_mode" ] || die "select only one of --to, --latest, --show, or --rollback"
                hop_mode="${1#--}"; shift ;;
            --release-tag)
                [ "$#" -ge 2 ] && [ -z "$hop_tag" ] || die "--release-tag needs one tag"
                [ -n "$2" ] || die "--release-tag cannot be empty"
                hop_tag="$2"; shift 2 ;;
            --release-tag=*)
                [ -z "$hop_tag" ] || die "--release-tag may only appear once"
                hop_tag="${1#--release-tag=}"; [ -n "$hop_tag" ] || die "--release-tag cannot be empty"; shift ;;
            --dry-run) dry_run=1; shift ;;
            --offline) offline=1; shift ;;
            -h|--help)
                info "usage: pleb update [-y|--yes] [--no-restart|--restart] [--preserve-only]"
                info "       pleb update --show"
                info "       pleb update (--to X.Y.Z | --latest) [--dry-run] [--offline] [-y] [--no-restart|--restart]"
                info "       pleb update --to X.Y.Z --release-tag vX.Y.Z-rcN [--dry-run] [--offline] [-y] [--no-restart|--restart]"
                info "       pleb update --rollback [-y] [--no-restart|--restart]"
                return 0 ;;
            *) die "unknown update option: $1" ;;
        esac
    done

    if [ -n "$hop_tag" ]; then
        [ "$hop_mode" = to ] || die "--release-tag requires --to"
        _pleb_valid_release_tag "$hop_target" "$hop_tag" || die "--release-tag must match --to (stable or numbered RC)"
    fi
    if [ "$hop_mode" = show ]; then
        [ "$dry_run" = 0 ] && [ "$offline" = 0 ] && [ "$preserve_only" = 0 ] \
            || die "--show cannot be combined with --dry-run, --offline, or --preserve-only"
        pleb_release_show
        return 0
    fi
    if [ -n "$hop_mode" ]; then
        [ "$preserve_only" = 0 ] || die "--preserve-only cannot be combined with a release hop"
        if [ "$hop_mode" = rollback ]; then
            [ "$dry_run" = 0 ] && [ "$offline" = 0 ] \
                || die "--rollback cannot be combined with --dry-run or --offline"
        elif [ "$hop_mode" != to ] && [ "$hop_mode" != latest ]; then
            die "invalid release-hop mode: $hop_mode"
        fi
        _require_managed_source_layout
        if [ "$dry_run" = 1 ]; then
            pleb_release_hop "$hop_mode" "$hop_target" "$dry_run" "$offline" \
                "$_UPDATE_YES" "$_UPDATE_RESTART" "$hop_tag"
            return 0
        fi
        _acquire_update_lock
        PLEB_UPDATE_LOCK_FD="$_UPDATE_LOCK_FD"
        export PLEB_UPDATE_LOCK_FD
        pleb_release_hop "$hop_mode" "$hop_target" "$dry_run" "$offline" \
            "$_UPDATE_YES" "$_UPDATE_RESTART" "$hop_tag"
        _release_update_lock
        trap - EXIT INT TERM
        return 0
    fi
    [ "$dry_run" = 0 ] && [ "$offline" = 0 ] \
        || die "--dry-run and --offline require --to or --latest"

    _require_managed_source_layout
    _acquire_update_lock
    [ -d "$KILIX_DIR/.git" ] || die "no kilix git checkout at $KILIX_DIR — run 'pleb install' first"
    validate_checkout_origin "$KILIX_DIR" "$KILIX_REPO" "kilix"
    if [ -d "$KILIX95_DIR/.git" ]; then
        validate_checkout_origin "$KILIX95_DIR" "$KILIX95_REPO" "kilix 95"
    fi
    if [ "$preserve_only" = 1 ]; then
        _preserve_only_update_checkouts
        _release_update_lock
        trap - EXIT INT TERM
        return 0
    fi
    if [ "${PLEB_RELEASE_HOP_APPLY:-0}" != 1 ]; then
        pleb_recover_incomplete_release_hop
        pleb_report_newer_release
    fi
    require_immutable_ref "$KILIX_REF" "$KILIX_ALLOW_MUTABLE_REF" \
        KILIX_REF KILIX_ALLOW_MUTABLE_REF
    require_immutable_ref "$KILIX95_REF" "$KILIX95_ALLOW_MUTABLE_REF" \
        KILIX95_REF KILIX95_ALLOW_MUTABLE_REF
    if [ ! -d "$KILIX95_DIR/.git" ] && kilix95_required \
        && [ -z "$KILIX95_REF" ] && [ "$KILIX95_ALLOW_UNPINNED_INSTALL" != 1 ]; then
        die "automatic Kilix 95 install requires an immutable KILIX95_REF commit SHA (set KILIX95_ALLOW_UNPINNED_INSTALL=1 only to allow an unpinned clone)"
    fi
    if [ -d "$KILIX95_DIR/.git" ]; then
        :
    fi
    # Decided here, applied last: a bad PLEB_REF or a dirty Pleb tree must stop
    # the run before any component moves, not after all of them have.
    _prepare_pleb_self_update
    local before after branch current src_before src_after current_engine
    # track the checked-out branch (or KILIX_BRANCH if set); fall back to main
    branch="${KILIX_BRANCH:-$(git -C "$KILIX_DIR" rev-parse --abbrev-ref HEAD 2>/dev/null)}"
    { [ -n "$branch" ] && [ "$branch" != HEAD ]; } || branch=main
    before="$(git -C "$KILIX_DIR" rev-parse HEAD 2>/dev/null || echo unknown)"
    src_before="$(git -C "$KILIX_DIR/src" rev-parse HEAD 2>/dev/null || echo none)"
    _update_transaction_begin

    if [ -n "$KILIX_REF" ]; then
        _capture_transaction_checkout_before_move "$KILIX_DIR" kilix
        checkout_fetched_ref "$KILIX_DIR" "$KILIX_REF" "kilix" KILIX_REF _capture_transaction_checkout_before_move
    else
        log "fetching latest kilix ($branch) from origin"
        _capture_transaction_checkout_before_move "$KILIX_DIR" kilix
        git -C "$KILIX_DIR" fetch --prune origin "$branch" || die "git fetch failed"
        if [ -n "$KILIX_BRANCH" ]; then
            current="$(git -C "$KILIX_DIR" rev-parse --abbrev-ref HEAD 2>/dev/null || echo HEAD)"
            if [ "$current" != "$KILIX_BRANCH" ]; then
                _capture_transaction_checkout_before_move "$KILIX_DIR" kilix
                if git -C "$KILIX_DIR" show-ref --verify --quiet "refs/heads/$KILIX_BRANCH"; then
                    git -C "$KILIX_DIR" -c submodule.recurse=false \
                        checkout "$KILIX_BRANCH" \
                        || die "could not check out KILIX_BRANCH=$KILIX_BRANCH"
                else
                    git -C "$KILIX_DIR" -c submodule.recurse=false \
                        checkout --track -b "$KILIX_BRANCH" "origin/$KILIX_BRANCH" \
                        || die "could not track KILIX_BRANCH=$KILIX_BRANCH"
                fi
            fi
        fi

        # fast-forward only — never silently clobber local work
        _capture_transaction_checkout_before_move "$KILIX_DIR" kilix
        if ! git -C "$KILIX_DIR" -c submodule.recurse=false \
                merge --ff-only "origin/$branch"; then
            warn "cannot fast-forward $branch (local commits/changes in $KILIX_DIR?)."
            die "resolve there and re-run 'pleb update'."
        fi
    fi
    reconcile_kilix_submodules "$KILIX_DIR"
    after="$(git -C "$KILIX_DIR" rev-parse HEAD 2>/dev/null || echo unknown)"
    src_after="$(git -C "$KILIX_DIR/src" rev-parse HEAD 2>/dev/null || echo none)"

    if [ "$before" = "$after" ] && [ "$src_before" = "$src_after" ]; then
        log "kilix already up to date at ${after:0:12}."
    else
        log "kilix updated: ${before:0:12}/${src_before:0:12} -> ${after:0:12}/${src_after:0:12}"
    fi

    # Bring the provider to its requested commit before building the engine. If
    # either component or the build fails, the EXIT transaction restores both.
    _update_kilix95 || die "kilix 95 update failed"

    # The selected Kilix commit transitively pins the unified utility checkout.
    # Reconcile its launchers inside the engine/provider update transaction.
    install_kilix_tui_utils
    install_tmux_tui
    install_pty_broker
    # Voice is installed lazily and stays that way; this only moves a closure
    # that is already there onto the commit the new Kilix pins.
    refresh_kilix_voice

    if _kilix_fork_enabled; then
        # Reconcile the package selection even when source-id avoids a rebuild.
        if [ -n "${PLEBIAN_OS_KILIX_GO_DEBIAN_VERSION:-}" ]; then
            _ensure_go_for_kilix_build
        fi
        if _kilix_fork_needs_rebuild; then
            _rebuild_kilix_fork
        else
            log "kilix fork already built for ${src_after:0:12}."
        fi
    else
        warn "PLEBIAN_OS_BUILD_KILIX_FORK=${PLEBIAN_OS_BUILD_KILIX_FORK:-0}; not rebuilding the fork"
    fi
    current_engine="$("$KILIX_DIR/kilix" --which 2>/dev/null | head -1 || true)"
    [ -n "$current_engine" ] && "$KILIX_DIR/kilix" --which >/dev/null 2>&1 \
        || die "updated Kilix has no runnable engine"
    log "engine now: $current_engine"

    _restore_transaction_preservations_after_success

    # Software state is now coherent. Restart failures must not undo a valid
    # update, but the lock remains held until restart handling finishes.
    _update_transaction_commit
    # Last: the updater's own checkout, so a failure here cannot strand a
    # half-updated engine and a moved Pleb cannot change this run underneath it.
    _update_pleb_self
    _offer_restart
    _release_update_lock
    trap - EXIT INT TERM
}
