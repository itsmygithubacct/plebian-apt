#!/usr/bin/env bash
# lib/install.sh — install/uninstall the Pleb LightDM session. Sourced by `pleb`.

# The Python modules installed under /usr/local/lib/pleb, in one place.
# Install, uninstall and Plebian-OS's root transactions all read this list;
# a second hand-typed copy left the lock guard (capture_session.py) out of
# uninstall and out of the distribution's rollback.
PLEB_CAPTURE_MODULES="displays.py displays_gui.py screenlock.py screenlock_gui.py capture_registry.py capture_sources.py capture_session.py capture_worker.py capture_screenshot.py capture_portal.py"

# Release mode on an installed Plebian OS. The release closure was already
# installed through the private Debian configuration, so a package still
# missing here means that closure is incomplete. Development, and pleb on a
# machine that is not Plebian OS, keep the system apt configuration.
_release_closure_refuses_system_apt() {
    [ "${PLEBIAN_OS_RELEASE_MODE:-0}" = 1 ] || return 1
    local marker="${PLEBIAN_OS_MACHINE_MARKER:-/etc/plebian-os/build-info.env}"
    [ -f "$marker" ] && [ ! -L "$marker" ]
}

_install_missing_apt_packages() {
    local label="$1"
    shift

    if [ "${PLEB_SKIP_DEPS:-0}" = 1 ]; then
        warn "skipping dependency install because PLEB_SKIP_DEPS=1"
        return 0
    fi
    if ! command -v apt-get >/dev/null 2>&1; then
        warn "automatic dependency install only supports apt-get; continuing"
        return 0
    fi

    local -a deps missing
    deps=("$@")
    missing=()
    if command -v dpkg-query >/dev/null 2>&1; then
        local pkg status
        for pkg in "${deps[@]}"; do
            # db:Status-Status is "installed" for both a normal install and an
            # apt-mark hold. One line per architecture; any installed instance
            # counts. The want flag (install vs hold) does not.
            status="$(dpkg-query -W -f='${db:Status-Status}\n' "$pkg" 2>/dev/null || true)"
            if ! printf '%s\n' "$status" | grep -qx 'installed'; then
                missing+=("$pkg")
            fi
        done
        if [ "${#missing[@]}" -eq 0 ]; then
            log "$label already installed"
            return 0
        fi
    else
        missing=("${deps[@]}")
    fi

    if _release_closure_refuses_system_apt; then
        warn "release package closure is incomplete; missing ${missing[*]}"
        warn "the system apt configuration was not used"
        warn "run 'plebian-os-update --revalidate-current' to reinstall this release's packages; if it is still missing, report it"
        return 1
    fi

    log "installing missing $label via apt-get: ${missing[*]}"
    run_root env DEBIAN_FRONTEND=noninteractive apt-get update
    run_root env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "${missing[@]}"
}

# ensure_system_deps — install the OS packages the Pleb session itself needs.
# Plebian-OS calls its own more complete dependency manifest before `pleb
# install`; this keeps standalone `pleb install` usable on fresh Debian/Ubuntu
# desktops too. Kilix owns the separate fork-build dependency manifest in
# scripts/install-build-deps.sh. Set PLEB_SKIP_DEPS=1 to skip package-manager
# changes.
ensure_system_deps() {
    local -a deps
    deps=(
        git curl tar unzip sudo tmux network-manager build-essential cmake zlib1g-dev
        lightdm xserver-xorg xinit x11-xserver-utils x11-utils xterm openbox
        libgl1 libegl1 libxkbcommon0 libxkbcommon-x11-0 libxcb-xkb1
        fontconfig fonts-dejavu-core xfonts-base
        python3-pil python3-xlib python3-websockets python3-venv python3-tk
        pulseaudio pulseaudio-utils pulsemixer alsa-utils ffmpeg xauth zenity
        zstd espeak-ng
        systemd libpam-systemd polkitd python3-dbus python3-gi dbus-user-session dbus-x11 xdg-desktop-portal xdg-desktop-portal-gtk
        pipewire pipewire-bin libpipewire-0.3-dev pkg-config gstreamer1.0-pipewire gstreamer1.0-x
        gstreamer1.0-plugins-base gstreamer1.0-plugins-good gir1.2-gst-plugins-base-1.0 gir1.2-gtk-3.0 python3-gi-cairo
        xdg-utils xdg-user-dirs desktop-file-utils shared-mime-info xfce4-notifyd libnotify-bin
        xss-lock i3lock libxss1 libx11-6 xfce4-power-manager xfconf lxpolkit
        blueman pulseaudio-module-bluetooth udisks2 udiskie gnome-disk-utility
        cups cups-client system-config-printer system-config-printer-udev
        pavucontrol ibus ibus-gtk ibus-gtk3 ibus-gtk4
        orca at-spi2-core gir1.2-notify-0.7
        libfluidsynth3 fluid-soundfont-gm
    )
    # Kilix Amp renders MIDI in-process through the FluidSynth *library* and a
    # General MIDI SoundFont. It never runs the FluidSynth player and never
    # talks to its daemon. On Debian (checked on 13) the package named
    # `fluidsynth` is that player, and it ships a per-user unit that the
    # package enables for every login, which then holds the default sound card
    # that dictation records from. So name the library, not the player. Do not
    # add libfluidsynth-dev here either: it hard-depends on the player (a
    # versioned Depends, which --no-install-recommends cannot drop), and Amp's
    # build prerequisites belong to Kilix's own installer, not this list.
    # tests/test_audio_dependencies.py resolves this request with apt itself.
    _install_missing_apt_packages "Pleb runtime dependencies" "${deps[@]}"
    # Read-aloud's optional quality tier: `mbrola` is contrib and its voice
    # databases are non-free, so a stock Debian with neither component enabled
    # cannot resolve them — and one unresolvable name fails the whole apt-get
    # transaction. Kept out of the required set and tolerated here, because
    # espeak-ng alone is the default engine and Kilix falls back to it when an
    # mbrola voice is missing. The release closure does not carry mbrola-us1
    # on purpose, so release mode must not call that an incomplete closure and
    # must not call system apt for it. `unzip` above extracts the checksum-pinned
    # Vosk wheel and acoustic-model archive. Microphone capture needs no new
    # package: pulseaudio-utils (parec/pacat) is already installed for the volume
    # widget.
    if ! _release_closure_refuses_system_apt; then
        _install_missing_apt_packages "read-aloud mbrola voices" mbrola mbrola-us1 \
            || warn "mbrola voices unavailable (enable Debian's contrib and non-free components to install them); read-aloud uses espeak-ng"
    fi
}

ensure_kilix_build_deps() {
    local installer="$KILIX_DIR/scripts/install-build-deps.sh"
    [ -f "$installer" ] && [ ! -L "$installer" ] && [ -x "$installer" ] \
        || die "Kilix build dependency installer is missing or unsafe: $installer"

    log "verifying Kilix-owned fork-build prerequisites"
    if "$installer" --verify; then
        log "Kilix fork-build prerequisites are ready"
        return 0
    fi
    if [ "${PLEB_SKIP_DEPS:-0}" = 1 ]; then
        die "Kilix build prerequisites are incomplete and PLEB_SKIP_DEPS=1; install the items reported above (including libxxhash when missing), then run '$installer --verify'"
    fi

    log "Kilix prerequisites are incomplete; running its authoritative installer"
    "$installer" \
        || die "Kilix build dependency installation failed: $installer"
    "$installer" --verify \
        || die "Kilix build prerequisites remain incomplete after installation (check the reported pkg-config modules, including libxxhash)"
    log "Kilix fork-build prerequisites are ready"
}

# ensure_kilix — make sure a kilix checkout with a runnable engine exists,
# cloning it fresh from upstream if it isn't there yet. A plain (non-recursive)
# clone + prebuilt kitty is enough to run; the clickable-button fork is built
# later on demand (`kilix --build` / `pleb update`, which init the submodule).
ensure_kilix() {
    require_immutable_ref "$KILIX_REF" "$KILIX_ALLOW_MUTABLE_REF" \
        KILIX_REF KILIX_ALLOW_MUTABLE_REF
    if [ -d "$KILIX_DIR/.git" ] && [ -x "$KILIX_DIR/kilix" ]; then
        validate_checkout_origin "$KILIX_DIR" "$KILIX_REPO" "kilix"
        log "kilix present at $KILIX_DIR (use 'pleb update' to update it)"
    else
        [ -e "$KILIX_DIR" ] && [ ! -d "$KILIX_DIR/.git" ] \
            && die "$KILIX_DIR exists but isn't a kilix checkout — move it aside first"
        command -v git >/dev/null 2>&1 || die "git is required to clone kilix"
        log "cloning kilix -> $KILIX_DIR"
        local -a clone_args=()
        [ -n "$KILIX_BRANCH" ] && clone_args=(--branch "$KILIX_BRANCH")
        git clone "${clone_args[@]}" "$KILIX_REPO" "$KILIX_DIR" \
            || die "git clone failed ($KILIX_REPO)"
    fi
    if [ -n "$KILIX_REF" ]; then
        require_clean_checkout "$KILIX_DIR" "kilix"
        checkout_fetched_ref "$KILIX_DIR" "$KILIX_REF" "kilix" KILIX_REF
        reconcile_kilix_submodules "$KILIX_DIR"
    fi
    ensure_engine
}

# ensure_kilix95 — make sure the optional Kilix 95 desktop checkout exists
# when this Pleb install is configured to boot directly into the desktop.
ensure_kilix95() {
    if ! kilix95_required; then
        return 0
    fi
    require_immutable_ref "$KILIX95_REF" "$KILIX95_ALLOW_MUTABLE_REF" \
        KILIX95_REF KILIX95_ALLOW_MUTABLE_REF

    if [ -d "$KILIX95_DIR/.git" ] && [ -f "$KILIX95_DIR/main.py" ]; then
        validate_checkout_origin "$KILIX95_DIR" "$KILIX95_REPO" "kilix 95"
        log "kilix 95 present at $KILIX95_DIR (use 'pleb update' to update it)"
    else
        if [ -z "$KILIX95_REF" ] && [ "$KILIX95_ALLOW_UNPINNED_INSTALL" != 1 ]; then
            die "automatic Kilix 95 install requires an immutable KILIX95_REF commit SHA (set KILIX95_ALLOW_UNPINNED_INSTALL=1 only to allow an unpinned clone)"
        fi
        [ -e "$KILIX95_DIR" ] && [ ! -d "$KILIX95_DIR/.git" ] \
            && die "$KILIX95_DIR exists but isn't a kilix 95 checkout — move it aside first"
        command -v git >/dev/null 2>&1 || die "git is required to clone kilix 95"
        log "cloning kilix 95 -> $KILIX95_DIR"
        local -a clone_args=()
        [ -n "$KILIX95_BRANCH" ] && clone_args=(--branch "$KILIX95_BRANCH")
        git clone "${clone_args[@]}" "$KILIX95_REPO" "$KILIX95_DIR" \
            || die "git clone failed ($KILIX95_REPO)"
    fi

    if [ -n "$KILIX95_REF" ]; then
        require_clean_checkout "$KILIX95_DIR" "kilix 95"
        checkout_fetched_ref "$KILIX95_DIR" "$KILIX95_REF" "kilix 95" KILIX95_REF
    fi
}

install_kilix_tui_utils() {
    local installer="$KILIX_DIR/scripts/install-kilix-tui-utils.sh"
    [ -f "$installer" ] && [ ! -L "$installer" ] && [ -x "$installer" ] \
        || die "kilix-tui-utils installer is missing or unsafe: $installer"
    log "installing Kilix's unified terminal utilities"
    KILIX_TUI_UTILS_PREFIX="$HOME/.local" \
        "$installer" --print-path >/dev/null \
        || die "kilix-tui-utils installation failed"
    [ -x "$KILIX_TEMPS_BIN" ] && [ -x "$KILIX_MEMORY_BIN" ] \
        || die "kilix-tui-utils did not produce Temps and Memory commands"
    [ -x "$KILIX_MUSIC_BIN" ] \
        || die "kilix-tui-utils did not produce the Music command"
}

install_tmux_tui() {
    local installer="$KILIX_DIR/scripts/install-tmux-tui.sh"
    [ -f "$installer" ] && [ ! -L "$installer" ] && [ -x "$installer" ] \
        || die "tmux-tui installer is missing or unsafe: $installer"
    log "installing Kilix's pinned tmux manager and tmux-cli command"
    TMUX_TUI_PREFIX="$HOME/.local" \
        "$KILIX_DIR/kilix" tmux --install-only --with-tb \
        || die "tmux-tui installation failed"
    [ -x "$TMUX_TUI_BIN" ] && [ -x "$TMUX_CLI_BIN" ] \
        || die "tmux-tui install did not produce tmux-tui and tb commands"
}

# dotfile_defines_tb — best-effort scan of one shell dotfile for any plausible
# user definition of `tb`: an alias assignment in any position of an `alias`
# command, or a function in either spelling, with or without parentheses. The
# scan is deliberately coarse, and a dotfile that exists but cannot be read —
# or a scan that fails outright — counts as a definition as well: skipping the
# provisioning is always safe, while a definition the scan missed would get
# shadowed by the appended alias.
dotfile_defines_tb() {
    local file="$1" rc=0
    [ -e "$file" ] || [ -L "$file" ] || return 1
    [ -f "$file" ] && [ -r "$file" ] || return 0
    grep -qE \
        '^[[:space:]]*(alias[[:space:]]+(.*[[:space:]])?tb=|function[[:space:]]+tb([[:space:](]|$)|tb[[:space:]]*\(\))' \
        -- "$file" || rc=$?
    # only grep's explicit no-match answer clears the name; a scan that failed
    # outright cannot prove absence either
    [ "$rc" -ne 1 ]
}

# provision_tb_shell_alias — give interactive shells a `tb` aliases-file entry
# (kilix session shells read ~/.bashrc, which sources ~/.bash_aliases on
# Debian). The alias resolves tmux-cli's logger inside the sibling kilix-apps
# checkout at use time, through the same source-root convention that locates
# every other sibling checkout, so the entry keeps working wherever the source
# root actually lives. The name `tb` may already be taken on the target system
# — as a binary, an alias, a function, or the published tmux-cli command link
# above — and an existing holder always wins: provisioning reports it and
# skips, it never clobbers or shadows.
provision_tb_shell_alias() {
    local aliases_file="$TMUX_CLI_ALIAS_FILE"
    local target="$KILIX_APPS_DIR/tmux-cli/tb.py"
    local alias_line existing_kind existing_path dotfile mode tmp
    alias_line="alias tb='python3 \"\${KILIX_APPS_DIR:-\${GPU_TERMINAL_SOURCE_HOME:-\$HOME/.local/gpu_terminal/sources}/kilix-apps}/tmux-cli/tb.py\"'"
    case "$aliases_file" in
        /*) ;;
        *) die "shell aliases path must be absolute: $aliases_file" ;;
    esac
    if [ -f "$aliases_file" ] && grep -qxF -- "$alias_line" "$aliases_file" 2>/dev/null; then
        log "tb shell alias already provisioned in $aliases_file"
        return 0
    fi
    existing_kind="$(type -t tb || true)"
    existing_path="$(command -v tb || true)"
    # This install's own tmux-cli command is the expected holder of the name,
    # including its published link on PATH: not a conflict, so no warning.
    if [ -x "$TMUX_CLI_BIN" ] || [ -e "$TMUX_CLI_LINK" ] || [ -L "$TMUX_CLI_LINK" ]; then
        if [ -z "$existing_kind" ] || [ "$existing_path" = "$TMUX_CLI_BIN" ] \
            || [ "$existing_path" = "$TMUX_CLI_LINK" ]; then
            log "tb is provided by the installed tmux-cli command ($TMUX_CLI_BIN or $TMUX_CLI_LINK); no shell alias needed"
            return 0
        fi
    fi
    if [ -n "$existing_kind" ]; then
        warn "tb already exists as a $existing_kind${existing_path:+ ($existing_path)}; skipping the tb shell alias"
        return 0
    fi
    # The aliases file is the user's own dotfile. Never write through a
    # symlink, into a file another user owns, or over a file this install
    # cannot read back in full — a dotfile arrangement this function does not
    # understand is a reason to leave the file alone, not to fail the whole
    # install, and certainly not to rewrite content it never saw.
    if [ -e "$aliases_file" ] || [ -L "$aliases_file" ]; then
        if ! { [ -f "$aliases_file" ] && [ ! -L "$aliases_file" ] \
            && [ -r "$aliases_file" ] \
            && [ "$(stat -c '%u' "$aliases_file" 2>/dev/null)" = "$(id -u)" ]; }; then
            warn "not writing through unexpected shell aliases file: $aliases_file; skipping the tb shell alias"
            return 0
        fi
    fi
    # A user's own `tb` may be defined in the aliases file, or directly in
    # ~/.bashrc where the non-interactive `type -t` probe above cannot see it.
    # Any plausible definition wins over the provisioning.
    for dotfile in "$aliases_file" "$HOME/.bashrc"; do
        if dotfile_defines_tb "$dotfile"; then
            warn "$dotfile already defines tb; skipping the tb shell alias"
            return 0
        fi
    done
    if [ ! -f "$target" ]; then
        warn "tmux-cli logger not found at $target; skipping the tb shell alias"
        return 0
    fi
    mode=644
    [ ! -f "$aliases_file" ] || mode="$(stat -c '%a' "$aliases_file")" \
        || die "could not inspect $aliases_file"
    tmp="$(mktemp "$(dirname "$aliases_file")/.bash_aliases.XXXXXX")" \
        || die "could not stage $aliases_file"
    if [ -f "$aliases_file" ]; then
        # the rewrite must carry every byte of the original, so a cat that
        # fails partway through means skip — never publish a partial copy
        if ! cat -- "$aliases_file" >"$tmp"; then
            rm -f -- "$tmp"
            warn "could not read $aliases_file back; skipping the tb shell alias"
            return 0
        fi
        [ -z "$(tail -c1 -- "$aliases_file")" ] || printf '\n' >>"$tmp" \
            || { rm -f -- "$tmp"; die "could not write $aliases_file"; }
    fi
    printf '%s\n' "$alias_line" >>"$tmp" \
        || { rm -f -- "$tmp"; die "could not write $aliases_file"; }
    chmod "$mode" -- "$tmp" \
        || { rm -f -- "$tmp"; die "could not protect $aliases_file"; }
    mv -f -- "$tmp" "$aliases_file" \
        || { rm -f -- "$tmp"; die "could not publish $aliases_file"; }
    log "tb shell alias -> $aliases_file (tmux-cli logger in the kilix-apps checkout)"
}

# install_kilix_voice — install Kilix's pinned read-aloud/dictation closure.
# Policy 0 deliberately installs read-aloud without libvosk or an acoustic
# model; because voice remains optional in that mode, a missing closure is
# reported without stopping the rest of Pleb. Policy 1 is an explicit request
# for the full checksum-pinned dictation closure. It must fail the install if
# any part is unavailable instead of silently accepting a read-aloud-only
# system that does not satisfy the selected release policy.
install_kilix_voice() {
    local installer="$KILIX_DIR/scripts/install-kilix-voice.sh"
    local policy="${PLEB_INSTALL_VOICE_MODEL:-0}"
    case "$policy" in
        0|1) ;;
        *) die "PLEB_INSTALL_VOICE_MODEL must be 0 (read-aloud only) or 1 (full dictation)" ;;
    esac
    if [ ! -f "$installer" ] || [ -L "$installer" ] || [ ! -x "$installer" ]; then
        if [ "$policy" = 1 ]; then
            die "Kilix Voice installer is missing or unsafe: $installer (PLEB_INSTALL_VOICE_MODEL=1 requires the full pinned dictation closure)"
        fi
        warn "Kilix Voice installer is missing or unsafe: $installer"
        warn "read-aloud stays unavailable; dictation was disabled by policy"
        return 0
    fi
    if [ "$policy" = 1 ]; then
        log "installing Kilix's full pinned read-aloud and dictation closure"
        KILIX_VOICE_PREFIX="$HOME/.local" "$KILIX_DIR/kilix" voice install \
            || die "Kilix Voice full dictation installation failed with PLEB_INSTALL_VOICE_MODEL=1; no read-aloud-only fallback was selected (run 'kilix voice doctor' for the reason)"
        return 0
    fi

    log "PLEB_INSTALL_VOICE_MODEL=0: installing the pinned read-aloud-only closure"
    KILIX_VOICE_PREFIX="$HOME/.local" \
        "$KILIX_DIR/kilix" voice install --without-dictation \
        || warn "Kilix Voice read-aloud installation failed; run 'kilix voice doctor' for the reason"
}

# The commit the installed voice closure was built from, as its own installer
# recorded it. Reported either side of a refresh so a voice move is as visible
# as a Kilix or Kilix 95 one.
_kilix_voice_installed_ref() {
    local stamp="$KILIX_STATE_DIRECTORY/kilix-voice-install.refs"
    [ -f "$stamp" ] && [ ! -L "$stamp" ] || return 0
    sed -n 's/^kilix-voice=//p' "$stamp" | head -1
}

# refresh_kilix_voice — carry a moved voice pin onto a machine that already has
# the closure, without ever being the thing that installs it.
#
# Voice is the one component Kilix installs lazily, and that laziness is load
# bearing: `kilix speak` must not be able to start a git clone and a 41 MB model
# download, which is why the launcher resolves the daemon without its installer.
# An update inherits the same rule from the other direction — it may refresh
# what is there, and it may not add what is not. Before this, a bumped
# KILIX_VOICE_REF reached every fresh machine and no existing one, so the only
# delivery route was a hand-typed `kilix voice install --force`.
#
# The read-aloud/dictation shape of the existing install is preserved for the
# same reason: refreshing a read-aloud-only machine must not quietly enrol it in
# the recognition closure.
refresh_kilix_voice() {
    local installer="$KILIX_DIR/scripts/install-kilix-voice.sh" before after
    local -a args=()
    if [ ! -x "$KILIX_VOICE_TTS_BIN" ] || [ ! -x "$KILIX_VOICE_STT_BIN" ]; then
        log "kilix voice: not installed; an update never installs it (run 'kilix voice install')"
        return 0
    fi
    if [ ! -f "$installer" ] || [ -L "$installer" ] || [ ! -x "$installer" ]; then
        warn "Kilix Voice installer is missing or unsafe: $installer"
        warn "the installed voice closure was left exactly as it was"
        return 0
    fi
    [ -f "$KILIX_DATA_HOME/voice/lib/current/libvosk.so" ] \
        || args=(--without-dictation)
    before="$(_kilix_voice_installed_ref)"
    log "refreshing the installed Kilix Voice closure to its pinned commit"
    if ! KILIX_VOICE_PREFIX="$HOME/.local" "$installer" "${args[@]}"; then
        warn "Kilix Voice refresh failed; the previously installed closure is still in place"
        warn "run 'kilix voice doctor' for the reason"
        return 0
    fi
    after="$(_kilix_voice_installed_ref)"
    if [ -n "$before" ] && [ -n "$after" ] && [ "$before" != "$after" ]; then
        log "kilix voice: ${before:0:12} -> ${after:0:12}"
    elif [ -n "$after" ]; then
        log "kilix voice already up to date at ${after:0:12}."
    fi
}

# install_kilix_amp — build the pinned Media Player and its headless backend.
#
# Kilix Amp is catalog content and has always installed on first use from the
# desktop. A provisioned machine should not make the first person to open the
# player, or the Music tool that drives its backend, wait for a compile, so it
# is built here instead.
#
# Failure warns rather than dies. A machine without the SDL, libsndfile and
# FluidSynth development libraries is a legitimate one — Plebian-OS installs
# them before this runs, a standalone `pleb install` may not — and the on-demand
# install stays available either way, so this is a head start, not a
# precondition for a working session.
install_kilix_amp() {
    log "installing Kilix's pinned Media Player and its headless backend"
    if ! "$KILIX_DIR/kilix" amp --install-only; then
        warn "Kilix Amp did not build; the Media Player and kilix-music will build it on first use"
        return 0
    fi
    [ -x "$KILIX_AMP_BIN" ] \
        || warn "Kilix Amp reported success but $KILIX_AMP_BIN is missing"
}

# install_kilix_pdf_viewer — install the catalog-pinned PDF launcher and build
# its native Poppler/Cairo core when the target has the development files.
#
# This is best-effort for standalone Pleb installs: the catalog launcher can
# still hand a document to Evince when no native core was built. Plebian-OS
# installs both that fallback and the native build prerequisites before Pleb.
install_kilix_pdf_viewer() {
    log "installing Kilix's pinned PDF Viewer"
    if ! "$KILIX_DIR/kilix" pdf-view --install-only; then
        warn "Kilix PDF Viewer did not install; Kilix will retry on first use"
        return 0
    fi
    [ -x "$KILIX_PDF_VIEWER_BIN" ] \
        || warn "Kilix PDF Viewer reported success but $KILIX_PDF_VIEWER_BIN is missing"
    if [ -x "$KILIX_PDF_CORE_BIN" ]; then
        log "Kilix PDF Viewer's native Poppler/Cairo core is ready"
    else
        warn "Kilix PDF Viewer's native core was not built; its Evince fallback remains available when installed"
    fi
}

install_pty_broker() {
    local source="$KILIX_DIR/third_party/kitty-pty-broker"
    local builder="$KILIX_DIR/scripts/build-pty-broker.sh"
    local mode
    mode="$(git -C "$KILIX_DIR" ls-files --stage -- \
        third_party/kitty-pty-broker 2>/dev/null | awk 'NR == 1 { print $1 }')"
    if [ "$mode" != 160000 ]; then
        if [ "${PLEB_DEFER_PTY_BROKER:-0}" = 1 ]; then
            log "current Kilix predates the pinned PTY broker; deferring until its component update"
            return 0
        fi
        die "Kilix does not pin the kitty-pty-broker submodule"
    fi
    log "initializing Kilix's pinned persistent PTY broker"
    git -C "$KILIX_DIR" submodule update --init --recursive -- \
        third_party/kitty-pty-broker \
        || die "kitty-pty-broker submodule update failed"
    [ -d "$source" ] && [ ! -L "$source" ] \
        || die "kitty-pty-broker source is missing or unsafe: $source"
    [ -f "$builder" ] && [ ! -L "$builder" ] && [ -x "$builder" ] \
        || die "kitty-pty-broker builder is missing or unsafe: $builder"
    "$KILIX_DIR/kilix" pty --install-only \
        || die "kitty-pty-broker build failed"
    [ -x "$KILIX_PTY_BROKER_BIN" ] && [ ! -L "$KILIX_PTY_BROKER_BIN" ] \
        || die "kitty-pty-broker build did not produce its executable"
}

# ensure_engine — make sure kilix has a runnable kitty; if not, fetch the
# prebuilt one (needs only git/curl/tar). The fork (buttons) needs Go >= 1.26.
ensure_engine() {
    local answer engine
    local -a bootstrap_args=()
    if { [ -n "$KILIX_PREBUILT_VERSION" ] && [ -z "$KILIX_PREBUILT_SHA256" ]; } \
        || { [ -z "$KILIX_PREBUILT_VERSION" ] && [ -n "$KILIX_PREBUILT_SHA256" ]; }; then
        die "KILIX_PREBUILT_VERSION and KILIX_PREBUILT_SHA256 must be set together"
    fi
    # A configured version/checksum pair is an installation invariant, not just
    # a download hint.  Let bootstrap.sh revalidate the fallback even when some
    # engine (including a previously built fork) is already runnable.
    if [ -z "$KILIX_PREBUILT_VERSION" ] \
        && "$KILIX_DIR/kilix" --which >/dev/null 2>&1; then
        log "engine: $("$KILIX_DIR/kilix" --which 2>/dev/null | tail -1)"
        return 0
    fi
    [ -x "$KILIX_DIR/bootstrap.sh" ] || die "no engine and no bootstrap.sh in $KILIX_DIR"
    if [ -z "$KILIX_PREBUILT_VERSION" ]; then
        [ -t 0 ] || die "non-interactive engine install requires pinned KILIX_PREBUILT_VERSION and KILIX_PREBUILT_SHA256"
        warn "no kitty bundle checksum is pinned; Plebian-OS release installs always pin one"
        # First run without the override. bootstrap.sh refuses before download
        # and prints the exact release URL so consent can be informed.
        env KILIX_PREBUILT_VERSION= KILIX_PREBUILT_SHA256= \
            KILIX_ALLOW_UNVERIFIED_PREBUILT=0 \
            "$KILIX_DIR/bootstrap.sh" || true
        ask "Allow bootstrap.sh to download that unverified asset? [y/N]"
        read -r answer
        case "$answer" in
            y|Y|yes|YES) bootstrap_args=(--allow-unverified) ;;
            *) die "engine install cancelled; set the prebuilt version and checksum, then retry" ;;
        esac
    fi
    log "fetching the prebuilt kilix engine ..."
    env "KILIX_PREBUILT_VERSION=$KILIX_PREBUILT_VERSION" \
        "KILIX_PREBUILT_SHA256=$KILIX_PREBUILT_SHA256" \
        "$KILIX_DIR/bootstrap.sh" "${bootstrap_args[@]}" \
        || die "kilix engine bootstrap failed"
    engine="$("$KILIX_DIR/kilix" --which 2>/dev/null | head -1 || true)"
    [ -n "$engine" ] && "$KILIX_DIR/kilix" --which >/dev/null 2>&1 \
        || die "kilix engine bootstrap reported success, but no runnable engine is available"
    log "engine ready: $engine"
}

link_command() {
    local target="$1" dest="$2" label="$3" existing=""
    if [ -L "$dest" ]; then
        existing="$(readlink "$dest")"
        if [ "$existing" = "$target" ]; then
            log "$label command already linked at $dest"
            return 0
        fi
        # The same file reached through another path, e.g. a checkout that a
        # developer layout reaches through a symlinked source directory. It is
        # already the expected command; rewrite only the link text so later
        # runs compare equal.
        if [ -e "$target" ] && [ "$dest" -ef "$target" ]; then
            log "$label command at $dest reaches $target through $existing; relinking it directly"
            run_root ln -sfn "$target" "$dest"
            return
        fi
    elif [ -e "$dest" ]; then
        existing="$dest"
    fi
    if [ -n "$existing" ] && [ "${PLEB_INSTALL_FORCE_LINKS:-0}" != 1 ]; then
        die "$dest already exists and is not the expected $label symlink (set PLEB_INSTALL_FORCE_LINKS=1 to replace it)"
    fi
    [ -n "$existing" ] && warn "replacing existing $dest"
    run_root ln -sfn "$target" "$dest"
}

_pleb_artwork_sources() {
    PLEB_WALLPAPER_SRC="$PLEB_ROOT/assets/desktop/plebian-os.png"
    PLEB_DESKTOP_README_SRC="$PLEB_ROOT/assets/desktop/README.md"
    PLEB_ARTWORK_ATTRIBUTION_SRC="$PLEB_ROOT/assets/installer/ATTRIBUTION.md"
    PLEB_ARTWORK_GPL2_SRC="$PLEB_ROOT/assets/COPYING.GPL-2"
}

_pleb_artwork_destinations() {
    PLEB_WALLPAPER_DST="$PLEB_DATA_HOME/wallpapers/plebian-os.png"
    PLEB_DESKTOP_README_DST="$PLEB_DATA_HOME/doc/desktop/README.md"
    PLEB_ARTWORK_ATTRIBUTION_DST="$PLEB_DATA_HOME/doc/installer/ATTRIBUTION.md"
    PLEB_ARTWORK_GPL2_DST="$PLEB_DATA_HOME/doc/COPYING.GPL-2"
}

validate_pleb_artwork_bundle() {
    local validator="$PLEB_ROOT/scripts/validate-artwork.py"
    _pleb_artwork_sources
    [ -f "$validator" ] && [ ! -L "$validator" ] \
        || die "missing Pleb artwork validator: $validator"
    command -v python3 >/dev/null 2>&1 \
        || die "python3 is required to validate the Plebian wallpaper"
    python3 "$validator" \
        "$PLEB_WALLPAPER_SRC" \
        "$PLEB_DESKTOP_README_SRC" \
        "$PLEB_ARTWORK_ATTRIBUTION_SRC" \
        "$PLEB_ARTWORK_GPL2_SRC" >/dev/null \
        || die "Plebian wallpaper bundle validation failed"
}

_pleb_artwork_destination_safe() {
    local destination="$1"
    if [ -e "$destination" ] || [ -L "$destination" ]; then
        [ -f "$destination" ] && [ ! -L "$destination" ] \
            || die "refusing unsafe Pleb artwork destination: $destination"
        [ "$(stat -c '%u' "$destination" 2>/dev/null)" = "$(id -u)" ] \
            || die "Pleb artwork destination is not owned by the current user: $destination"
    fi
}

install_pleb_artwork_bundle() {
    local validator="$PLEB_ROOT/scripts/validate-artwork.py" index destination
    local failure="" published=0
    local -a sources destinations staged backups
    _pleb_artwork_sources
    ensure_pleb_private_storage
    _pleb_artwork_destinations
    validate_pleb_artwork_bundle
    umask 077
    for destination in \
        "$PLEB_STORAGE_HOME" \
        "$PLEB_DATA_HOME" \
        "$PLEB_DATA_HOME/wallpapers" \
        "$PLEB_DATA_HOME/doc" \
        "$PLEB_DATA_HOME/doc/desktop" \
        "$PLEB_DATA_HOME/doc/installer"; do
        _pleb_private_data_dir "$destination"
    done

    sources=(
        "$PLEB_WALLPAPER_SRC"
        "$PLEB_DESKTOP_README_SRC"
        "$PLEB_ARTWORK_ATTRIBUTION_SRC"
        "$PLEB_ARTWORK_GPL2_SRC"
    )
    destinations=(
        "$PLEB_WALLPAPER_DST"
        "$PLEB_DESKTOP_README_DST"
        "$PLEB_ARTWORK_ATTRIBUTION_DST"
        "$PLEB_ARTWORK_GPL2_DST"
    )
    staged=()
    backups=()
    for ((index=0; index<${#destinations[@]}; index++)); do
        destination="${destinations[$index]}"
        _pleb_artwork_destination_safe "$destination"
        staged[$index]="$(mktemp "$(dirname "$destination")/.${destination##*/}.XXXXXX")" \
            || die "could not stage Pleb artwork: $destination"
        if ! cp -- "${sources[$index]}" "${staged[$index]}" \
            || ! chmod 0600 -- "${staged[$index]}"; then
            rm -f -- "${staged[@]}"
            die "could not copy Pleb artwork into private staging"
        fi
        backups[$index]=""
        if [ -e "$destination" ]; then
            backups[$index]="$(mktemp "$(dirname "$destination")/.${destination##*/}.backup.XXXXXX")" \
                || die "could not stage Pleb artwork rollback copy: $destination"
            if ! cp -p -- "$destination" "${backups[$index]}"; then
                rm -f -- "${staged[@]}" "${backups[$index]}"
                die "could not preserve existing Pleb artwork before replacement: $destination"
            fi
        fi
    done

    if ! python3 "$validator" "${staged[@]}" >/dev/null; then
        rm -f -- "${staged[@]}"
        for destination in "${backups[@]}"; do
            [ -z "$destination" ] || rm -f -- "$destination"
        done
        die "staged Pleb artwork bundle validation failed"
    fi
    for ((index=0; index<${#destinations[@]}; index++)); do
        if ! chmod 0644 -- "${staged[$index]}" \
            || ! mv -fT -- "${staged[$index]}" "${destinations[$index]}"; then
            failure="could not publish Pleb artwork: ${destinations[$index]}"
            break
        fi
        published=$((published + 1))
    done
    if [ -z "$failure" ] \
        && ! python3 "$validator" "${destinations[@]}" >/dev/null; then
        failure="installed Pleb artwork bundle failed post-copy validation"
    fi
    if [ -n "$failure" ]; then
        # Each rename is atomic. If a later rename or the final validation
        # fails, restore every earlier destination before returning failure so
        # a normal I/O error cannot leave a mixed old/new bundle.
        for ((index=published-1; index>=0; index--)); do
            if [ -n "${backups[$index]}" ]; then
                command mv -fT -- "${backups[$index]}" "${destinations[$index]}" \
                    || warn "could not restore ${destinations[$index]} after artwork failure"
                backups[$index]=""
            else
                rm -f -- "${destinations[$index]}" \
                    || warn "could not remove ${destinations[$index]} after artwork failure"
            fi
        done
        rm -f -- "${staged[@]:$published}"
        for destination in "${backups[@]}"; do
            [ -z "$destination" ] || rm -f -- "$destination"
        done
        die "$failure"
    fi
    for destination in "${backups[@]}"; do
        [ -z "$destination" ] || rm -f -- "$destination"
    done
    log "installed Plebian wallpaper -> $PLEB_WALLPAPER_DST"
    info "artwork attribution: $PLEB_ARTWORK_ATTRIBUTION_DST"
}

_pleb_desktop_state_dir() {
    local state_dir data_root
    case "${KILIX_DESKTOP_PROVIDER:-auto}" in
        builtin|external|xp|kilix-xp) ;;
        auto)
            if [ -f "$KILIX95_DIR/main.py" ]; then
                :
            elif [ -f "$KILIX_DIR/desktop/main.py" ]; then
                :
            else
                return 1
            fi ;;
        none|off|disabled|command|custom|cap|kilix-cap|mansion|tui|kilix-tui|land|kilix-land|kilix-land-desktop|icewm|kilix-icewm|zell|zell-neuronte|kilix-zell)
            return 1 ;;
        *)
            die "unknown KILIX_DESKTOP_PROVIDER=${KILIX_DESKTOP_PROVIDER:-}" ;;
    esac
    state_dir="$(_pleb_normalized_absolute_path "$KILIX_DESKTOP_DIR")"
    data_root="$(_pleb_normalized_absolute_path "$PLEB_DATA_HOME")"
    [ "${KILIX_DESKTOP_DIR%/}" = "$state_dir" ] \
        || die "KILIX_DESKTOP_DIR must be a normalized absolute path: $KILIX_DESKTOP_DIR"
    case "$state_dir" in
        "$data_root"/*) ;;
        *) die "standalone Pleb requires KILIX_DESKTOP_DIR below PLEB_DATA_HOME ($data_root): $state_dir" ;;
    esac
    _pleb_assert_no_symlink_components "$state_dir"
    printf '%s\n' "$state_dir"
}

seed_pleb_wallpaper_state() {
    local validator="$PLEB_ROOT/scripts/validate-artwork.py"
    local state_dir state_path owner rc
    _pleb_artwork_destinations
    state_dir="$(_pleb_desktop_state_dir)" || {
        log "no compatible Kilix desktop provider selected; wallpaper state not seeded"
        return 0
    }
    state_path="$state_dir/.state.json"
    if [ -e "$state_path" ] || [ -L "$state_path" ]; then
        log "preserving existing Kilix desktop state (including wallpaper): $state_path"
        return 0
    fi
    python3 "$validator" \
        "$PLEB_WALLPAPER_DST" \
        "$PLEB_DESKTOP_README_DST" \
        "$PLEB_ARTWORK_ATTRIBUTION_DST" \
        "$PLEB_ARTWORK_GPL2_DST" >/dev/null \
        || die "installed Pleb artwork is invalid; refusing to seed desktop state"
    _pleb_private_data_dir "$state_dir"
    owner="$(stat -c '%u' "$state_dir" 2>/dev/null)" \
        || die "could not inspect Kilix desktop state directory: $state_dir"
    [ "$owner" = "$(id -u)" ] \
        || die "Kilix desktop state directory is not owned by the current user: $state_dir"

    if python3 - "$state_dir" "$state_path" "$PLEB_WALLPAPER_DST" <<'PY'
import json
import os
import sys
import tempfile

state_dir, state_path, wallpaper = sys.argv[1:]
fd, temporary = tempfile.mkstemp(prefix=".state.json.pleb.", dir=state_dir)
try:
    os.fchmod(fd, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        json.dump({
            "wall_image": wallpaper,
            "wall_mode": "stretch",
            "wall_custom": True,
        }, stream, indent=1)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    try:
        os.link(temporary, state_path, follow_symlinks=False)
    except FileExistsError:
        raise SystemExit(17)
    directory_fd = os.open(state_dir, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)
finally:
    try:
        os.unlink(temporary)
    except FileNotFoundError:
        pass
PY
    then
        log "new Kilix desktop will use $PLEB_WALLPAPER_DST"
    else
        rc=$?
        [ "$rc" = 17 ] \
            || die "could not seed Plebian wallpaper state: $state_path"
        log "Kilix desktop state appeared concurrently; preserving it"
    fi
}

install_standalone_pleb_wallpaper() {
    # Privacy is part of Pleb's storage contract, not part of artwork ownership.
    # Plebian-OS manages the files below data/, but must not bypass mode repair.
    ensure_pleb_private_storage
    if [ "${PLEBIAN_OS_MANAGED_INSTALL:-0}" = 1 ]; then
        log "Plebian-OS manages the system wallpaper; skipping standalone Pleb artwork"
        return 0
    fi
    install_pleb_artwork_bundle
    # Seed the selected compatible provider even when PLEB_DESKTOP is currently
    # off, so enabling the desktop later does not require reinstalling Pleb.
    # Providers `none` and `command` have no Kilix state contract and are
    # deliberately skipped by _pleb_desktop_state_dir.
    seed_pleb_wallpaper_state
}

validate_recovery_document() {
    if [ ! -f "$PLEB_RECOVERY_DOC_SRC" ] || [ -L "$PLEB_RECOVERY_DOC_SRC" ]; then
        die "missing or unsafe Pleb recovery document: $PLEB_RECOVERY_DOC_SRC"
    fi
}

install_recovery_document() {
    validate_recovery_document
    case "$PLEB_RECOVERY_DOC_DST" in
        /*) ;;
        *) die "PLEB_RECOVERY_DOC_DST must be absolute: $PLEB_RECOVERY_DOC_DST" ;;
    esac
    log "installing Pleb recovery guide -> $PLEB_RECOVERY_DOC_DST"
    run_root install -D -m 0644 -- \
        "$PLEB_RECOVERY_DOC_SRC" "$PLEB_RECOVERY_DOC_DST"
}

validate_openbox_profile() {
    if [ ! -f "$OPENBOX_CONFIG_SRC" ] || [ -L "$OPENBOX_CONFIG_SRC" ]; then
        die "missing or unsafe Pleb Openbox profile: $OPENBOX_CONFIG_SRC"
    fi
}

install_openbox_profile() {
    validate_openbox_profile
    case "$OPENBOX_CONFIG_DST" in
        /*) ;;
        *) die "OPENBOX_CONFIG_DST must be absolute: $OPENBOX_CONFIG_DST" ;;
    esac
    log "installing Pleb Openbox profile -> $OPENBOX_CONFIG_DST"
    run_root install -D -m 0644 -- \
        "$OPENBOX_CONFIG_SRC" "$OPENBOX_CONFIG_DST"
}

install_notification_theme() {
    if [ ! -f "$NOTIFICATION_THEME_SRC" ] || [ -L "$NOTIFICATION_THEME_SRC" ]; then
        die "missing or unsafe Pleb notification theme: $NOTIFICATION_THEME_SRC"
    fi
    case "$NOTIFICATION_THEME_DST" in
        /*) ;;
        *) die "NOTIFICATION_THEME_DST must be absolute: $NOTIFICATION_THEME_DST" ;;
    esac
    run_root install -D -m 0644 -- "$NOTIFICATION_THEME_SRC" "$NOTIFICATION_THEME_DST"
}

# do_install — ensure kilix is present, copy pleb-session to /usr/local/bin, and
# drop the xsession entry so LightDM lists "Pleb" as a choosable session.
install_capture_portal() {
    local dest=/usr/local/lib/pleb
    # Compile as the invoking user, then stage the transport and every module
    # beside its destination before renaming any of them into place. A failed
    # build or staging step leaves the installed transport and modules
    # untouched, and a D-Bus activation never sees most of one version beside
    # the rest of another.
    (
        set -e
        build_dir=$(mktemp -d) || exit 1
        trap 'rm -rf -- "$build_dir"' EXIT
        bash "$PLEB_ROOT/scripts/build-capture-transport.sh" "$build_dir/capture_transport.so" || exit 1
        run_root install -D -m 0644 "$build_dir/capture_transport.so" "$dest/.capture_transport.so.new" || exit 1
    ) || {
        run_root rm -f "$dest/.capture_transport.so.new"
        die "Could not build/install capture transport; install libpipewire-0.3-dev and pkg-config"
    }
    local module name staged=(capture_transport.so)
    for module in $PLEB_CAPTURE_MODULES; do
        if ! run_root install -D -m 0644 "$PLEB_ROOT/lib/$module" "$dest/.$module.new"; then
            # Including the failing module's own partial copy.
            for name in "${staged[@]}" "$module"; do
                run_root rm -f "$dest/.$name.new"
            done
            die "Could not stage the capture backend module $module"
        fi
        staged+=("$module")
    done
    local index
    for ((index = 0; index < ${#staged[@]}; index++)); do
        name=${staged[$index]}
        if ! run_root mv -f "$dest/.$name.new" "$dest/$name"; then
            for name in "${staged[@]:$index}"; do
                run_root rm -f "$dest/.$name.new"
            done
            die "Could not move the capture backend file ${staged[$index]} into place; the installed backend is incomplete, rerun the install"
        fi
    done
    run_root install -D -m 0644 "$PLEB_ROOT/share/portals/pleb.portal" \
        /usr/local/share/xdg-desktop-portal/portals/pleb.portal
    run_root install -D -m 0644 "$PLEB_ROOT/share/portals/org.freedesktop.impl.portal.desktop.pleb.service" \
        /usr/local/share/dbus-1/services/org.freedesktop.impl.portal.desktop.pleb.service
    # The distribution owns this audio/video policy. A standalone Pleb install
    # uses its host's session manager and must not change another desktop's
    # WirePlumber profile or portal preferences.
    if [ "${PLEBIAN_OS_MANAGED_INSTALL:-0}" = 1 ]; then
        run_root install -D -m 0644 "$PLEB_ROOT/share/portals/50pleb-video-only.conf" \
            /etc/wireplumber/wireplumber.conf.d/50pleb-video-only.conf
        run_root install -D -m 0644 "$PLEB_ROOT/share/portals/pleb-portals.conf" \
            /etc/xdg-desktop-portal/pleb-portals.conf
    fi
}

# Closing the lid does nothing by default (owner answer 17, 2026-10-07). This
# covers the times no Pleb session runs xfce4-power-manager (greeter, console);
# inside a session its xfconf setting decides (bin/pleb-session seeds NOTHING).
# Plebian-OS ships its own 50-plebian-lid.conf, so a managed install skips this.
# Only this one file is written; other logind drop-ins are never touched, and
# logind is not restarted: the drop-in applies at the next boot.
install_lid_policy() {
    if [ "${PLEBIAN_OS_MANAGED_INSTALL:-0}" = 1 ]; then
        return 0
    fi
    log "lid close does nothing without a session policy -> $LID_POLICY_DST"
    run_root install -D -m 0644 "$PLEB_ROOT/share/logind/50-pleb-lid.conf" "$LID_POLICY_DST"
}

install_screensaver() {
    local dest=/usr/local/lib/pleb
    # Stage both files before publication. A failed copy leaves the previous
    # service/shim in place; publish before the session that requires them.
    if ! run_root install -D -m 0644 "$PLEB_ROOT/lib/screensaver.py" "$dest/.screensaver.py.new" \
        || ! run_root install -D -m 0755 "$PLEB_ROOT/bin/xdg-screensaver" "$dest/session-bin/.xdg-screensaver.new"; then
        run_root rm -f -- "$dest/.screensaver.py.new" "$dest/session-bin/.xdg-screensaver.new" || true
        die "Could not stage Pleb ScreenSaver service"
    fi
    run_root mv -fT -- "$dest/.screensaver.py.new" "$dest/screensaver.py" \
        || die "Could not publish Pleb ScreenSaver service; rerun the install"
    run_root mv -fT -- "$dest/session-bin/.xdg-screensaver.new" "$dest/session-bin/xdg-screensaver" \
        || die "Could not publish Pleb ScreenSaver command; rerun the install"
}

install_notifications() {
    local dest=/usr/local/lib/pleb
    run_root install -D -m 0644 "$PLEB_ROOT/lib/notification_center.py" "$dest/.notification_center.py.new" \
        || die "Could not stage Pleb notifications"
    run_root mv -fT -- "$dest/.notification_center.py.new" "$dest/notification_center.py" \
        || die "Could not publish Pleb notifications; rerun the install"
}

# do_install_packaged — `pleb install` on a system installed from the pleb
# Debian package. The packages own the session launcher, the xsession entry,
# the portal, the commands on PATH and Kilix itself, so nothing here runs as
# root, clones or builds: only this user's storage, shared settings and
# artwork are prepared.
do_install_packaged() {
    ensure_pleb_private_storage
    [ -f "$KILIX_DIR/kilix-settings" ] && [ ! -L "$KILIX_DIR/kilix-settings" ] \
        || die "missing or unsafe Kilix settings TUI: $KILIX_DIR/kilix-settings (install the kilix package)"
    python3 "$KILIX_DIR/kilix-settings" --ensure \
        || die "could not initialize $GPU_TERMINAL_SETTINGS_FILE"
    install_standalone_pleb_wallpaper
    log "done. Pleb is installed from Debian packages; at the LightDM greeter"
    info "pick the \"Pleb\" session and log in."
}

do_install() {
    if [ "$PLEB_PACKAGED" = 1 ]; then
        do_install_packaged
        return
    fi
    [ -f "$PLEB_BIN_SRC" ]    || die "missing $PLEB_BIN_SRC"
    [ -f "$PLEB_DESKTOP_IN" ] || die "missing $PLEB_DESKTOP_IN"
    validate_recovery_document
    validate_openbox_profile

    # This is required for both standalone and Plebian-OS-managed installs.
    # Managed installs skip artwork publication, never storage privacy.
    ensure_pleb_private_storage

    ensure_system_deps
    ensure_kilix   # fresh-clone kilix + set up an engine if not already present
    # The shared SDK uses one fixed installed ancestor per private bus.
    # No service is enabled permanently and no session environment is authority.
    # Publish a launcher only with the complete installed SDK source contract.
    [ -f "$KILIX_DIR/config/kilix_sdk/bus_platform.py" ] \
        && [ ! -L "$KILIX_DIR/config/kilix_sdk/bus_platform.py" ] \
        || die "Missing/unsafe private GUI bus platform source; install the reviewed complete Kilix tuple"
    python3 "$KILIX_DIR/config/kilix_sdk/bus_platform.py" --check-source-delivery \
        || die "Incomplete private GUI bus platform source; install the reviewed complete Kilix tuple"
    [ -f "$KILIX_DIR/scripts/install-private-bus-supervisor.py" ] \
        && [ ! -L "$KILIX_DIR/scripts/install-private-bus-supervisor.py" ] \
        || die "Missing/unsafe private-bus supervisor installer"
    run_root /usr/bin/python3 -I "$KILIX_DIR/scripts/install-private-bus-supervisor.py" --install \
        || die "Private-bus supervisor delivery failed; launcher not published"
    install_pty_broker
    install_kilix_tui_utils
    install_tmux_tui
    install_kilix_voice
    install_kilix_amp
    install_kilix_pdf_viewer
    if [ ! -f "$KILIX_DIR/kilix-settings" ] \
            || [ -L "$KILIX_DIR/kilix-settings" ]; then
        die "missing or unsafe Kilix settings TUI: $KILIX_DIR/kilix-settings"
    fi
    python3 "$KILIX_DIR/kilix-settings" --ensure \
        || die "could not initialize $GPU_TERMINAL_SETTINGS_FILE"
    ensure_kilix95 # optional: external Kilix 95 when the selected provider needs it
    install_standalone_pleb_wallpaper
    install_recovery_document
    # before the launcher: an installed pleb-session that points at an absent
    # profile is a hard session failure under PLEB_WM=openbox, and do_install
    # has no rollback, so ordering is the staging mechanism.
    install_openbox_profile
    install_notification_theme

    log "installing session launcher -> $SESSION_BIN_DST"
    run_root install -D -m 0644 "$PLEB_ROOT/lib/displays.py" "$PLEB_DISPLAYS_DST"
    run_root install -D -m 0755 "$PLEB_ROOT/bin/pleb-lock" "$PLEB_LOCK_DST"
    install_capture_portal
    install_lid_policy
    install_screensaver
    install_notifications
    run_root install -D -m 0755 "$PLEB_BIN_SRC" "$SESSION_BIN_DST"

    log "installing xsession entry -> $XSESSION_DST"
    sed "s#@SESSION_BIN@#$SESSION_BIN_DST#g" "$PLEB_DESKTOP_IN" | write_root "$XSESSION_DST"

    # put `kilix` on PATH so `kilix desktop` / `kilix serve` etc. work anywhere
    log "linking kilix command -> $KILIX_LINK"
    link_command "$KILIX_DIR/kilix" "$KILIX_LINK" "kilix"

    log "linking kilix-settings command -> $KILIX_SETTINGS_LINK"
    link_command "$KILIX_DIR/kilix-settings" "$KILIX_SETTINGS_LINK" "kilix-settings"

    log "linking kilix-temps command -> $KILIX_TEMPS_LINK"
    link_command "$KILIX_TEMPS_BIN" "$KILIX_TEMPS_LINK" "kilix-temps"

    log "linking tmux-tui command -> $TMUX_TUI_LINK"
    link_command "$TMUX_TUI_BIN" "$TMUX_TUI_LINK" "tmux-tui"

    log "linking tmux-cli command alias -> $TMUX_CLI_LINK"
    link_command "$TMUX_CLI_BIN" "$TMUX_CLI_LINK" "tb"

    # Fallback for shells whose PATH misses the published links; a taken `tb`
    # name is reported and left alone, so on a complete install this is a
    # visible no-op rather than a second `tb`.
    provision_tb_shell_alias

    # One closure installs both TUIs, so either both are there or neither is; a
    # link to an absent target would only turn a dimmed widget into a broken
    # command.
    if [ -x "$KILIX_VOICE_TTS_BIN" ] && [ -x "$KILIX_VOICE_STT_BIN" ]; then
        log "linking kilix-tts command -> $KILIX_VOICE_TTS_LINK"
        link_command "$KILIX_VOICE_TTS_BIN" "$KILIX_VOICE_TTS_LINK" "kilix-tts"

        log "linking kilix-stt command -> $KILIX_VOICE_STT_LINK"
        link_command "$KILIX_VOICE_STT_BIN" "$KILIX_VOICE_STT_LINK" "kilix-stt"
    else
        warn "Kilix Voice is not installed; kilix-tts and kilix-stt stay off PATH"
    fi

    # and `pleb` itself, so `pleb update` / `pleb status` etc. work anywhere
    # (bin/pleb resolves its checkout through the symlink via readlink -f)
    log "linking pleb command -> $PLEB_LINK"
    link_command "$PLEB_ROOT/bin/pleb" "$PLEB_LINK" "pleb"

    log "done. Log out, then at the LightDM greeter pick the session"
    info "menu (gear/badge near the login box) -> \"Pleb\" -> log in."
    warn "verify the engine first:  pleb doctor"
}

# do_uninstall — remove the system session files and command links. Checkouts,
# caches/state, and packages installed as dependencies are intentionally kept.
do_uninstall() {
    if [ "$PLEB_PACKAGED" = 1 ]; then
        die "Pleb is installed from Debian packages; remove it with: sudo apt remove pleb"
    fi
    local removed=0
    for f in "$XSESSION_DST" "$SESSION_BIN_DST" "$PLEB_RECOVERY_DOC_DST" \
            "$OPENBOX_CONFIG_DST" "$NOTIFICATION_THEME_DST" "$PLEB_DISPLAYS_DST" "$PLEB_LOCK_DST"; do
        if [ -e "$f" ] || [ -L "$f" ]; then
            log "removing $f"
            run_root rm -f "$f"
            removed=1
        fi
    done
    local module
    for module in $PLEB_CAPTURE_MODULES; do
        f="/usr/local/lib/pleb/$module"
        if [ -e "$f" ] || [ -L "$f" ]; then
            log "removing $f"
            run_root rm -f "$f"
            removed=1
        fi
    done
    for f in "$LID_POLICY_DST" /usr/local/lib/pleb/capture_transport.so \
            /usr/local/lib/pleb/screensaver.py /usr/local/lib/pleb/session-bin/xdg-screensaver \
            /usr/local/lib/pleb/notification_center.py /usr/local/lib/pleb/.notification_center.py.new \
            /usr/local/share/xdg-desktop-portal/portals/pleb.portal \
            /usr/local/share/dbus-1/services/org.freedesktop.impl.portal.desktop.pleb.service; do
        if [ -e "$f" ] || [ -L "$f" ]; then
            log "removing $f"
            run_root rm -f "$f"
            removed=1
        fi
    done
    # Never recursively remove this private PATH directory or operator files.
    local shim_dir=/usr/local/lib/pleb/session-bin
    if [ -d "$shim_dir" ] && [ ! -L "$shim_dir" ] \
            && [ "$(stat -c '%u' "$shim_dir" 2>/dev/null)" = 0 ] \
            && [ -z "$(ls -A -- "$shim_dir" 2>/dev/null)" ]; then
        run_root rmdir -- "$shim_dir" || true
    fi
    # prune the Pleb-owned Openbox directories, leaf first, and only at the exact
    # paths install_openbox_profile creates: a customized OPENBOX_CONFIG_DST is
    # left alone entirely. Each one must still be a real, root-owned, empty
    # directory, and `rmdir` is never recursive, so nothing else is removed.
    if [ "$OPENBOX_CONFIG_DST" = /usr/local/share/pleb/openbox/rc.xml ]; then
        for d in /usr/local/share/pleb/openbox /usr/local/share/pleb; do
            [ -d "$d" ] && [ ! -L "$d" ] \
                && [ "$(stat -c '%u' "$d" 2>/dev/null)" = 0 ] \
                && [ -z "$(ls -A -- "$d" 2>/dev/null)" ] || continue
            log "removing empty $d"
            if run_root rmdir -- "$d"; then
                removed=1
            fi
        done
    fi
    # Keep packaged Smoke files and any other local theme content. Removing the
    # local override lets the unchanged Smoke setting resolve to the package.
    if [ "$NOTIFICATION_THEME_DST" = /usr/local/share/themes/Smoke/xfce-notify-4.0/gtk.css ]; then
        for d in /usr/local/share/themes/Smoke/xfce-notify-4.0 /usr/local/share/themes/Smoke; do
            [ -d "$d" ] && [ ! -L "$d" ] \
                && [ "$(stat -c '%u' "$d" 2>/dev/null)" = 0 ] \
                && [ -z "$(ls -A -- "$d" 2>/dev/null)" ] || continue
            if run_root rmdir -- "$d"; then
                removed=1
            fi
        done
    fi
    # remove the kilix command symlink, but only if it points at our checkout
    if [ -L "$KILIX_LINK" ] && [ "$(readlink "$KILIX_LINK")" = "$KILIX_DIR/kilix" ]; then
        log "removing kilix command symlink $KILIX_LINK"
        run_root rm -f "$KILIX_LINK"
        removed=1
    fi
    if [ -L "$KILIX_SETTINGS_LINK" ] \
            && [ "$(readlink "$KILIX_SETTINGS_LINK")" = "$KILIX_DIR/kilix-settings" ]; then
        log "removing kilix-settings command symlink $KILIX_SETTINGS_LINK"
        run_root rm -f "$KILIX_SETTINGS_LINK"
        removed=1
    fi
    if [ -L "$KILIX_TEMPS_LINK" ] \
            && [ "$(readlink "$KILIX_TEMPS_LINK")" = "$KILIX_TEMPS_BIN" ]; then
        log "removing kilix-temps command symlink $KILIX_TEMPS_LINK"
        run_root rm -f "$KILIX_TEMPS_LINK"
        removed=1
    fi
    if [ -L "$TMUX_TUI_LINK" ] \
            && [ "$(readlink "$TMUX_TUI_LINK")" = "$TMUX_TUI_BIN" ]; then
        log "removing tmux-tui command symlink $TMUX_TUI_LINK"
        run_root rm -f "$TMUX_TUI_LINK"
        removed=1
    fi
    if [ -L "$TMUX_CLI_LINK" ] \
            && [ "$(readlink "$TMUX_CLI_LINK")" = "$TMUX_CLI_BIN" ]; then
        log "removing tb command symlink $TMUX_CLI_LINK"
        run_root rm -f "$TMUX_CLI_LINK"
        removed=1
    fi
    if [ -L "$KILIX_VOICE_TTS_LINK" ] \
            && [ "$(readlink "$KILIX_VOICE_TTS_LINK")" = "$KILIX_VOICE_TTS_BIN" ]; then
        log "removing kilix-tts command symlink $KILIX_VOICE_TTS_LINK"
        run_root rm -f "$KILIX_VOICE_TTS_LINK"
        removed=1
    fi
    if [ -L "$KILIX_VOICE_STT_LINK" ] \
            && [ "$(readlink "$KILIX_VOICE_STT_LINK")" = "$KILIX_VOICE_STT_BIN" ]; then
        log "removing kilix-stt command symlink $KILIX_VOICE_STT_LINK"
        run_root rm -f "$KILIX_VOICE_STT_LINK"
        removed=1
    fi
    # likewise the pleb command symlink, only if it points at our checkout
    if [ -L "$PLEB_LINK" ] && [ "$(readlink "$PLEB_LINK")" = "$PLEB_ROOT/bin/pleb" ]; then
        log "removing pleb command symlink $PLEB_LINK"
        run_root rm -f "$PLEB_LINK"
        removed=1
    fi
    # also drop autologin if it points at pleb
    if [ -f "$AUTOLOGIN_CONF" ]; then
        log "removing autologin config $AUTOLOGIN_CONF"
        run_root rm -f "$AUTOLOGIN_CONF"
        removed=1
    fi
    if [ "$removed" = 1 ]; then log "uninstalled."; else warn "nothing installed."; fi
}
