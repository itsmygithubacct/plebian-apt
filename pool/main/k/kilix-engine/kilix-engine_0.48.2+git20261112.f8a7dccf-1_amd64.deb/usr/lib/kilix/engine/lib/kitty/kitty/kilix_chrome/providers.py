"""Small providers for non-sensor Kilix top-bar widgets."""

import os
import time
from datetime import datetime

from ..utils import which
from .settings import chrome_enabled, chrome_value

VOLUME_WIDGET_ACTION = 'kilix_show_volume_widget'
NETWORK_WIDGET_ACTION = 'kilix_show_network_widget'
CALENDAR_WIDGET_ACTION = 'kilix_show_calendar_widget'
DATE_WIDGET_ACTION = 'kilix_show_date_widget'
START_MENU_ACTION = 'kilix_show_start_menu'
VOLUME_GLYPH = chr(0xf028)
NETWORK_GLYPH = chr(0xf1eb)
CALENDAR_GLYPH = chr(0xf073)


def start_menu_segment() -> tuple[str, str] | None:
    """Return the compact text-tier Start badge and its chrome action."""
    from ..kilix_windows import in_pleb_session
    default = '1' if in_pleb_session() else '0'
    if not chrome_enabled('KILIX_CHROME_START_MENU', default):
        return None
    # Use the conventional menu mark rather than a brand-specific private-use
    # glyph: it remains recognizable with every configured terminal font.
    return ' ☰ ', START_MENU_ACTION


def volume_segment() -> tuple[str, str] | None:
    return ((f' {VOLUME_GLYPH} ', VOLUME_WIDGET_ACTION)
            if chrome_enabled('KILIX_CHROME_VOLUME') else None)


def network_segment() -> tuple[str, str] | None:
    return ((f' {NETWORK_GLYPH} ', NETWORK_WIDGET_ACTION)
            if chrome_enabled('KILIX_CHROME_NETWORK') else None)


def local_now() -> datetime:
    # Refresh libc's timezone cache after a user changes the system timezone.
    # TZ, when supplied by the user's session, retains its usual precedence.
    if hasattr(time, 'tzset'):
        time.tzset()
    return datetime.now().astimezone()


def clock_segment() -> str | None:
    if not chrome_enabled('KILIX_CHROME_CLOCK'):
        return None
    fmt = chrome_value('KILIX_CHROME_CLOCK_FORMAT', '%Y-%m-%d %I:%M %p') or '%Y-%m-%d %I:%M %p'
    try:
        text = local_now().strftime(fmt)
    except Exception:
        text = local_now().strftime('%Y-%m-%d %I:%M %p')
    return f' {text} '


def clock_segments() -> tuple[tuple[str, str], ...]:
    ans: list[tuple[str, str]] = []
    if chrome_enabled('KILIX_CHROME_CALENDAR'):
        ans.append((f' {CALENDAR_GLYPH}', CALENDAR_WIDGET_ACTION))
    if (clock := clock_segment()) is not None:
        ans.append((clock, DATE_WIDGET_ACTION))
    return tuple(ans)


def volume_target(mode: str = 'full') -> list[str] | None:
    suffix = [] if mode == 'full' else [f'--{mode}']
    if executable := which('kilix-volume'):
        return [executable, *suffix]
    if kilix_home := os.environ.get('KILIX_HOME'):
        kilix = os.path.join(kilix_home, 'kilix')
        if os.path.isfile(kilix) and os.access(kilix, os.X_OK):
            return [kilix, 'volume', *suffix]
    if mode == 'full' and (fallback := (which('pulsemixer') or which('alsamixer'))):
        return [fallback]
    return None


def settings_target() -> list[str] | None:
    if executable := which('kilix'):
        return [executable, 'settings']
    if kilix_home := os.environ.get('KILIX_HOME'):
        kilix = os.path.join(kilix_home, 'kilix')
        if os.path.isfile(kilix) and os.access(kilix, os.X_OK):
            return [kilix, 'settings']
    return None
