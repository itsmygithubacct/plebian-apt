"""kilix-temps — live temperature, fan, and thermal-headroom dashboard."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "src"))

from kilix_temps.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
