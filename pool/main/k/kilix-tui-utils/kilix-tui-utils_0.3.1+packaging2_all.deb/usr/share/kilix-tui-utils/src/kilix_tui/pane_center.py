"""One enriched snapshot of every pane in the current Kilix window.

Kitty already knows the page tree and foreground processes. The PTY broker
knows attachment and journal state. Coding agents know which conversation a
process owns and whether its latest turn has finished. This module joins those
three views once so the interactive pane center and its CLI cannot disagree.

Refresh work is deliberately bounded by the live panes: one kitty query (made
by the caller), one broker ``list`` call, and ``/proc`` descriptor reads only
for PIDs kitty reported. It never walks a user's complete Codex history.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import time
from dataclasses import dataclass, field
from typing import Any

from kilix_rollout import claude, codex, grok, liveness, omp
from kilix_rollout.model import Session

from . import kitty_rc


_UUID = re.compile(
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",
    re.I,
)
_SHELLS = frozenset({
    "ash", "bash", "dash", "fish", "ksh", "nu", "sh", "tcsh", "zsh",
})


def _integer(value: object) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _one_line(value: object, limit: int = 160) -> str:
    return " ".join(str(value or "").split())[:limit]


def _short_path(path: str) -> str:
    home = os.path.expanduser("~")
    if path == home:
        return "~"
    if path.startswith(home + os.sep):
        return "~" + path[len(home):]
    return path


@dataclass(frozen=True)
class BrokerStatus:
    id: str
    broker_pid: int = 0
    child_pid: int = 0
    foreground_pgrp: int = 0
    started_millis: int = 0
    journal_bytes: int = 0
    journal_epoch: int = 0
    attached: bool = False
    replay_complete: bool = False
    rows: int = 0
    columns: int = 0
    cwd: str = ""
    command: str = ""

    @classmethod
    def parse(cls, record: dict[str, Any]) -> "BrokerStatus | None":
        session_id = str(record.get("id") or "")
        if not kitty_rc.valid_broker_session(session_id):
            return None
        return cls(
            id=session_id,
            broker_pid=_integer(record.get("broker_pid")),
            child_pid=_integer(record.get("child_pid")),
            foreground_pgrp=_integer(record.get("foreground_pgrp")),
            started_millis=_integer(record.get("started_millis")),
            journal_bytes=_integer(record.get("journal_bytes")),
            journal_epoch=_integer(record.get("journal_epoch")),
            attached=bool(record.get("attached")),
            replay_complete=bool(record.get("replay_complete")),
            rows=_integer(record.get("rows")),
            columns=_integer(record.get("columns")),
            cwd=str(record.get("cwd") or ""),
            command=str(record.get("command") or ""),
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "session_id": self.id,
            "attached": self.attached,
            "replay_complete": self.replay_complete,
            "broker_pid": self.broker_pid or None,
            "child_pid": self.child_pid or None,
            "foreground_pgrp": self.foreground_pgrp or None,
            "started_millis": self.started_millis or None,
            "journal_bytes": self.journal_bytes,
            "journal_epoch": self.journal_epoch,
            "rows": self.rows or None,
            "columns": self.columns or None,
            "cwd": self.cwd or None,
            "command": self.command or None,
        }


@dataclass
class PaneInfo:
    pane: kitty_rc.Pane
    page_index: int
    activity: str = "unknown"
    doing: str = ""
    coding: Session | None = None
    broker: BrokerStatus | None = None

    @property
    def age(self) -> str:
        if self.coding is None or self.coding.updated <= 0:
            return ""
        return self.coding.age()

    @property
    def searchable(self) -> str:
        session = self.coding
        return " ".join(filter(None, (
            self.pane.title,
            self.pane.process,
            self.pane.cwd,
            self.pane.page_title,
            self.activity,
            self.doing,
            session.provider if session else "",
            session.session_id if session else "",
        )))

    def to_dict(self) -> dict[str, object]:
        pane = self.pane
        return {
            "pane_id": pane.id,
            "page": {
                "id": pane.page_id,
                "index": self.page_index,
                "title": pane.page_title,
                "os_window_id": pane.os_window_id,
            },
            "focused": pane.is_focused,
            "title": pane.title,
            "cwd": pane.cwd or None,
            "activity": self.activity,
            "activity_readiness_verified": False,
            "doing": self.doing or None,
            "process": {
                "name": pane.process or None,
                "argv": list(pane.argv),
                "child_pid": pane.child_pid or None,
                "foreground": [
                    {
                        "pid": process.pid or None,
                        "argv": list(process.argv),
                        "cwd": process.cwd or None,
                    }
                    for process in pane.processes
                ],
            },
            "coding_session": self.coding.to_dict() if self.coding else None,
            "broker": self.broker.to_dict() if self.broker else (
                {"session_id": pane.broker_session, "available": False}
                if pane.broker_session else None
            ),
        }


@dataclass
class Snapshot:
    panes: list[PaneInfo] = field(default_factory=list)
    generated_at: float = field(default_factory=time.time)
    self_pane_id: int = 0
    broker_available: bool = False
    warnings: tuple[str, ...] = ()

    def by_id(self, pane_id: int) -> PaneInfo | None:
        return next((item for item in self.panes if item.pane.id == pane_id), None)

    def resolve(self, target: str) -> PaneInfo:
        """Resolve an ID, session prefix, exact label, or unique substring."""
        raw = target.strip()
        if not raw:
            raise ValueError("a pane target is required")
        if raw.isdigit():
            item = self.by_id(int(raw))
            if item is not None:
                return item
            raise ValueError(f"no live pane has ID {raw}")

        folded = raw.casefold()
        broker_matches = [
            item for item in self.panes
            if item.pane.broker_session.casefold().startswith(folded)
        ]
        coding_matches = [
            item for item in self.panes
            if item.coding
            and item.coding.session_id.casefold().startswith(folded)
        ]
        exact = [
            item for item in self.panes
            if folded in {
                item.pane.title.casefold(),
                item.pane.process.casefold(),
            }
        ]
        matches = broker_matches or coding_matches or exact
        if not matches:
            matches = [
                item for item in self.panes
                if folded in item.searchable.casefold()
            ]
        unique = {item.pane.id: item for item in matches}
        if len(unique) == 1:
            return next(iter(unique.values()))
        if not unique:
            raise ValueError(f"no live pane matches {target!r}")
        choices = ", ".join(
            f"{item.pane.id}:{item.pane.title or item.pane.process}"
            for item in sorted(unique.values(), key=lambda value: value.pane.id)
        )
        raise ValueError(f"pane target {target!r} is ambiguous: {choices}")

    def to_dict(self) -> dict[str, object]:
        page_ids = {item.pane.page_id for item in self.panes}
        return {
            "schema": "kilix.panes/v1",
            "generated_at": self.generated_at,
            "self_pane_id": self.self_pane_id or None,
            "counts": {"pages": len(page_ids), "panes": len(self.panes)},
            "broker_available": self.broker_available,
            "warnings": list(self.warnings),
            "panes": [item.to_dict() for item in self.panes],
        }


def _broker_statuses() -> tuple[dict[str, BrokerStatus], bool, str]:
    executable = os.environ.get("KITTY_PTY_BROKER_EXECUTABLE", "")
    runtime = os.environ.get("KITTY_PTY_BROKER_RUNTIME", "")
    if not executable or not runtime or not os.access(executable, os.X_OK):
        return {}, False, "PTY broker status is unavailable"
    try:
        done = subprocess.run(
            [executable, "--runtime-dir", runtime, "list", "--json"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=2,
            check=False,
        )
        payload = json.loads(done.stdout) if done.returncode == 0 else None
    except (OSError, subprocess.SubprocessError, ValueError):
        return {}, False, "PTY broker did not answer"
    if not isinstance(payload, list):
        return {}, False, "PTY broker returned malformed status"
    found: dict[str, BrokerStatus] = {}
    for record in payload:
        status = BrokerStatus.parse(record) if isinstance(record, dict) else None
        if status is not None:
            found[status.id] = status
    return found, True, ""


_AGENT_NAMES = {
    "claude": "claude", "claude-code": "claude", "codex": "codex", "grok": "grok",
    "omp": "omp", "kimi": "kimi", "kimi-code": "kimi",
}
# Programs that only host a command: their arguments are not themselves an agent. Multiplexers and remote
# shells (the needle tmux hint handles `tmux … claude`), and `kitten run-shell … claude`, the launcher
# Kilix starts every coding pane with, whose child (the agent itself) is listed as its own process.
_HOSTS = frozenset({"tmux", "screen", "ssh", "mosh", "mosh-client", "kitten"})


def _mentioned(argv) -> list[str]:
    """The agents an argv mentions, in order of first mention; empty for a host program."""
    argv = tuple(argv)
    if not argv or os.path.basename(str(argv[0])).casefold() in _HOSTS:
        return []
    found: list[str] = []
    for value in argv:
        for part in str(value).replace("\\", "/").split("/"):
            name = part.casefold()
            provider = _AGENT_NAMES.get(name)
            if provider is None:
                for known, candidate in _AGENT_NAMES.items():
                    if name.startswith((known + "-", known + ".")):
                        provider = candidate
                        break
            if provider is not None and provider not in found:
                found.append(provider)
    return found


def _process_agent(process: kitty_rc.Process) -> str:
    mentioned = _mentioned(process.argv)
    return mentioned[0] if mentioned else ""


def _claude_native(argv) -> bool:
    """The one form accepted for a Claude state: the program itself, `argv[0]` named exactly `claude`.

    `node …/cli.js`, `bun`, `env claude`, a differently spelled or aliased name are possible Claudes
    (so they make a pane ambiguous) but never named: they read `agent`.
    """
    argv = tuple(argv)
    return bool(argv) and os.path.basename(str(argv[0])) == "claude"


def _certifiable(pane: kitty_rc.Pane):
    """The one process of a pane that may be given a Claude state, or None.

    Exactly one process may mention any agent at all, it may mention only Claude, and it must be native.
    """
    possible = [(process, _mentioned(process.argv)) for process in pane.processes]
    possible = [(process, kinds) for process, kinds in possible if kinds]
    if len(possible) != 1:
        return None
    process, kinds = possible[0]
    return process if kinds == ["claude"] and _claude_native(process.argv) else None


def _argument_session(process: kitty_rc.Process) -> str:
    argv = process.argv
    for index, value in enumerate(argv):
        if value in ("--resume", "--session") and index + 1 < len(argv):
            return argv[index + 1].lower()
        for prefix in ("--resume=", "--session="):
            if value.startswith(prefix):
                return value[len(prefix):].lower()
    for value in argv:
        match = _UUID.fullmatch(value.strip("{}"))
        if match:
            return match.group(0).lower()
    return ""


MAX_CMDLINE_BYTES = 1 << 20
MAX_ENVIRON_BYTES = 4 << 20


def _live_argv(pid: int, *, proc_root: str) -> tuple[str, ...] | None:
    """The command line the process has NOW, from /proc/<pid>/cmdline.

    None if unreadable, not valid UTF-8, or longer than the bound: a prefix is never returned, so
    two results can only be equal when both are the whole command line.
    """
    if pid <= 0:
        return None
    raw = liveness.read_bounded(os.path.join(proc_root, str(pid), "cmdline"), MAX_CMDLINE_BYTES)
    if raw is None:
        return None
    parts = raw.split(b"\0")
    if parts and parts[-1] == b"":
        parts.pop()
    try:
        return tuple(part.decode("utf-8") for part in parts) or None
    except UnicodeDecodeError:
        return None


def _live_environment(pid: int, *, proc_root: str) -> dict[str, str] | None:
    """The environment the process started with; None if unreadable, not UTF-8 or longer than the bound."""
    raw = liveness.read_bounded(os.path.join(proc_root, str(pid), "environ"), MAX_ENVIRON_BYTES)
    if raw is None:
        return None
    found: dict[str, str] = {}
    try:
        for entry in raw.split(b"\0"):
            name, separator, value = entry.partition(b"=")
            if separator and name:
                key, text = name.decode("utf-8"), value.decode("utf-8")
                # Which of two different values a program honours is its own business: the context is unknown.
                if key in ("HOME", "CLAUDE_CONFIG_DIR", "GROK_HOME") and found.get(key, text) != text:
                    return None
                found[key] = text
    except UnicodeDecodeError:
        return None
    return found


def _file_version(path):
    try:
        info = os.stat(path)
        return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns
    except OSError:
        return None


def _minimal_session(
    provider: str,
    pane: kitty_rc.Pane,
    *,
    session_id: str = "",
    status: str = "unknown",
    cwd: str = "",
    title: str = "",
    pids: tuple[int, ...] = (),
    version: str = "",
    entrypoint: str = "",
) -> Session:
    return Session(
        provider=provider,
        session_id=session_id or "unknown",
        path="",
        cwd=cwd or pane.cwd,
        original_cwd=cwd or pane.cwd,
        title=title or pane.title,
        updated=0,
        state="live",
        pids=pids or pane.pids,
        live_status=status or "unknown",
        version=version,
        entrypoint=entrypoint,
    )


def _activity(session: Session | None, pane: kitty_rc.Pane) -> str:
    if session is not None:
        status = session.live_status.strip().casefold().replace("_", "-")
        if session.provider == "claude":
            return claude.ACTIVITY.get(status, "agent")
        if status in {"idle", "ready"}:
            return "idle"
        if status in {"working", "active", "busy", "running"}:
            return "working"
        if status in {"waiting", "wait", "blocked"}:
            return "waiting"
        return "agent"
    process = pane.process.casefold()
    if process in _SHELLS:
        return "shell"
    if process in {"ssh", "mosh-client"}:
        return "remote"
    return "running" if process else "unknown"


def _doing(session: Session | None, pane: kitty_rc.Pane) -> str:
    if session is not None:
        if session.last_user_message:
            return _one_line(session.last_user_message)
    if pane.title and pane.title.casefold() != pane.process.casefold():
        return _one_line(pane.title)
    if session is not None and session.title:
        return _one_line(session.title)
    if pane.argv:
        return _one_line(" ".join(pane.argv))
    return pane.process


class Inspector:
    """Fresh, bounded process and provider observations for each snapshot."""

    def __init__(self, *, proc_root: str = "/proc") -> None:
        self.proc_root = proc_root
        self._listed_pids: list[int] = []
        self._checks = {}

    def _identity(self, process):
        """Bracket a whole command line with the process instance and user."""
        try:
            if os.stat(os.path.join(self.proc_root, str(process.pid))).st_uid != os.getuid():
                return None
        except OSError:
            return None
        start = liveness.start_ticks(process.pid, proc_root=self.proc_root)
        argv = _live_argv(process.pid, proc_root=self.proc_root)
        if (start is None or argv != tuple(process.argv)
                or liveness.start_ticks(process.pid, proc_root=self.proc_root) != start):
            return None
        return start, argv

    def _single(self, pane, provider):
        possible = [p for p in pane.processes if _mentioned(p.argv)]
        if len(possible) != 1:
            return None
        process = possible[0]
        argv = process.argv
        native = bool(argv) and os.path.basename(argv[0]) == provider
        hosted = (len(argv) > 1 and os.path.basename(argv[0]) in {"node", "bun"}
                  and os.path.basename(argv[1]) == provider)
        if (not (native or hosted) or _mentioned(argv) != [provider]
                or self._listed_pids.count(process.pid) != 1):
            return None
        return process

    def _codex_owner(self, pane):
        """One native writer, optionally behind its verified nonwriting Node launcher."""
        possible = [p for p in pane.processes if _mentioned(p.argv)]
        if len(possible) == 1:
            process = self._single(pane, "codex")
            identity = self._identity(process) if process is not None else None
            return (process, (identity,)) if identity is not None else None
        if len(possible) != 2 or any(
                self._listed_pids.count(p.pid) != 1 or _mentioned(p.argv) != ["codex"]
                for p in possible):
            return None
        native = [p for p in possible if p.argv and os.path.basename(p.argv[0]) == "codex"]
        wrappers = [p for p in possible if len(p.argv) > 1
                    and os.path.basename(p.argv[0]) == "node"
                    and os.path.basename(p.argv[1]) == "codex"]
        if len(native) != 1 or len(wrappers) != 1:
            return None
        child, wrapper = native[0], wrappers[0]
        identities = tuple(self._identity(p) for p in (wrapper, child))
        raw = liveness.read_bounded(os.path.join(self.proc_root, str(child.pid), "stat"),
                                    liveness.MAX_PROC_BYTES)
        if raw is None or any(identity is None or not identity[0].isascii()
                              or not identity[0].isdigit() for identity in identities):
            return None
        fields = raw.rsplit(b")", 1)[-1].split()
        if (len(fields) < 20 or fields[1] != str(wrapper.pid).encode()
                or fields[19] != identities[1][0].encode()
                or int(identities[0][0]) > int(identities[1][0])
                or self._held(wrapper) != ()
                or tuple(self._identity(p) for p in (wrapper, child)) != identities):
            return None
        return child, identities

    def _held(self, process):
        """Writable, nondeleted rollouts, with the descriptor and inode identities."""
        directory = os.path.join(self.proc_root, str(process.pid), "fd")
        try:
            names = os.listdir(directory)
            found = []
            for name in names:
                descriptor = os.path.join(directory, name)
                path = os.readlink(descriptor)
                if not (os.path.isabs(path) and os.path.basename(path).startswith("rollout-")
                        and path.endswith(".jsonl")):
                    continue
                info = liveness.read_bounded(os.path.join(
                    self.proc_root, str(process.pid), "fdinfo", name), 65536)
                if info is None:
                    return None
                flags = [line.split()[1] for line in info.decode().splitlines()
                         if line.startswith("flags:")]
                if len(flags) != 1 or int(flags[0], 8) & os.O_ACCMODE == os.O_RDONLY:
                    continue
                stat = os.stat(descriptor)
                current = os.stat(path)
                if (stat.st_dev, stat.st_ino) != (current.st_dev, current.st_ino):
                    return None
                found.append((os.path.realpath(path), name, stat.st_dev, stat.st_ino))
            return tuple(sorted(found))
        except (OSError, ValueError, UnicodeError, IndexError):
            return None

    def _codex_for(self, pane: kitty_rc.Pane) -> Session | None:
        owner = self._codex_owner(pane)
        if owner is None:
            return None
        process = owner[0]
        identity = self._identity(process)
        held = self._held(process)
        if identity is None or not held or len({row[0] for row in held}) != 1:
            return None
        path = held[0][0]
        # A second listed process holding the same log makes the owner ambiguous.
        for other in self._processes:
            if other.pid != process.pid and _process_agent(other) == "codex":
                other_held = self._held(other)
                if other_held is None or any(row[2:] == held[0][2:] for row in other_held):
                    return None
        before = _file_version(path)
        session = codex.session_from_path(path, pids=(process.pid,))
        started = liveness.start_time(process.pid, proc_root=self.proc_root)
        if (session is None or not started or not before
                or before != _file_version(path) or self._held(process) != held
                or self._identity(process) != identity):
            return None
        # An open writer does not make a historical completion current after resume.
        details = codex._inspect(path, include_agent_message=False)
        if (not details.get("boundary_time") or details["boundary_time"] < started
                or details["boundary_time"] > time.time()
                or before != _file_version(path) or self._identity(process) != identity
                or self._held(process) != held or self._codex_owner(pane) != owner):
            return None
        self._checks[pane.id] = lambda: (
            _file_version(path) == before and self._held(process) == held
            and self._identity(process) == identity and self._codex_owner(pane) == owner)
        return session

    def _grok_for(self, pane):
        process = self._single(pane, "grok")
        if process is None:
            return None
        identity = self._identity(process)
        environment = _live_environment(process.pid, proc_root=self.proc_root)
        if identity is None or environment is None:
            return None
        base = environment.get("GROK_HOME") or (
            os.path.join(environment["HOME"], ".grok") if environment.get("HOME") else "")
        if not os.path.isabs(base):
            return None
        row = grok.live_record(base, process.pid, proc_root=self.proc_root)
        if row is None:
            return None
        session_id, cwd, opened = row
        folder = grok.session_dir(session_id, cwd, base)
        path = os.path.join(folder, "events.jsonl")
        before = _file_version(path)
        status = grok.observed_activity(folder, after=opened)
        if (not before or before != _file_version(path)
                or grok.live_record(base, process.pid, proc_root=self.proc_root) != row
                or _live_environment(process.pid, proc_root=self.proc_root) != environment
                or self._identity(process) != identity):
            return None
        self._checks[pane.id] = lambda: (
            _file_version(path) == before
            and grok.live_record(base, process.pid, proc_root=self.proc_root) == row
            and _live_environment(process.pid, proc_root=self.proc_root) == environment
            and self._identity(process) == identity)
        return _minimal_session("grok", pane, session_id=session_id, cwd=cwd,
                                status=status, pids=(process.pid,))

    def _observe(self, pid: int):
        """(start time, command line, config directory) of the process, read as one bracketed unit.

        Start time first, then command line and environment, then the start time again: a process that
        was replaced meanwhile, or a read that was cut off, gives None instead of a mixture.
        """
        start = liveness.start_ticks(pid, proc_root=self.proc_root)
        argv = _live_argv(pid, proc_root=self.proc_root)
        environment = _live_environment(pid, proc_root=self.proc_root)
        if start is None or argv is None or environment is None:
            return None
        if liveness.start_ticks(pid, proc_root=self.proc_root) != start:
            return None
        config = environment.get("CLAUDE_CONFIG_DIR") or (
            os.path.join(environment["HOME"], ".claude") if environment.get("HOME") else "")
        if not config or not os.path.isabs(config):
            return None
        return start, argv, config

    def _fresh_row(self, config: str, pid: int):
        """The one registry row of this config directory that names the pid, read now; None otherwise."""
        records = liveness.registry_records(
            os.path.join(config, "sessions"), proc_root=self.proc_root, require_start=True)
        rows = [(session_id, record) for session_id, group in records.items()
                for record in group if record.get("pid") == pid]
        return rows[0] if len(rows) == 1 else None

    def _certify(self, process):
        """(observation, session id, row) when this Claude process is named exactly now, else None.

        Nothing is carried between panes or snapshots: the process is observed, its registry row is read
        from disk, the process is observed again and the row read again, and everything must be equal.
        """
        snapshot = tuple(process.argv)
        if not _claude_native(snapshot):
            return None
        first = self._observe(process.pid)
        if first is None or first[1] != snapshot:
            return None
        found = self._fresh_row(first[2], process.pid)
        if found is None or str(found[1].get("procStart")) != first[0]:
            return None
        if self._observe(process.pid) != first or self._fresh_row(first[2], process.pid) != found:
            return None
        return first, found[0], found[1]

    def _claude_by_pid(self, processes) -> dict[int, tuple[str, dict[str, object]]]:
        """pid -> (session id, registry row) for the Claude processes that a row names exactly.

        A process is recognised as Claude only in its native form (`_claude_native`); its whole live
        command line must equal the pane's; its row is in the registry of its own config directory
        (`CLAUDE_CONFIG_DIR`, else `$HOME/.claude`, both from its environment), names its pid, and
        carries a `procStart` equal to its start time; no other row names the pid. Each pane is
        certified from fresh reads (`_certify`), and once every pane is done all of them are checked
        once more, so a process that changed while a later pane was inspected is dropped. What remains
        is the window that any observer has between its last read and the use of its answer.
        """
        # A pid listed more than once (in two panes, or twice in one) is a contradictory census: whichever
        # entry is observed, the observation would be lent to the other. Every such candidate is refused.
        processes = list(processes)
        listed = [process.pid for process in processes]
        processes = [process for process in processes if listed.count(process.pid) == 1]
        certified = {}
        for process in processes:
            result = self._certify(process)
            if result is not None:
                certified[process.pid] = result
        found = {}
        for process in processes:
            result = certified.get(process.pid)
            if result is None:
                continue
            first, session_id, row = result
            if self._observe(process.pid) == first and self._fresh_row(first[2], process.pid) == (session_id, row):
                found[process.pid] = (session_id, row)
        return found

    def _coding_for(
        self,
        pane: kitty_rc.Pane,
        claude_by_pid: dict[int, tuple[str, dict[str, object]]],
        ambiguous_omp_cwds: frozenset[str] = frozenset(),
    ) -> Session | None:
        possible = [p for p in pane.processes if _mentioned(p.argv)]
        if session := self._codex_for(pane):
            return session
        if (len(possible) > 1 or any(self._listed_pids.count(p.pid) != 1 for p in possible)):
            return _minimal_session(_process_agent(possible[0]), pane)
        for process in pane.processes:
            provider = _process_agent(process)
            if provider == "claude":
                known = claude_by_pid.get(process.pid) if _certifiable(pane) is not None else None
                session_id, record = known if known else (
                    _argument_session(process), {})
                return _minimal_session(
                    "claude", pane,
                    session_id=session_id,
                    status=str(record.get("status") or "unknown"),
                    cwd=str(record.get("cwd") or ""),
                    title=str(record.get("name") or ""),
                    pids=(process.pid,) if process.pid else (),
                    version=str(record.get("version") or ""),
                    entrypoint=str(record.get("entrypoint") or ""),
                )
            if provider == "grok":
                return self._grok_for(pane) or _minimal_session(
                    "grok", pane, session_id=_argument_session(process),
                    pids=(process.pid,) if process.pid else ())
            if provider == "omp":
                started = liveness.start_time(process.pid, proc_root=self.proc_root)
                found = omp.session_for_pid(
                    process.pid, proc_root=self.proc_root, after=started
                ) if started else None
                marked = omp.has_terminal_marker(
                    process.pid, proc_root=self.proc_root, after=started
                ) if started else False
                if (found is None and not marked and started
                        and pane.cwd not in ambiguous_omp_cwds):
                    found = omp.newest_in(pane.cwd, after=started)
                if found is not None:
                    return _minimal_session(
                        "omp", pane, session_id=found.session_id,
                        status=omp.activity(found.path), cwd=found.cwd,
                        title=found.title, pids=(process.pid,))
                return _minimal_session("omp", pane, session_id=_argument_session(process),
                                        pids=(process.pid,) if process.pid else ())
            if provider == "kimi":
                return _minimal_session(
                    "kimi", pane,
                    session_id=_argument_session(process),
                    pids=(process.pid,) if process.pid else (),
                )
            if provider == "codex":
                return _minimal_session(
                    "codex", pane,
                    session_id=_argument_session(process),
                    pids=(process.pid,) if process.pid else (),
                )
        return None

    def snapshot(self, tree: kitty_rc.Tree) -> Snapshot:
        self._checks = {}
        self._processes = [p for pane in tree.panes for p in pane.processes]
        self._listed_pids = [p.pid for p in self._processes]
        brokers, broker_available, warning = _broker_statuses()
        claude_by_pid = self._claude_by_pid(
            process for pane in tree.panes for process in pane.processes)
        page_index = {
            page.id: page.index for page in tree.pages
        }
        omp_counts: dict[str, int] = {}
        for current in tree.panes:
            if any(_process_agent(process) == "omp" for process in current.processes):
                omp_counts[current.cwd] = omp_counts.get(current.cwd, 0) + 1
        ambiguous_omp_cwds = frozenset(
            cwd for cwd, count in omp_counts.items() if count > 1)
        panes = []
        for pane in tree.panes:
            coding = self._coding_for(pane, claude_by_pid, ambiguous_omp_cwds)
            broker = brokers.get(pane.broker_session)
            panes.append(PaneInfo(
                pane=pane,
                page_index=page_index.get(pane.page_id, 0),
                activity=_activity(coding, pane),
                doing=_doing(coding, pane),
                coding=coding,
                broker=broker,
            ))
        for item in panes:
            check = self._checks.get(item.pane.id)
            if check is not None and not check():
                item.coding.live_status = "unknown"
                item.activity = "agent"
        warnings = (warning,) if warning else ()
        return Snapshot(
            panes=panes,
            self_pane_id=kitty_rc.self_pane_id(),
            broker_available=broker_available,
            warnings=warnings,
        )


def format_bytes(value: int) -> str:
    amount = float(max(0, value))
    for suffix in ("B", "K", "M", "G", "T"):
        if amount < 1024 or suffix == "T":
            return f"{amount:.0f}{suffix}" if suffix == "B" else f"{amount:.1f}{suffix}"
        amount /= 1024
    return f"{value}B"


def table(snapshot: Snapshot, *, width: int = 0) -> str:
    """Compact human list; JSON remains the lossless agent interface."""
    rows = []
    for item in snapshot.panes:
        pane = item.pane
        agent = item.coding.provider if item.coding else "-"
        marker = "*" if pane.is_focused else " "
        rows.append([
            marker,
            str(pane.id),
            str(item.page_index),
            item.activity,
            agent,
            item.age or "-",
            item.doing or pane.title or pane.process or "-",
            _short_path(pane.cwd) or "-",
        ])
    headers = ["", "PANE", "PAGE", "STATE", "AGENT", "AGE", "WHAT", "CWD"]
    if not rows:
        return "(no panes)"
    widths = [
        max(len(headers[index]), *(len(row[index]) for row in rows))
        for index in range(len(headers))
    ]
    # Keep paths useful in ordinary terminals; the tail survives clipping.
    budget = width or 120
    fixed = sum(widths[:-2]) + len(widths) - 1
    widths[-2] = min(widths[-2], max(12, (budget - fixed) * 3 // 5))
    widths[-1] = min(widths[-1], max(12, budget - fixed - widths[-2]))

    def cell(value: str, index: int) -> str:
        allowance = widths[index]
        if len(value) > allowance:
            value = ("…" + value[-allowance + 1:]) if index == len(widths) - 1 \
                else (value[:allowance - 1] + "…")
        return value.ljust(allowance)

    output = [" ".join(cell(value, index) for index, value in enumerate(headers)).rstrip()]
    output.extend(
        " ".join(cell(value, index) for index, value in enumerate(row)).rstrip()
        for row in rows
    )
    return "\n".join(output)
