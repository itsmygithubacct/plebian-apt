"""kilix desktop — the desktop surface (the shell).

Owns the wallpaper, the icon grid, the launcher files and every "open
something" verb. The desktop folder is a real directory under Kilix 95's
per-user storage (override with $KILIX_DESKTOP_DIR):
plain files and directories dropped there appear as icons, and "Create
Launcher…" writes freedesktop-style .desktop files there. Programs launch
into new kilix tabs/windows over kitty remote control; X11 apps go through
`kilix run`; launcher and Help URLs go through Kilix's ordered real-browser
dispatcher.
"""
import configparser
import os
import shutil
import stat
import subprocess
import threading
import time

from PIL import Image
from kilix_sdk import content as kilix_content
try:
    from kilix_sdk import frontend_context
except ImportError:                  # older hosts retain their existing route
    frontend_context = None

import icons
import directory_listing
import durable_state
import nostalgia
import recycle
import theme as T
import vbox
import widgets as W
import wm
import host as kilix_host
import storage
import applications
import xdgapps

_here = os.path.dirname(os.path.abspath(__file__))
KILIX_HOME = kilix_host.find_kilix_home()
# Packaged locations first (Plebian-OS 0.2.4 Debian packages), then the
# /usr/local paths a checkout install writes. Each is a tuple searched in order.
PLEB_RECOVERY_DOC = "/usr/share/pleb/RECOVERY.md"
PLEB_RECOVERY_DOC_LEGACY = "/usr/local/share/doc/pleb/RECOVERY.md"
PLEBIAN_OS_UPDATE = ("/usr/bin/plebian-os-update", "/usr/local/bin/plebian-os-update")
PLEBIAN_OS_INSTALL_DEPS = ("/usr/sbin/plebian-os-install-deps",
                           "/usr/local/sbin/plebian-os-install-deps")
PLEBIAN_OS_SSH_SERVER = ("/usr/sbin/plebian-os-ssh-server",
                         "/usr/local/sbin/plebian-os-ssh-server")


def first_present(paths):
    """The first of PATHS that exists, or None."""
    for path in paths:
        if os.path.exists(path):
            return path
    return None

OPEN_MODES = ["kilix tab", "kilix os-window", "kilix fullscreen",
              "kilix run (X11 app)", "web browser"]
MODE_KEYS = {"kilix tab": "tab", "kilix os-window": "window",
             "kilix fullscreen": "fullscreen",
             "kilix run (X11 app)": "run", "web browser": "browse"}
ICON_CHOICES = ["exe", "terminal", "mux", "doc", "doc_text", "doc_image", "folder",
                "computer", "browser", "notepad", "documentreader", "settings", "display",
                "drive", "home", "run", "flame"]
NAME_ERROR = "Use a plain name, not a path."

TEXT_EXT = (".txt", ".md", ".rst", ".log", ".conf", ".cfg", ".ini", ".json",
            ".yaml", ".yml", ".toml", ".py", ".sh", ".c", ".h", ".go", ".rs",
            ".js", ".ts", ".html", ".css", ".xml", ".csv", ".diff", ".patch")


def child_path(base, name):
    """Return base/name, but only for a single user-visible path component."""
    if (not name or name in (".", "..") or "\0" in name
            or os.path.isabs(name) or os.path.basename(name) != name
            or (os.path.altsep and os.path.altsep in name)):
        raise ValueError(NAME_ERROR)
    return os.path.join(base, name)


IMG_EXT = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".ico", ".ppm",
           ".tiff")
# Files opened in Media Player, including native EnCodec and playlists.
AUDIO_EXT = (".mp3", ".flac", ".ogg", ".oga", ".opus", ".wav", ".aiff",
             ".aif", ".aifc", ".m4a", ".aac", ".wma", ".m3u", ".m3u8",
             ".pls", ".kenc")

WALL_COLORS = [("Teal (classic)", (0, 128, 128)),
               ("XP Blue", (58, 110, 165)), ("Navy", (0, 0, 128)),
               ("Black", (0, 0, 0)), ("Gray", (128, 128, 128)),
               ("Green", (0, 128, 0)), ("Plum", (128, 0, 128)),
               ("Maroon", (128, 0, 0)), ("Steel", (60, 90, 120))]


def _menu_label(s):
    # "-" is MenuItem's separator sentinel; keep user-named entries clickable
    if not s:
        return "(unnamed)"
    return s + " " if s == "-" else s


class Shell:
    def __init__(self, desk):
        self.desk = desk
        self.dir = os.path.expanduser(
            os.environ.get("KILIX_DESKTOP_DIR")
            or storage.data_dir("desktop"))
        self.dir = os.path.expanduser(self.dir)
        os.makedirs(self.dir, exist_ok=True)
        self.legacy_state_path = os.path.join(self.dir, ".state.json")
        self.state_store = durable_state.JsonState(
            "shell.state", legacy_path=self.legacy_state_path,
            max_payload=256 * 1024)
        self.state_path = str(self.state_store.path)
        self.state = {"flavor": T.flavor_name(),
                      "wall_color": list(T.DESKTOP), "wall_image": None,
                      "wall_mode": "stretch", "wall_custom": False,
                      "wall_pattern": "None", "recent": [],
                      "paperclips_enabled": False, "paperclips_animate": True,
                      "paperclips_interval": 300,
                      "cursor_scheme": "Standard", "saver_name": "Mystify",
                      "saver_idle": 180, "saver_lock": False,
                      "full_window_drag": True, "show_quick_launch": True,
                      "show_home": True, "show_settings": True,
                      "show_terminals": True,
                      "full_experience": False,
                      "era_profile": "Windows 95 Plus!"}
        loaded = self.state_store.load_dict()
        self.state.update(loaded)
        if "wall_custom" not in loaded and loaded.get("wall_image"):
            self.state["wall_custom"] = True
        self._load_flavor()
        self._wall = None             # cached composited wallpaper
        sw, sh = desk.size()
        self.grid = W.IconGrid(0, 0, sw, sh - T.TASKBAR_H,
                               on_activate=self._activate,
                               on_context=self._context, desktop=True)
        self.grid.window = self       # duck-typed: needs .invalidate/.desk
        self.focus = None             # part of the window duck-type
        self.caret_on = False
        self.installed_applications = []
        self._application_result = None
        self._application_worker = None
        self._application_scan_after = 0
        self.refresh()

    def poll_applications(self, now=None):
        """Refresh installed programs off the UI thread; publish on this thread."""
        if self._application_result is not None:
            rows, self._application_result = self._application_result, None
            self.installed_applications = rows
            self.refresh()
        if self._application_worker and self._application_worker.is_alive():
            return
        now = time.monotonic()
        if now < self._application_scan_after:
            return
        self._application_scan_after = now + 30

        def scan():
            try:
                self._application_result = applications.inventory()
            except Exception:
                # An unavailable optional provider must not break the desktop.
                self._application_result = []
        self._application_worker = threading.Thread(target=scan, daemon=True)
        self._application_worker.start()

    def _load_flavor(self):
        old_wall = tuple(T.DESKTOP)
        requested = self.state.get("flavor", T.flavor_name())
        T.apply_flavor(requested)
        self._sync_sound_flavor()
        self.state["flavor"] = T.flavor_name()
        wall = self.state.get("wall_color")
        if not (isinstance(wall, list) and len(wall) == 3):
            self.state["wall_color"] = list(T.DESKTOP)
        elif tuple(wall) == old_wall and old_wall != T.DESKTOP:
            self.state["wall_color"] = list(T.DESKTOP)
        self._sync_default_wall()
        self.desk.fb = Image.new("RGB", self.desk.size(), T.DESKTOP)

    def _default_wall_image(self):
        path = getattr(T, "WALL_IMAGE", None)
        if self.state.get('paperclips_enabled') is True:
            path = 'assets/wallpapers/kilix-firekitten-dusk.png'
        if not path:
            return None
        if not os.path.isabs(path):
            path = os.path.join(_here, path)
        return path if os.path.exists(path) else None

    def _sync_default_wall(self):
        if self.state.get("wall_custom"):
            return
        self.state["wall_image"] = self._default_wall_image()
        self.state["wall_mode"] = "stretch"

    # window duck-type used by IconGrid
    def invalidate(self):
        self.desk.dirty = True

    def _save_state(self):
        if getattr(self, "state_frozen", False):
            return                    # a restore just replaced the saved state
        try:
            self.state_store.save_dict(self.state)
        except durable_state.StateError:
            pass

    def full_experience_enabled(self):
        """Whether the optional nostalgia layer should be exposed."""
        return bool(self.state.get("full_experience", False))

    def set_full_experience(self, enabled):
        """Persist and apply the optional nostalgia layer immediately."""
        enabled = bool(enabled)
        if enabled == self.full_experience_enabled():
            return False
        self.state["full_experience"] = enabled
        self._save_state()
        self.desk.menus.close_all()
        self.desk.new_hardware = False
        self.desk.hardware_signature = ()
        if not enabled:
            self.desk.dialup_state = {
                "connected": False, "status": "Disconnected"}
        self.refresh()
        for win in list(self.desk.wm.windows):
            refresh = getattr(win, "refresh_full_experience", None)
            if refresh is not None:
                refresh()
        self.desk.taskbar.invalidate()
        self.desk.dirty = True
        return True

    # ── the icons ───────────────────────────────────────────────────────────
    def refresh(self, listing=None):
        bin_full = bool(recycle.items())
        items = [
            {"label": "My Computer", "icon": "computer",
             "data": ("builtin", ("mycomp", None))},
            {"label": "Recycle Bin",
             "icon": "recyclebin_full" if bin_full else "recyclebin_empty",
             "data": ("builtin", ("recyclebin", None))},
        ]
        if self.full_experience_enabled():
            items[1:1] = [
                {"label": "Network Neighborhood", "icon": "network",
                 "data": ("builtin", ("networkhood", None))},
                {"label": "My Briefcase", "icon": "briefcase",
                 "data": ("builtin", ("briefcase", None))},
            ]
        if self.state.get("show_home", True):
            items.append({"label": "Home", "icon": "home",
                          "data": ("builtin", ("filemgr", os.path.expanduser("~")))})
        if self.state.get("show_settings", True):
            items.append({"label": "kilix Settings", "icon": "settings",
                          "data": ("builtin", ("settings", None))})
        if self.state.get("show_terminals", True):
            items += [
                {"label": "Terminal", "icon": "terminal",
                 "data": ("builtin", ("terminal", None))},
                {"label": "Mux Terminal", "icon": "mux",
                 "data": ("builtin", ("mux", None))},
            ]
        listing = listing if listing is not None else directory_listing.scan(self.dir)
        for entry in sorted(listing.entries, key=lambda e: e.name.lower()):
            n, p = entry.name, entry.path
            if n.startswith("."):
                continue
            if entry.launcher is not None:
                spec = entry.launcher
                items.append(entry.tag({"label": spec.get("Name") or n[:-8],
                              "icon": spec.get("Icon") or "exe",
                              "shortcut": True, "data": ("launcher", p)}))
            else:
                items.append(entry.tag({"label": n,
                              "icon": icons.for_path(p, entry.isdir),
                              "data": ("path", p)}))
        # Preserve explicit desktop launchers; generated icons are read-only and
        # disappear when the corresponding application/model is removed.
        existing = {item["label"].casefold() for item in items}
        for entry in xdgapps.scan():
            if entry["name"].casefold() not in existing:
                items.append({"label": entry["name"], "icon": xdgapps.icon_for(entry),
                              "shortcut": True, "data": ("xdg-app", entry)})
                existing.add(entry["name"].casefold())
        for row in self.installed_applications:
            if row["label"].casefold() not in existing:
                items.append({"label": row["label"], "icon": row["icon"],
                              "shortcut": True, "data": ("installed-app", row)})
                existing.add(row["label"].casefold())
        self.grid.set_items(items, preserve=True)
        self.invalidate()

    def dir_changed(self, path):
        """A directory changed on disk — refresh every open view of it: the
        desktop grid and any File Manager window showing the same folder."""
        path = os.path.abspath(os.path.expanduser(path))
        if path == os.path.abspath(self.dir):
            self.refresh()
        for win in list(self.desk.wm.windows):
            if getattr(win, "is_file_window", False) and \
                    os.path.abspath(win.path) == path:
                win.refresh()

    def _sync_sound_flavor(self):
        try:
            import sounds
            sounds.use_flavor(T.flavor_name())
        except Exception:
            pass

    def on_resize(self):
        sw, sh = self.desk.size()
        self.grid.w, self.grid.h = sw, sh - T.TASKBAR_H
        self._wall = None
        self.invalidate()

    # ── drawing ─────────────────────────────────────────────────────────────
    def draw(self, fb, d):
        sw, sh = self.desk.size()
        if self._wall is None or self._wall.size != (sw, sh):
            self._wall = self._build_wall(sw, sh)
        fb.paste(self._wall, (0, 0))
        if getattr(self.desk, 'paperclips', None) is not None:
            self.desk.paperclips.draw(fb)
        self.grid.draw(d, fb)

    def _build_wall(self, sw, sh):
        img = Image.new("RGB", (sw, sh), tuple(self.state["wall_color"]))
        path = self.state.get("wall_image")
        if getattr(self.desk, 'paperclips', None) is not None:
            path = self.desk.paperclips.wallpaper() or path
        if path:
            try:
                pic = Image.open(os.path.expanduser(path)).convert("RGB")
                mode = self.state.get("wall_mode", "stretch")
                if mode == "stretch":
                    img.paste(pic.resize((sw, sh - T.TASKBAR_H)), (0, 0))
                elif mode == "tile":
                    for ty in range(0, sh, pic.height):
                        for tx in range(0, sw, pic.width):
                            img.paste(pic, (tx, ty))
                else:                 # center
                    img.paste(pic, ((sw - pic.width) // 2,
                                    (sh - T.TASKBAR_H - pic.height) // 2))
            except OSError:
                pass
        return img

    # ── input ───────────────────────────────────────────────────────────────
    def on_mouse(self, gev):
        return self.grid.on_mouse(gev)

    def on_key(self, ev):
        if self.grid.on_key(ev):
            return True
        if ev.key == "F5":
            self.refresh()
            return True
        if ev.key == "Delete":
            sel = self.grid.selected_items()
            if sel:
                self._delete_items(sel)
            return True
        if ev.key == "F2":
            sel = self.grid.selected_items()
            if sel:
                self._rename_item(sel[0])
            return True
        return False

    # ── activation / context menus ──────────────────────────────────────────
    def _activate(self, item):
        if not directory_listing.current(item):
            self.refresh()
            return False
        kind, arg = item["data"]
        if kind == "builtin":
            app, param = arg
            if app == "terminal":
                self.open_terminal()
            elif app == "mux":
                self.open_mux_terminal()
            else:
                self.open_app(app, param)
        elif kind == "launcher":
            self.launch(parse_launcher(arg), arg)
        elif kind == "xdg-app":
            xdgapps.launch(self, arg)
        elif kind == "installed-app":
            applications.launch(self, arg)
        else:
            self.open_path(arg)

    def _context(self, item, ev):
        MI, sep = W.MenuItem, W.sep
        if item is not None:
            kind, arg = item["data"]
            items = [MI("Open", action=lambda: self._activate(item))]
            if kind == "path" and vbox.is_vm_file(arg):
                items.append(MI("Open fullscreen",
                                action=lambda p=arg:
                                self.open_virtualbox_vm(p, fullscreen=True)))
            if kind == "launcher":
                items.append(MI("Edit Launcher…",
                                action=lambda: self.create_launcher_dialog(
                                    edit_path=arg)))
            if kind == "path" and not os.path.isdir(arg):
                items.append(MI("Open with Notepad", icon="notepad",
                                action=lambda: self.open_app("notepad", arg)))
            if kind == "path" and os.path.splitext(arg)[1].lower() in {".txt", ".md", ".markdown", ".pdf"}:
                items.append(MI("Read aloud…", icon="speak",
                                action=lambda: self.open_app("documentreader", arg)))
            if kind in ("launcher", "path"):
                paths = [entry["data"][1] for entry in self._sel_or_one(item)
                         if entry["data"][0] in ("launcher", "path")]
                items.append(sep())
                if self.full_experience_enabled():
                    items.append(MI("Send To", icon="sendto",
                                    submenu=self.send_to_menu_items(paths)))
                items += [MI("Rename…", action=lambda: self._rename_item(item)),
                          MI("Delete…", action=lambda: self._delete_items(
                              self._sel_or_one(item)))]
            if kind == "path":
                items.append(MI("Create Launcher…", icon="exe",
                                action=lambda: self.create_launcher_dialog(
                                    prefill_cmd=shell_quote(arg))))
        else:
            items = [
                MI("New Launcher…", icon="exe",
                   action=self.create_launcher_dialog),
                MI("New Folder…", icon="folder", action=self._new_folder),
                MI("New Text File…", icon="doc_text", action=self._new_file),
                sep(),
                MI("Refresh", action=self.refresh),
                MI("Open Desktop Folder", icon="folder_open",
                   action=lambda: self.open_app("filemgr", self.dir)),
                sep(),
                MI("Arrange Icons", icon="desktop", submenu=[
                    MI("by Name", action=self.refresh),
                    MI("Auto Arrange", checked=True, action=self.refresh),
                    MI("Line Up Icons", action=self.refresh),
                ]),
                MI("Display…", icon="display", action=self.display_properties),
                MI("Sounds…", icon="soundcp",
                   action=lambda: self.open_app("soundcp")),
                MI(f"About {T.PRODUCT_NAME}…", icon="flame",
                   action=self.about_dialog),
            ]
        self.desk.menus.open(items, ev.x, ev.y)

    # ── file ops on the desktop folder ──────────────────────────────────────
    def _sel_or_one(self, item):
        # a context action on a still-selected icon acts on the whole selection
        sel = self.grid.selected_items()
        return sel if item in sel else [item]

    def _writable(self, item):
        return item["data"][0] in ("launcher", "path")

    def _rename_item(self, item):
        if not self._writable(item):
            wm.msgbox(self.desk, "Desktop", "System icons cannot be renamed.",
                      icon="info")
            return
        kind, path = item["data"]

        def do(name):
            if not name:
                return
            if kind == "launcher":
                spec = parse_launcher(path)
                spec["Name"] = name
                try:
                    write_launcher(path, spec)
                except OSError as e:
                    wm.msgbox(self.desk, "Rename", str(e), icon="error")
                    return
            else:
                try:
                    target = child_path(self.dir, name)
                except ValueError as e:
                    wm.msgbox(self.desk, "Rename", str(e), icon="error")
                    return
                if (os.path.lexists(target)
                        and os.path.abspath(target) != os.path.abspath(path)):
                    wm.msgbox(self.desk, "Rename",
                              f"'{name}' already exists.", icon="error")
                    return
                try:
                    os.rename(path, target)
                except OSError as e:
                    wm.msgbox(self.desk, "Rename", str(e), icon="error")
            self.dir_changed(self.dir)

        wm.inputbox(self.desk, "Rename", "New name:", item["label"], cb=do)

    def _delete_items(self, sel):
        real = [i for i in sel if self._writable(i)]
        if not real:
            wm.msgbox(self.desk, "Desktop", "System icons cannot be deleted.",
                      icon="info")
            return
        names = ", ".join(i["label"] for i in real[:4]) + (
            "…" if len(real) > 4 else "")

        def do(answer):
            if answer != "Yes":
                return
            for it in real:
                p = it["data"][1]
                try:
                    recycle.send(p)
                except (OSError, shutil.Error) as e:
                    wm.msgbox(self.desk, "Delete", str(e), icon="error")
            self.dir_changed(self.dir)

        wm.msgbox(self.desk, "Confirm Delete",
                  f"Send {names} to the Recycle Bin?",
                  icon="warn", buttons=("Yes", "No"), default=1, cb=do)

    def _new_folder(self):
        def do(name):
            if name:
                try:
                    os.makedirs(child_path(self.dir, name), exist_ok=False)
                except (OSError, ValueError) as e:
                    wm.msgbox(self.desk, "New Folder", str(e), icon="error")
                self.dir_changed(self.dir)
        wm.inputbox(self.desk, "New Folder", "Folder name:", "New Folder",
                    cb=do, icon="folder")

    def _new_file(self):
        def do(name):
            if name:
                try:
                    p = child_path(self.dir, name)
                    open(p, "x").close()
                except (OSError, ValueError) as e:
                    wm.msgbox(self.desk, "New File", str(e), icon="error")
                self.dir_changed(self.dir)
        wm.inputbox(self.desk, "New Text File", "File name:", "New File.txt",
                    cb=do, icon="doc_text")

    # ── launchers ───────────────────────────────────────────────────────────
    def launcher_menu_items(self):
        out = []
        try:
            names = sorted(os.listdir(self.dir), key=str.lower)
        except OSError:
            names = []
        for n in names:
            if not n.endswith(".desktop"):
                continue
            p = os.path.join(self.dir, n)
            spec = parse_launcher(p)
            out.append(W.MenuItem(
                _menu_label(spec.get("Name") or n[:-8]),
                icon=spec.get("Icon") or "exe",
                action=lambda s=spec, p=p: self.launch(s, p)))
        return out

    def flavor_menu_items(self):
        cur = T.flavor_name()
        return [W.MenuItem(label, checked=(key == cur),
                           action=lambda key=key: self.set_flavor(key))
                for key, label in T.flavor_options()]

    def set_flavor(self, flavor):
        old = T.flavor_name()
        old_wall = tuple(T.DESKTOP)
        new = T.apply_flavor(flavor)
        self._sync_sound_flavor()
        self.state["flavor"] = new
        wall = self.state.get("wall_color")
        if not (isinstance(wall, list) and len(wall) == 3) \
                or tuple(wall) == old_wall:
            self.state["wall_color"] = list(T.DESKTOP)
        self._sync_default_wall()
        self._save_state()
        self._wall = None
        self.on_resize()
        for win in self.desk.wm.windows:
            win.surface = None
            win.dirty = True
        self.desk.fb = Image.new("RGB", self.desk.size(), T.DESKTOP)
        self.desk.dirty = True
        if old != new:
            self.desk.play_sound("open")

    def create_launcher_dialog(self, prefill_cmd=None, edit_path=None):
        """The Create Launcher wizard (also edits existing launchers)."""
        desk = self.desk
        spec = parse_launcher(edit_path) if edit_path else {}
        win = wm.Window(desk, "Edit Launcher" if edit_path
                        else "Create Launcher", 380, 262, icon="exe",
                        resizable=False, modal=True)
        cw = win.client_size()[0]
        y = 12
        win.add(W.Label(12, y + 3, "Name:"))
        f_name = win.add(W.TextField(90, y, cw - 102,
                                     spec.get("Name", "")))
        y += 28
        win.add(W.Label(12, y + 3, "Command:"))
        cmd0 = spec.get("URL") or spec.get("Exec") or prefill_cmd or ""
        f_cmd = win.add(W.TextField(90, y, cw - 136, cmd0))

        def browse_cmd():
            import filedialog
            filedialog.open_file(desk, "Choose Program",
                                 lambda p: p and f_cmd.set(shell_quote(p)))
        win.add(W.Button(cw - 44, y - 1, 32, 23, "…", cb=browse_cmd))
        y += 28
        win.add(W.Label(12, y + 3, "Start in:"))
        f_dir = win.add(W.TextField(90, y, cw - 136, spec.get("Path", "")))

        def browse_dir():
            import filedialog
            filedialog.pick_folder(desk, "Start in Folder",
                                   lambda p: p and f_dir.set(p),
                                   start=f_dir.text or None)
        win.add(W.Button(cw - 44, y - 1, 32, 23, "…", cb=browse_dir))
        y += 28
        win.add(W.Label(12, y + 3, "Open in:"))
        mode0 = spec.get("X-Kilix-Open", "tab")
        if spec.get("Type") == "Link":
            mode0 = "browse"
        rev = {v: k for k, v in MODE_KEYS.items()}
        d_mode = win.add(W.Dropdown(90, y, cw - 102, OPEN_MODES,
                                    OPEN_MODES.index(rev.get(mode0,
                                                             "kilix tab"))))
        y += 28
        win.add(W.Label(12, y + 3, "Icon:"))
        icon0 = spec.get("Icon", "exe")
        d_icon = win.add(W.Dropdown(90, y, cw - 150, ICON_CHOICES,
                                    ICON_CHOICES.index(icon0)
                                    if icon0 in ICON_CHOICES else 0))

        class _Preview(W.Widget):
            def __init__(self):
                super().__init__(cw - 36, y - 6, 32, 32)

            def draw(self, d, img):
                icons.paint(img, d_icon.value, self.x, self.y, 32,
                            shortcut=True)

        win.add(_Preview())
        d_icon.cb = lambda *_: win.invalidate()
        y += 34
        hint = "Command runs in a new kilix tab; pick another mode above."
        win.add(W.Label(12, y, hint, font=T.SMALL, color=T.SHADOW))

        def save():
            name = f_name.text.strip() or "Launcher"
            cmd = f_cmd.text.strip()
            if not cmd:
                wm.msgbox(desk, "Create Launcher",
                          "A command (or URL) is required.", icon="warn")
                return
            mode = MODE_KEYS[d_mode.value]
            out = {"Name": name, "Icon": d_icon.value}
            if mode == "browse":
                out.update({"Type": "Link", "URL": cmd})
            else:
                out.update({"Type": "Application", "Exec": cmd,
                            "X-Kilix-Open": mode})
                if f_dir.text.strip():
                    out["Path"] = f_dir.text.strip()
            path = edit_path or unique_path(
                os.path.join(self.dir, safe_name(name) + ".desktop"))
            try:
                write_launcher(path, out)
            except OSError as e:
                wm.msgbox(desk, "Create Launcher", str(e), icon="error")
                return
            win.close()
            self.dir_changed(self.dir)

        ch = win.client_size()[1]
        win.add(W.Button(cw - 164, ch - 33, 72, 23, "OK", cb=save,
                         default=True))
        win.add(W.Button(cw - 84, ch - 33, 72, 23, "Cancel", cb=win.close))
        win.set_focus(f_name)
        desk.wm.add(win)

    def launch(self, spec, path=None):
        name = spec.get("Name") or "app"
        if spec.get("Type") == "Link" or spec.get("URL"):
            self.open_url(spec.get("URL"))
            return
        cmd = spec.get("Exec", "")
        if not cmd:
            wm.msgbox(self.desk, name, "Launcher has no Exec line.",
                      icon="error")
            return
        mode = spec.get("X-Kilix-Open")
        if not mode:
            # Freedesktop launchers default Terminal=false. Imported/copied
            # GUI launchers therefore belong in `kilix run`, while explicit
            # terminal launchers remain ordinary command tabs.
            terminal = str(spec.get("Terminal", "")).strip().lower() == "true"
            mode = "tab" if terminal else "run"
        cwd = os.path.expanduser(spec.get("Path") or "~")
        argv = desktop_exec_argv(spec, path)
        if not argv:
            wm.msgbox(self.desk, name, "Launcher has an invalid Exec line.",
                      icon="error")
            return
        sanitized_cmd = " ".join(shell_quote(arg) for arg in argv)
        # Imported Kilix/Kitty .desktop entries say Terminal=false, but are
        # terminal hosts, not applications to capture inside another desktop.
        if mode == "run" and os.path.basename(argv[0]) in {"kilix", "kitty"}:
            if len(argv) == 1:
                self._tab([os.environ.get("SHELL") or "/bin/bash"], name, cwd=cwd)
            elif argv[1] == "-e" and len(argv) > 2:
                self._tab(argv[2:], name, cwd=cwd)
            else:
                wm.msgbox(self.desk, name,
                          "Use a terminal launcher for Kilix/Kitty commands.\n"
                          "A terminal host cannot be opened as an X11 app.",
                          icon="error")
            return
        if vbox.is_virtualbox_argv(argv):
            self.open_x11_tab(argv, name, cwd=cwd, fill=(mode == "fullscreen"),
                              size=self.desk.size() if mode == "fullscreen"
                              else None, refit_windows=True)
        elif mode == "run":
            self.open_x11_tab(argv, name, cwd=cwd)
        elif mode == "window":
            self._spawn_kitty_launch(
                ["--type=os-window"], sanitized_cmd, name, cwd)
        elif mode == "fullscreen":
            # X11 app filling the whole screen, on a private Xvfb (XPane)
            self.open_in_xpane(argv, name, cwd=cwd,
                               app_size=self.desk.size())
        else:
            self._spawn_kitty_launch(["--type=tab"], sanitized_cmd, name, cwd)

    # ── spawning into kilix ─────────────────────────────────────────────────
    def _kitten(self):
        k = os.environ.get("KILIX_KITTEN")
        if k and os.access(k, os.X_OK):
            return k
        storage_home = os.environ.get(
            "KILIX_STORAGE_HOME", os.path.expanduser(
                "~/.local/gpu_terminal/kilix"))
        for cand in (os.path.join(storage_home,
                                  "build/current/src/kitty/launcher/kitten"),
                     os.path.join(storage_home, "prebuilt/kitty.app/bin/kitten"),
                     shutil.which("kitten")):
            if cand and os.access(cand, os.X_OK):
                return cand
        return None

    def _kitten_remote(self, kitten, command):
        if frontend_context is not None:
            frontend_context.refresh()
        argv = [kitten, "@"]
        password_file = os.environ.get("KILIX_RC_PASSWORD_FILE")
        if password_file:
            argv.extend(["--password-file", password_file])
        argv.append(command)
        return argv

    def _spawn_kitty_launch(self, opts, cmd, title, cwd=None,
                            pause_on_error=True):
        """Run shell command `cmd` in a new kilix tab/window."""
        kitten = self._kitten()
        if not kitten or not os.environ.get("KITTY_LISTEN_ON"):
            wm.msgbox(self.desk, "kilix",
                      "Cannot reach kilix remote control\n"
                      "(KITTY_LISTEN_ON is not set).", icon="error")
            return False
        script = cmd
        if pause_on_error:
            script = (f'{cmd}; rc=$?; [ $rc -ne 0 ] && '
                      f'{{ echo; echo "[exit $rc -- Enter to close]"; '
                      f'read -r _; }}; exit $rc')
        argv = [*self._kitten_remote(kitten, "launch"), *opts,
                "--self", "--tab-title", title,
                "--cwd", cwd or os.path.expanduser("~"), "--",
                "bash", "-lc", script]
        return self._popen(argv)

    @staticmethod
    def _resolve_program(name):
        """An absolute path for `name`, resolved in the desktop's environment.

        The terminal spawns a tab's child from its own environment, whose
        PATH does not reliably include ~/.local/bin — a bare name it cannot
        resolve dies before its first prompt and leaves a dead tab whose only
        trace is a resize warning. PATH first, then ~/.local/bin explicitly,
        which is where the stack installs its tools; names that are already
        paths only have to be executable.
        """
        if os.path.sep in name:
            return name if os.access(name, os.X_OK) else None
        found = shutil.which(name)
        if found:
            return found
        local = os.path.join(os.path.expanduser("~"), ".local", "bin", name)
        return local if os.access(local, os.X_OK) else None

    def _tab(self, argv, title, cwd=None, env=None):
        kitten = self._kitten()
        if not kitten or not os.environ.get("KITTY_LISTEN_ON"):
            wm.msgbox(self.desk, "kilix", "Cannot reach kilix remote control\n"
                      "(KITTY_LISTEN_ON is not set).", icon="error")
            return False
        program = self._resolve_program(argv[0])
        if program is None:
            # Words instead of a corpse: a tab whose child cannot even start
            # renders as an instantly dead pane with no explanation.
            wm.msgbox(self.desk, title or "kilix",
                      f"{argv[0]} could not be found\n"
                      "(not on PATH or in ~/.local/bin).", icon="error")
            return False
        argv = [program, *argv[1:]]
        env_args = []
        for k, v in (env or {}).items():
            env_args.extend(["--env", f"{k}={v}"])
        return self._popen([*self._kitten_remote(kitten, "launch"),
                            "--type=tab", "--self", "--tab-title",
                            title, "--cwd", cwd or os.path.expanduser("~"),
                            *env_args, "--"]
                           + argv)

    def open_device_settings(self, tool):
        labels = {
            "power": "Power", "bluetooth": "Bluetooth", "storage": "Disks",
            "printers": "Printers", "audio": "Sound Devices",
            "input-method": "Input Methods", "accessibility": "Accessibility",
            "lock": "Lock Desktop",
        }
        if tool not in labels:
            raise ValueError("Unknown desktop device control")
        pleb = self._resolve_program("pleb")
        if not pleb:
            wm.msgbox(self.desk, labels[tool],
                      "Desktop device controls require Pleb. Run pleb install.",
                      icon="error")
            return False
        argv = [pleb, "lock"] if tool == "lock" else [pleb, "devices", tool]
        return self._tab(argv, labels[tool])

    def open_x11_tab(self, argv, title, cwd=None, fill=False, size=None,
                     refit_windows=False):
        run = [os.path.join(KILIX_HOME, "kilix"), "run"]
        if size:
            w, h = size
            run += ["--size", f"{int(w)}x{int(h)}"]
        if fill:
            run.append("--fill")
        if refit_windows:
            run.append("--refit-windows")
        return self._tab(run + list(argv), title, cwd, env={
            "KILIX_IN_OVERLAY": "1",
            "KILIX_STREAM": os.environ.get("KILIX_STREAM", ""),
        })

    def _popen(self, argv, cwd=None):
        try:
            subprocess.Popen(argv, cwd=cwd, start_new_session=True,
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL,
                             stdin=subprocess.DEVNULL)
        except OSError as e:
            wm.msgbox(self.desk, "kilix", f"Launch failed:\n{e}",
                      icon="error")
            return False
        return True

    def open_terminal(self, cwd=None):
        kitten = self._kitten()
        if not kitten or not os.environ.get("KITTY_LISTEN_ON"):
            wm.msgbox(self.desk, "kilix", "Cannot reach kilix remote control\n"
                      "(KITTY_LISTEN_ON is not set).", icon="error")
            return False
        return self._popen([*self._kitten_remote(kitten, "launch"),
                            "--type=tab", "--self", "--tab-title",
                            "Terminal", "--cwd", cwd or os.path.expanduser("~")])

    def open_mux_terminal(self, session="main", cwd=None):
        session = session or "main"
        kilix = os.path.join(KILIX_HOME, "kilix")
        return self._tab([kilix, "serve", session],
                         f"Mux: {session}", cwd or os.path.expanduser("~"))

    @staticmethod
    def kilix_temps_target():
        if executable := shutil.which("kilix-temps"):
            return [executable, "--graphics"], None
        source_home = os.environ.get("GPU_TERMINAL_SOURCE_HOME") or \
            os.path.expanduser("~/.local/gpu_terminal/sources")
        project = os.path.join(
            os.path.abspath(os.path.expanduser(source_home)), "kilix-temps")
        executable = os.path.join(project, "build", "kilix-temps")
        if os.path.isfile(executable) and os.access(executable, os.X_OK):
            return [executable, "--graphics"], project
        kilix_home = os.environ.get("KILIX_HOME") or os.path.join(
            os.path.abspath(os.path.expanduser(source_home)), "kilix")
        kilix = os.path.join(kilix_home, "kilix")
        if os.path.isfile(kilix) and os.access(kilix, os.X_OK):
            return [kilix, "temps", "--graphics"], None
        return None

    def open_kilix_temps(self):
        target = self.kilix_temps_target()
        if target is not None:
            argv, cwd = target
            return self._tab(argv, "Kilix Temps", cwd)
        wm.msgbox(
            self.desk, "Kilix Temps",
            "Neither an installed Kilix Temps dashboard nor the pinned Kilix "
            "installer could be found.", icon="error")
        return False

    @staticmethod
    def kilix_memory_target():
        if executable := shutil.which("kilix-memory"):
            return [executable, "--graphics"], None
        source_home = os.environ.get("GPU_TERMINAL_SOURCE_HOME") or \
            os.path.expanduser("~/.local/gpu_terminal/sources")
        project = os.path.join(
            os.path.abspath(os.path.expanduser(source_home)), "kilix-memory")
        executable = os.path.join(project, "build", "kilix-memory")
        if os.path.isfile(executable) and os.access(executable, os.X_OK):
            return [executable, "--graphics"], project
        kilix_home = os.environ.get("KILIX_HOME") or os.path.join(
            os.path.abspath(os.path.expanduser(source_home)), "kilix")
        kilix = os.path.join(kilix_home, "kilix")
        if os.path.isfile(kilix) and os.access(kilix, os.X_OK):
            return [kilix, "memory", "--graphics"], None
        return None

    def open_kilix_memory(self):
        target = self.kilix_memory_target()
        if target is not None:
            argv, cwd = target
            return self._tab(argv, "Kilix Memory", cwd)
        wm.msgbox(
            self.desk, "Kilix Memory",
            "Neither an installed Kilix Memory dashboard nor its source "
            "checkout could be found.", icon="error")
        return False

    @staticmethod
    def pty_manager_target():
        """Use Kilix so the manager shares its private, pinned broker runtime."""
        kilix = os.path.join(KILIX_HOME, "kilix")
        if os.path.isfile(kilix) and os.access(kilix, os.X_OK):
            return [kilix, "pty"]
        return None

    def open_pty_manager(self):
        target = self.pty_manager_target()
        if target is not None:
            return self._tab(
                target,
                "PTY Sessions (Terminal)",
                os.path.expanduser("~"),
                env={"KITTY_PTY_BROKER_BYPASS": "1"},
            )
        wm.msgbox(
            self.desk, "PTY Sessions (Terminal)",
            "The Kilix persistent-session manager could not be found.",
            icon="error")
        return False

    @staticmethod
    def tmux_manager_target():
        """Installed manager first; the Kilix pinned installer is the fallback."""
        if executable := shutil.which("tmux-tui"):
            return [executable]
        kilix = os.path.join(KILIX_HOME, "kilix")
        if os.path.isfile(kilix) and os.access(kilix, os.X_OK):
            return [kilix, "tmux"]
        return None

    def open_tmux_manager(self):
        target = self.tmux_manager_target()
        if target is not None:
            return self._tab(target, "Tmux Manager", os.path.expanduser("~"))
        wm.msgbox(
            self.desk, "Tmux Manager",
            "Neither an installed Tmux Manager nor the pinned Kilix installer "
            "could be found.", icon="error")
        return False

    @staticmethod
    def kilix_voice_source_target(command):
        """Resolve a development voice TUI from the same tree as the widgets."""
        source_home = os.environ.get("GPU_TERMINAL_SOURCE_HOME") or \
            os.path.expanduser("~/gpu_terminal")
        project = os.path.join(
            os.path.abspath(os.path.expanduser(source_home)),
            "kilix-apps", "kilix-voice")
        candidate = os.path.join(project, command)
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return [candidate]
        return None

    @staticmethod
    def kilix_workflows_target():
        """Use the selected host catalog, never an unrelated PATH checkout."""
        launcher = os.path.join(KILIX_HOME, "kilix")
        if os.path.isfile(launcher) and os.access(launcher, os.X_OK):
            return [launcher, "app", "run", "kilix-needle", "--"]
        return None

    @staticmethod
    def kilix_tts_target():
        """Pinned launcher first, so it can refresh an older Voice runtime."""
        kilix = os.path.join(KILIX_HOME, "kilix")
        if os.path.isfile(kilix) and os.access(kilix, os.X_OK):
            return [kilix, "tts"]
        if executable := shutil.which("kilix-tts"):
            return [executable]
        if target := Shell.kilix_voice_source_target("kilix-tts"):
            return target
        return None

    def open_kilix_tts(self):
        target = self.kilix_tts_target()
        if target is not None:
            return self._tab(target, "Read Aloud", os.path.expanduser("~"))
        wm.msgbox(
            self.desk, "Read Aloud",
            "Neither an installed Kilix read-aloud TUI nor the pinned Kilix "
            "installer could be found.", icon="error")
        return False

    @staticmethod
    def kilix_stt_target():
        """Pinned launcher first, so every model action uses its Voice pin."""
        kilix = os.path.join(KILIX_HOME, "kilix")
        if os.path.isfile(kilix) and os.access(kilix, os.X_OK):
            return [kilix, "stt"]
        if executable := shutil.which("kilix-stt"):
            return [executable]
        if target := Shell.kilix_voice_source_target("kilix-stt"):
            return target
        return None

    def open_kilix_stt(self):
        """The TUI is dictation's settings and diagnostics surface — device,
        model, level meter. It opens no microphone: capture is click-to-talk
        and only ever starts from an explicit press."""
        target = self.kilix_stt_target()
        if target is not None:
            return self._tab(target, "Dictation", os.path.expanduser("~"))
        wm.msgbox(
            self.desk, "Dictation",
            "Neither an installed Kilix dictation TUI nor the pinned Kilix "
            "installer could be found.", icon="error")
        return False

    def open_voice_help(self):
        """Explain where the real speech controls act.

        Kilix 95 is a framebuffer, not terminal text.  Naming that boundary in
        the desktop keeps the two settings/diagnostic TUIs from looking like
        one-click speech actions and gives a first-time user a complete route
        to a pane that read-aloud and dictation can actually target.
        """
        wm.msgbox(
            self.desk,
            "Kilix Voice Help",
            "Open Start > Programs > Document Reader to read TXT, Markdown, "
            "or PDF files. Its Kristin button optionally changes your shared voice.\n\n"
            "Read Aloud and Dictation are the speaking-head and microphone "
            "buttons in the page strip at the top of Kilix.\n\n"
            "They work on terminal panes. Open Start > Programs > Terminal, "
            "then click the speaking head to read that pane or click the "
            "microphone to dictate into it. Click the same button again to "
            "stop.\n\n"
            "The Kilix 95 desktop is drawn as pixels, so it has no terminal "
            "text for those controls to read or type into. Use the Read "
            "Aloud Settings and Dictation Settings entries to test audio, "
            "choose devices, and inspect diagnostics. On an installed release, "
            "if the voice runtime is missing, those Settings entries install "
            "Kilix's exact pinned runtime before opening.",
            icon="info",
        )
        return True

    @staticmethod
    def kilix_bonsai_target():
        """Installed command first; the Kilix pinned installer is the fallback.

        Exactly the two branches the Kilix CLI resolves, and for the same
        reason: a Start-menu launch and a `kilix bonsai` typed in a pane must
        not be able to run different builds of the tool that downloads
        multi-gigabyte weights. A source checkout is deliberately not one of
        them — a working tree is not the pinned closure."""
        if executable := shutil.which("kilix-bonsai"):
            return [executable]
        kilix = os.path.join(KILIX_HOME, "kilix")
        if os.path.isfile(kilix) and os.access(kilix, os.X_OK):
            return [kilix, "bonsai"]
        return None

    @staticmethod
    def kilix_mask_target():
        """Installed command first, then the Kilix pinned installer.

        The same two branches as every other pinned tool here, and not a
        source checkout, for the same reason: a mask is a file format, and
        a Start-menu launch editing it with a different build than
        `kilix mask` would is the divergence a pin exists to prevent."""
        if executable := shutil.which("kilix-mask"):
            return [executable]
        kilix = os.path.join(KILIX_HOME, "kilix")
        if os.path.isfile(kilix) and os.access(kilix, os.X_OK):
            return [kilix, "mask"]
        return None

    def open_kilix_mask(self):
        """Paint a region map over a picture.

        It needs a picture before it can do anything - the whole point is
        painting in relation to what is in the image - so this asks for one
        rather than opening onto an error. The mask is named after the
        picture and offered for confirmation, because writing one silently
        next to somebody's photograph is not this program's business.
        """
        target = self.kilix_mask_target()
        if target is None:
            wm.msgbox(
                self.desk, "Region Painter",
                "Neither an installed kilix-mask nor the Kilix installer "
                "that builds it could be found.", icon="error")
            return False
        import filedialog

        def picked(picture):
            if not picture:
                return
            base = os.path.splitext(picture)[0] + ".mask.png"

            def confirmed(mask):
                if not mask:
                    return
                self._tab(target + ["--image", picture, mask],
                          "Region Painter", os.path.dirname(mask) or
                          os.path.expanduser("~"))

            filedialog.save_file(
                self.desk, "Mask to paint", confirmed,
                start=os.path.dirname(base),
                filters=[("Masks", "*.mask.png;*.png")],
                filename=os.path.basename(base))

        filedialog.open_file(
            self.desk, "Picture to paint over", picked,
            filters=[("Pictures", "*.png;*.ppm"), ("All Files", "*")])
        return True

    def open_kilix_cameras(self):
        """Open the camera manager inside the desktop, including diagnostics."""
        return self.open_catalog_application("kilix-camera-manager")

    def open_kilix_bonsai(self):
        """The BitNet model store: browse, download, and verify local models.

        It opens with nothing downloaded on purpose — the TUI's first screen is
        a setup screen that prices each model — so this launches unconditionally
        rather than checking for weights first. One of those models is the
        dictation engine, which is why this and Dictation sit near each other in
        the menu."""
        target = self.kilix_bonsai_target()
        if target is not None:
            return self._tab(target, "BitNet Models", os.path.expanduser("~"))
        wm.msgbox(
            self.desk, "BitNet Models",
            "Neither an installed Kilix Bonsai model store nor its source "
            "checkout could be found.", icon="error")
        return False

    def open_kilix_pdf(self, path=None):
        """Choose or open a PDF in the catalog viewer."""
        if path:
            return self.open_catalog_application(
                "kilix-pdf", action="open", arguments=(path,))

        import filedialog

        return filedialog.open_file(
            self.desk, "Open PDF",
            lambda selected: selected and self.open_kilix_pdf(selected),
            filters=[("PDF Documents", "*.pdf"), ("All Files", "*.*")])

    def open_pdf(self, path):
        """Use the OS default viewer; retain the catalog viewer on other hosts."""
        if binary := self._resolve_program("okular"):
            return self.open_in_xpane([binary, os.path.abspath(path)], "Okular",
                                      icon="doc_text", app_size=(960, 700))
        return self.open_kilix_pdf(path)

    def open_catalog_application(self, content_id, action=None, arguments=()):
        """Render any shared catalog application as a managed desktop box."""
        kilix = os.path.join(KILIX_HOME, "kilix")
        try:
            plan = kilix_content.application_plan(
                content_id, "window", arguments, launcher=kilix, action=action)
        except (kilix_content.CatalogError, ValueError) as error:
            wm.msgbox(self.desk, "Kilix Application", str(error), icon="error")
            return False
        if plan.single_instance:
            for window in self.desk.wm.windows:
                if getattr(window, "kilix_application_id", "") == content_id:
                    self.desk.wm.activate(window)
                    return True
        return self.open_in_xpane(
            plan.argv, plan.label, icon=plan.icon,
            app_size=plan.preferred_size, cwd=os.path.expanduser("~"),
            application_id=content_id)

    def catalog_application_menu_items(self):
        """Start-menu rows derived from the SDK's plain catalog records."""
        try:
            records = kilix_content.menu_records()
        except Exception:                         # an unreadable catalog is empty
            return []
        return [
            W.MenuItem(
                record["label"],
                icon="exe",
                action=lambda content_id=record["id"]:
                self.open_catalog_application(content_id),
            )
            for record in records
            if record.get("kind") == "app"
        ]

    def installed_application_menu_items(self):
        return [W.MenuItem(row["label"], icon=row["icon"],
                           action=lambda row=row: applications.launch(self, row))
                for row in self.installed_applications]

    @staticmethod
    def kilix_tui_target():
        """Installed command first; the Kilix launcher is the fallback.

        The same two branches as the model store, for the same reason: a
        Start-menu launch and a `kilix kilix-tui` typed in a pane must run the
        same build of the desktop. A source checkout is deliberately not one
        of them — a working tree is not the pinned closure."""
        if executable := shutil.which("kilix-tui"):
            return [executable]
        kilix = os.path.join(KILIX_HOME, "kilix")
        if os.path.isfile(kilix) and os.access(kilix, os.X_OK):
            import games

            return [kilix, "kilix-tui", "--content-root",
                    os.path.normpath(games.APPS_DIR)]
        return None

    @staticmethod
    def install_target(item=""):
        """`kilix install`, resolved the way every other entry resolves.

        The Kilix launcher owns the list; the Start menu asks it rather than
        keeping a catalogue of its own, so what this offers and what
        `kilix install` prints cannot drift apart."""
        kilix = os.path.join(KILIX_HOME, "kilix")
        if os.path.isfile(kilix) and os.access(kilix, os.X_OK):
            return [kilix, "install"] + ([item] if item else [])
        if executable := shutil.which("kilix"):
            return [executable, "install"] + ([item] if item else [])
        return None

    @staticmethod
    def default_desktop_target(name=""):
        """`kilix default-desktop`, resolved like every other entry."""
        kilix = os.path.join(KILIX_HOME, "kilix")
        if not (os.path.isfile(kilix) and os.access(kilix, os.X_OK)):
            kilix = shutil.which("kilix") or ""
        if not kilix:
            return None
        return [kilix, "default-desktop"] + (["set", name] if name else ["show"])

    def open_default_desktop(self, name=""):
        """Choose the desktop every later session starts with."""
        target = self.default_desktop_target(name)
        if target is None:
            wm.msgbox(self.desk, "Default Desktop",
                      "The Kilix launcher could not be found.", icon="error")
            return False
        return self._tab(target, "Default Desktop", os.path.expanduser("~"))

    def open_install(self, item=""):
        """Browse everything installable, or install one thing by id."""
        target = self.install_target(item)
        if target is not None:
            title = "Install Software" if not item else f"Install {item}"
            return self._tab(target, title, os.path.expanduser("~"))
        wm.msgbox(
            self.desk, "Install Software",
            "The Kilix launcher could not be found, so the installable list is "
            "unavailable.", icon="error")
        return False

    def open_kilix_tui(self):
        """The text-native desktop, in a tab of its own.

        Kilix 95 keeps running — this opens the sibling desktop beside it, the
        way a second terminal would, so the two can be compared and the TUI can
        be reached without changing the session's provider."""
        target = self.kilix_tui_target()
        if target is not None:
            import games

            # The terminal's environment may belong to a different desktop.
            # Direct installed TUI and host fallback share this install root;
            # the fallback also passes it explicitly to the host launcher.
            return self._tab(target, "Kilix TUI", os.path.expanduser("~"), env={
                "KILIX_CONTENT_ROOT": os.path.normpath(games.APPS_DIR)})
        wm.msgbox(
            self.desk, "Kilix TUI",
            "Neither an installed Kilix TUI desktop nor its pinned "
            "installer could be found.", icon="error")
        return False

    def install_tb_alias(self):
        """Open the pinned user-level `tb` alias installer in a visible tab."""
        kilix = os.path.join(KILIX_HOME, "kilix")
        if os.path.isfile(kilix) and os.access(kilix, os.X_OK):
            return self._tab(
                [kilix, "tmux", "--install-only", "--with-tb"],
                "Install tb", os.path.expanduser("~"))
        wm.msgbox(
            self.desk, "Install tb",
            "The Kilix pinned Tmux Manager installer could not be found.",
            icon="error")
        return False

    @staticmethod
    def tb_alias_command():
        return shutil.which("tb")

    def open_dos_prompt(self):
        """Authentic Start-menu caller for the managed DOSBox prompt."""
        return self._tab(["python3", os.path.join(_here, "games.py"), "dosbox"],
                         "MS-DOS Prompt", os.path.expanduser("~"))

    def send_to_menu_items(self, paths):
        def send(destination):
            try:
                copied = nostalgia.send_paths(paths, destination)
                self.dir_changed(destination)
                wm.msgbox(self.desk, "Send To",
                          f"Copied {len(copied)} item(s) to:\n{destination}",
                          icon="info")
            except (OSError, shutil.Error) as error:
                wm.msgbox(self.desk, "Send To", str(error), icon="error")
        return [W.MenuItem(name, icon="folder",
                           action=lambda destination=path: send(destination))
                for name, path in nostalgia.send_to_destinations(self)]

    def run_maintenance(self, cmd, title):
        """Run an update/maintenance command in a new kilix tab, pausing at the
        end so its output — and any prompt, e.g. `pleb update`'s restart
        question — stays readable. Backs the Start ▸ System launchers."""
        done = f"== {title} finished -- press Enter to close =="
        self._spawn_kitty_launch(
            ["--type=tab"],
            f'{cmd}; rc=$?; echo; printf "%s\\n" {shell_quote(done)}; '
            f'read -r _; exit $rc',
            title,
            pause_on_error=False)

    def open_url(self, url):
        if url is None:
            wm.inputbox(self.desk, "Web Browser", "Address:", "https://",
                        cb=lambda u: u and self.open_url(u), icon="browser")
            return
        self.open_default_browser_tab(url, "browser")

    def open_default_browser_tab(self, url, title="Browser"):
        """Open a URL in a browser contained by a Kilix tab."""
        if not url:
            return False
        browser = self._first_on_path(self.REAL_BROWSER_CANDS)
        if browser:
            return self.open_x11_tab(
                self._browser_argv(browser, url), title or "Browser",
                fill=True)
        # No native browser exists. Run Kilix's in-pane renderer in this tab;
        # the marker prevents open-url from creating a second overlay.
        return self._tab(
            [os.path.join(KILIX_HOME, "kilix"), "open-url", url],
            title or "Browser", None, env={"KILIX_IN_OVERLAY": "1"})

    @staticmethod
    def pleb_recovery_doc_candidates():
        """Recovery-guide locations, in installed-then-source priority order.

        PLEB_RECOVERY_DOC_DST is primarily Pleb's installer destination
        override. Honouring it here too makes a deliberately relocated guide
        discoverable when the desktop is launched from the same environment.
        """
        source_home = os.environ.get("GPU_TERMINAL_SOURCE_HOME") or \
            os.path.expanduser("~/.local/gpu_terminal/sources")
        candidates = [os.environ.get("PLEB_RECOVERY_DOC_DST"),
                      PLEB_RECOVERY_DOC,
                      PLEB_RECOVERY_DOC_LEGACY,
                      os.path.join(source_home, "pleb", "docs", "RECOVERY.md")]
        result = []
        for path in candidates:
            if not path:
                continue
            path = os.path.abspath(os.path.expanduser(path))
            if path not in result:
                result.append(path)
        return result

    def open_pleb_recovery(self):
        """Open Pleb's canonical recovery guide or provide a useful fallback."""
        for path in self.pleb_recovery_doc_candidates():
            if os.path.isfile(path) and os.access(path, os.R_OK):
                self.open_app("notepad", path)
                return path
        wm.msgbox(
            self.desk, "Pleb Recovery Guide",
            "The Pleb recovery guide is not installed.\n\n"
            f"Expected: {PLEB_RECOVERY_DOC}\n\n"
            "If `pleb update` reports that libxxhash is missing, run:\n"
            f"sudo {first_present(PLEBIAN_OS_INSTALL_DEPS) or PLEBIAN_OS_INSTALL_DEPS[0]}\n"
            "pleb update\n\n"
            "If that helper is unavailable, install the immediate dependency:\n"
            "sudo apt-get update\n"
            "sudo apt-get install libxxhash-dev",
            icon="warn")
        return None

    FIREFOX_CANDS = ("firefox-esr", "firefox")
    CHROME_CANDS = ("google-chrome", "google-chrome-stable", "chromium",
                    "chromium-browser")
    REAL_BROWSER_CANDS = CHROME_CANDS + FIREFOX_CANDS
    BROWSER_HOME = "https://duckduckgo.com/"

    @staticmethod
    def _first_on_path(cands):
        for c in cands:
            p = shutil.which(c)
            if p:
                return p
        return None

    @staticmethod
    def _browser_argv(browser, url):
        name = os.path.basename(browser)
        if name.startswith("firefox"):
            return [browser, "--no-remote", url]
        return [browser, url]

    @staticmethod
    def kilix_chawan_target():
        """Only the Kilix CLI.

        Unlike the other tools here there is no installed command to prefer:
        `kilix chawan` owns the pinned checkout and the first-run build, and
        the browser's binary lives inside that private prefix. Going through
        the CLI is what keeps a Start-menu launch and a typed `kilix chawan`
        on the same build."""
        kilix = os.path.join(KILIX_HOME, "kilix")
        if os.path.isfile(kilix) and os.access(kilix, os.X_OK):
            return [kilix, "chawan"]
        return None

    def open_kilix_chawan(self, url=None):
        """The text browser, in a terminal tab.

        It is a terminal program, so it opens in a kilix tab rather than an
        XPane: there is no X client to host. The first launch builds it, which
        takes a few minutes and prints its progress in that tab."""
        target = self.kilix_chawan_target()
        if target is None:
            wm.msgbox(
                self.desk, "Chawan",
                "The Kilix launcher could not be found, so the text browser "
                "cannot be installed or started.", icon="error")
            return False
        if url:
            target = target + [url]
        return self._tab(target, "Chawan", os.path.expanduser("~"))

    def open_browser(self, which="firefox", mode=None, url=None):
        """Launch a web browser from the desktop.

        Firefox and Chromium open in a filled kilix-run tab by default so they
        stay inside the terminal pane. mode overrides: "window", "tab",
        "fullscreen". Chawan is a terminal browser and ignores mode.
        """
        url = url or self.BROWSER_HOME
        if which == "chawan":
            return self.open_kilix_chawan(url)
        if which == "chromium":
            chromium = self._first_on_path(self.CHROME_CANDS)
            if not chromium:
                wm.msgbox(self.desk, "Chromium", "Chromium is not installed.",
                          icon="error")
                return
            mode = mode or "tab"
            if mode == "tab":
                self.open_x11_tab(
                    self._browser_argv(chromium, url), "Chromium", fill=True)
            else:                           # GUI chromium (works where GL does)
                self._browser_window(
                    self._browser_argv(chromium, url),
                    "Chromium", mode)
            return
        # firefox — the default browser
        ff = self._first_on_path(self.FIREFOX_CANDS)
        if not ff:
            wm.msgbox(self.desk, "Firefox", "Firefox is not installed.",
                      icon="error")
            return
        mode = mode or "tab"
        argv = [ff, "--no-remote", url]
        if mode == "tab":
            self.open_x11_tab(argv, "Firefox", fill=True)
        else:                               # window / fullscreen
            self._browser_window(argv, "Firefox", mode)

    def _browser_window(self, argv, title, mode):
        """Open a GUI browser as an XPane desktop window, sized per mode."""
        import app_profiles
        try:
            argv, temporary_profile = app_profiles.prepare_app_command(argv)
        except (OSError, RuntimeError) as error:
            wm.msgbox(self.desk, title, f"Could not prepare browser:\n{error}",
                      icon="error")
            return False
        cleanup = lambda: app_profiles.cleanup_app_profile(temporary_profile)
        sw, sh = self.desk.size()
        size = (sw, sh) if mode == "fullscreen" \
            else (int(sw * 0.82), int(sh * 0.82))
        return self.open_in_xpane(
            argv, title, icon="browser", app_size=size, cleanup=cleanup)

    def open_path(self, path, from_app=None):
        """The desktop's 'what do I do with this file' verb."""
        path = os.path.expanduser(path)
        if os.path.isdir(path):
            self.open_app("filemgr", path)
            return
        try:
            # a FIFO/device would block open(2) on this single-threaded loop
            if not stat.S_ISREG(os.stat(path).st_mode):
                wm.msgbox(self.desk, os.path.basename(path) or path,
                          "This is a special file (pipe or device) and "
                          "cannot be opened.", icon="warn")
                return
        except OSError:
            pass
        low = path.lower()
        if low.endswith(".desktop"):
            self.launch(parse_launcher(path), path)
            return
        if vbox.is_vm_file(path):
            self.open_virtualbox_vm(path)
            self.add_recent(path)
            return
        if low.endswith((".krt", ".rtf")):
            self.open_app("wordpad", path)
            self.add_recent(path)
            return
        if low.endswith(".pdf"):
            self.open_pdf(path)
        elif low.endswith(IMG_EXT):
            self.open_app("viewer", path)
        elif low.endswith(AUDIO_EXT):
            self.open_app("amp", path)
        elif low.endswith(TEXT_EXT) or self._looks_texty(path):
            self.open_app("notepad", path)
        elif os.access(path, os.X_OK):
            def do(ans):
                if ans == "Run":
                    self._spawn_kitty_launch(["--type=tab"],
                                             shell_quote(path),
                                             os.path.basename(path))
                elif ans == "Notepad":
                    self.open_app("notepad", path)
            wm.msgbox(self.desk, os.path.basename(path),
                      "This file is executable. Run it in a kilix tab?",
                      icon="question", buttons=("Run", "Notepad", "Cancel"),
                      cb=do)
        else:
            def do2(ans):
                if ans == "Notepad":
                    self.open_app("notepad", path)
            wm.msgbox(self.desk, os.path.basename(path),
                      "No association for this file type.",
                      icon="question", buttons=("Notepad", "Cancel"), cb=do2)
        self.add_recent(path)

    @staticmethod
    def _looks_texty(path):
        try:
            with open(path, "rb") as f:
                chunk = f.read(2048)
            return b"\0" not in chunk
        except OSError:
            return False

    def open_virtualbox_vm(self, path, fullscreen=False):
        title = vbox.vm_title(path)
        return self.open_x11_tab(vbox.vm_argv(path, fullscreen=fullscreen),
                                 title, fill=fullscreen,
                                 size=self.desk.size() if fullscreen else None,
                                 refit_windows=True)

    def game_menu_items(self, availability=None):
        """Start ▸ Programs ▸ Games, built from the games.py registry."""
        import games
        return [W.MenuItem(meta["label"], icon=meta["icon"],
                           action=lambda g=name: self.play_game(g))
                for name, meta in games.available_games(availability).items()]

    def system_menu_items(self):
        """Start ▸ System: update + maintenance launchers, each shown only when
        the thing it drives is actually present — so a bare kilix checkout only
        offers `kilix update`, while a full Pleb/Plebian-OS box offers the whole
        set. Every item runs in a visible tab (see run_maintenance)."""
        home = os.path.expanduser("~")
        items = []

        def launcher(cmd, title, icon="run"):
            return W.MenuItem(title, icon=icon,
                              action=lambda c=cmd, t=title:
                              self.run_maintenance(c, t))

        # kilix, when this is a git checkout with the launcher, or a packaged
        # Kilix, where `kilix update` upgrades the Kilix packages with apt
        kilix = os.path.join(KILIX_HOME, "kilix")
        if (os.path.isdir(os.path.join(KILIX_HOME, ".git"))
                or os.path.exists(os.path.join(KILIX_HOME, "PACKAGED"))) \
                and os.path.exists(kilix):
            items.append(launcher(f'"{kilix}" update', "Update kilix"))
        # pleb, when the session manager is present
        pleb = os.path.join(home, "pleb", "bin", "pleb")
        if os.path.exists(pleb):
            items.append(launcher(f'"{pleb}" update',
                                  "Update Pleb (kilix + session)"))
        # the whole Plebian-OS stack + dependency reinstall, when installed
        pos = first_present(PLEBIAN_OS_UPDATE)
        if pos:
            items.append(launcher(pos, "Update Plebian-OS (kilix + pleb)"))
        deps = first_present(PLEBIAN_OS_INSTALL_DEPS)
        if deps:
            if items:
                items.append(W.MenuItem("-"))
            items.append(launcher(f'sudo "{deps}"', "Reinstall dependencies",
                                  icon="settings"))
        # Plebian-OS 0.2.3: the SSH server is off unless the owner turns it
        # on. Each entry runs the one privileged helper in a visible tab; sudo
        # asks for the password there, as it does for the dependency reinstall.
        # Turning it on asks first in that tab, so a machine whose sudo needs
        # no password still never opens SSH from one click.
        ssh = first_present(PLEBIAN_OS_SSH_SERVER)
        if ssh:
            if items:
                items.append(W.MenuItem("-"))
            items.append(W.MenuItem("Remote login (SSH)", icon="network", submenu=[
                launcher(ssh_enable_command(ssh), "Turn SSH on", icon="settings"),
                launcher(f'sudo "{ssh}" disable', "Turn SSH off", icon="settings"),
                launcher(f'"{ssh}" status', "Show SSH status", icon="info"),
            ]))

        # any other executable *.sh shipped under the checkouts' scripts/ dirs
        extra = []
        for base in (os.path.join(home, "pleb", "scripts"),
                     os.path.join(KILIX_HOME, "scripts")):
            if not os.path.isdir(base):
                continue
            for fn in sorted(os.listdir(base)):
                fp = os.path.join(base, fn)
                if fn.endswith(".sh") and os.access(fp, os.X_OK):
                    extra.append(W.MenuItem(
                        fn, icon="exe", action=lambda p=fp, n=fn:
                        self.run_maintenance(f'"{p}"', n)))
        if extra:
            if items:
                items.append(W.MenuItem("-"))
            items.append(W.MenuItem("Scripts", icon="folder", submenu=extra))

        return items

    def play_game(self, game):
        """Plays immediately when games.conf points at a working install;
        otherwise asks once, then a new tab installs the pieces (showing
        progress) and boots the game."""
        import games
        if not games.game_enabled(game):
            wm.msgbox(
                self.desk, "Games",
                "This game is disabled. Re-enable it in "
                "kilix Settings → Games.",
                icon="info")
            return
        meta = games.GAMES[game]

        def go():
            self._tab(["python3", os.path.join(_here, "games.py"), game],
                      meta["label"], None)

        ready = games.game_ready(game)
        if not ready and games.host_play_argv(game):
            # games.py delegates install-and-boot to `kilix games play`, so
            # the host owns install state; asking it here keeps a game the
            # host already installed from prompting "isn't set up yet".
            ready = games.host_game_ready(game)
        if ready:
            go()
            return

        def answered(ans):
            if ans == "Install":
                go()
        wm.msgbox(self.desk, "Games",
                  f"{meta['label']} isn't set up yet.\n\n{meta['blurb']}\n"
                  "(Paths are remembered in Kilix 95's private config directory.)",
                  icon=meta["icon"], buttons=("Install", "Cancel"),
                  cb=answered)

    def open_app(self, app, arg=None):
        import apps
        try:
            apps.open(self.desk, app, arg)
        except Exception as e:            # an app must never take the desk down
            wm.msgbox(self.desk, T.PRODUCT_NAME, f"{app}: {e}", icon="error")

    def open_in_xpane(self, argv, title, icon="exe", cwd=None, app_size=None,
                      cleanup=None, application_id=""):
        """Open an X11 command (already-split argv) as a window ON the desktop,
        the way apps/amp.py runs kilix-amp. app_size (w, h) sizes the private
        Xvfb / window; None fills the desktop (minus the taskbar). An Xvfb/XPane
        failure shows an error dialog — it must never take the desktop down."""
        from apps import xpane
        try:
            pane = xpane.XPane(
                self.desk, list(argv), title, icon=icon, app_size=app_size,
                cwd=cwd or os.path.expanduser("~"), fill=True,
                cleanup=cleanup)
            pane.kilix_application_id = application_id
            self.desk.wm.add(pane)
            return True
        except Exception as e:
            if cleanup is not None:
                cleanup()
            wm.msgbox(self.desk, title,
                      f"Could not open '{title}' in a window:\n{e}",
                      icon="error")
            return False

    # ── recents ─────────────────────────────────────────────────────────────
    def add_recent(self, path):
        r = [p for p in self.state.get("recent", []) if p != path]
        r.insert(0, path)
        self.state["recent"] = r[:10]
        self._save_state()

    def recent_docs(self):
        return [(_menu_label(os.path.basename(p)), p)
                for p in self.state.get("recent", [])
                if os.path.exists(p)]

    # ── dialogs ─────────────────────────────────────────────────────────────
    def run_dialog(self):
        def do(cmd):
            if not cmd or not cmd.strip():
                return
            first = os.path.expanduser(split_cmd(cmd)[0])
            if self._resolve_program(first):
                self._spawn_kitty_launch(["--type=tab"], cmd,
                                         split_cmd(cmd)[0])
                return
            self.ask_kilix_dialog(cmd.strip())
        wm.inputbox(self.desk, "Run",
                    "Type the name of a program to open it in a kilix tab:",
                    "", cb=do, icon="run", width=320)

    def ask_kilix_dialog(self, text):
        """Confirm, then hand `text` to `kilix ask` in a tab. This dialog
        never acts on the request: the plan and the y/N prompt live in the
        terminal."""
        def chosen(label):
            if label == "OK":
                self.ask_kilix(text)
        wm.msgbox(self.desk, "Run", f"Ask Kilix: {text}?", icon="question",
                  buttons=("OK", "Cancel"), cb=chosen)

    def ask_kilix(self, text):
        # _tab takes an argv list, so the text stays one literal argument;
        # `--` keeps text that starts with a dash from reading as an option.
        # The tab closes when its command exits, so --hold keeps the result.
        return self._tab(["kilix", "ask", "--hold", "--", text], "Ask Kilix")

    def ask_voice(self):
        return self._tab(["kilix", "ask", "--voice", "--hold"], "Ask Kilix")

    def change_password_dialog(self):
        """Modal change-password dialog (masked fields), backed by the
        plebian-os-passwd helper. On success the default-password tray nag
        clears; on failure the helper's reason is shown inline."""
        import security
        desk = self.desk
        win = wm.Window(desk, "Change Password", 322, 210,
                        icon="warn", resizable=False, modal=True)
        cw = win.client_size()[0]
        win.add(W.Label(12, 12, "Set a new login password for this account."))
        win.add(W.Label(12, 42, "New password:"))
        new = win.add(W.TextField(122, 40, cw - 134, "", mask=True))
        win.add(W.Label(12, 70, "Confirm:"))
        conf = win.add(W.TextField(122, 68, cw - 134, "", mask=True))
        status = win.add(W.Label(12, 96, "", color=T.SHADOW))

        def fail(msg):
            status.set(msg)
            win.invalidate()

        def ok(*_):
            p1, p2 = new.text, conf.text
            if not p1:
                return fail("Enter a new password.")
            if p1 != p2:
                return fail("The passwords do not match.")
            if p1 == "plebian":
                return fail("Choose something other than the default.")
            okr, msg = security.change_password(p1)
            if okr:
                win.close()
                desk._refresh_password_nag()          # clears the tray icon
                wm.msgbox(desk, "Password Changed", msg, icon="info")
            else:
                fail(msg[:46])

        new.on_enter = lambda *_: win.set_focus(conf)
        conf.on_enter = ok
        win.add(W.Button(cw - 168, 130, 76, 24, "OK", cb=ok, default=True))
        win.add(W.Button(cw - 84, 130, 76, 24, "Cancel", cb=win.close))
        win.set_focus(new)
        desk.wm.add(win)
        return win

    def shutdown_dialog(self):
        desk = self.desk
        win = wm.Window(desk, f"Shut Down {T.PRODUCT_NAME}", 300, 250,
                        icon="shutdown", resizable=False, modal=True)
        cw, ch = win.client_size()
        win.add(W.Label(14, 12, "What do you want to do?"))

        def choose(fn):
            def go():
                win.close()
                fn()
            return go

        # one machine action (power off); the rest act on the desktop session
        opts = [
            ("Shut Down", self._power_off),          # turn the computer off
            ("Restart", self._restart_desktop),      # relaunch the desktop
            ("Exit to Terminal", desk.quit),         # leave the desktop → shell
            ("Update and Restart", self._update_and_restart),
        ]
        y = 40
        for label, fn in opts:
            win.add(W.Button(14, y, cw - 28, 26, label, cb=choose(fn)))
            y += 32
        win.add(W.Button(cw - 90, y + 6, 76, 24, "Cancel", cb=win.close))
        desk.wm.add(win)

    def show_bsod(self):
        self.desk.show_bsod()

    # ── shutdown actions ────────────────────────────────────────────────────
    def _power_off(self):
        voice = getattr(self.desk, 'system_voice', None)
        if voice is not None:
            voice.goodbye()
        # run in a tab so a permission error (rather than a silent no-op) shows
        self._spawn_kitty_launch(["--type=tab"], "systemctl poweroff",
                                 "Shut Down")

    def _restart_desktop(self):
        """Relaunch the desktop on a fresh process (loads updated
        code), then quit this one — the new tab takes over."""
        kilix = os.path.join(KILIX_HOME, "kilix")
        if self._tab(["env", "KILIX_IN_OVERLAY=1", kilix, "desktop"],
                     T.PRODUCT_NAME):
            self.desk.quit()
            return True
        return False

    def _update_and_restart(self):
        kilix = os.path.join(KILIX_HOME, "kilix")
        if self._spawn_kitty_launch(
            ["--type=tab"],
            f'{self._best_update_command()} && '
            f'exec env KILIX_IN_OVERLAY=1 "{kilix}" desktop',
            "Update and Restart"):
            self.desk.quit()

    def _best_update_command(self):
        """The most complete updater present: the whole-stack script, else
        `pleb update`, else `kilix update`."""
        pos = first_present(PLEBIAN_OS_UPDATE)
        if pos:
            return pos
        source_home = os.environ.get("GPU_TERMINAL_SOURCE_HOME") or \
            os.path.expanduser("~/.local/gpu_terminal/sources")
        pleb = os.path.join(
            os.path.abspath(os.path.expanduser(source_home)),
            "pleb", "bin", "pleb")
        if os.path.exists(pleb):
            return f'"{pleb}" update'
        return f'"{os.path.join(KILIX_HOME, "kilix")}" update'

    def about_dialog(self):
        wm.msgbox(self.desk, f"About {T.PRODUCT_NAME}",
                  f"{T.PRODUCT_NAME}\nA {T.STYLE_NAME} desktop for kilix.\n\n"
                  "Rendered as pixels over the kitty graphics protocol.\n"
                  "All artwork drawn in-house — no Redmond bits inside.",
                  icon="flame")

    def display_properties(self):
        self.open_app("displayprops")


# ── launcher file helpers ────────────────────────────────────────────────────

def parse_launcher(path):
    return directory_listing.parse_launcher(path)


def write_launcher(path, spec):
    cp = configparser.ConfigParser(interpolation=None)
    cp.optionxform = str
    cp["Desktop Entry"] = {"Version": "1.0", **spec}
    with open(path, "w") as f:
        cp.write(f)


def safe_name(name):
    return "".join(c if c.isalnum() or c in "-_ ." else "_" for c in name)


def unique_path(path):
    if not os.path.exists(path):
        return path
    base, ext = os.path.splitext(path)
    i = 2
    while os.path.exists(f"{base} ({i}){ext}"):
        i += 1
    return f"{base} ({i}){ext}"


def split_cmd(cmd):
    import shlex
    try:
        return shlex.split(cmd) or [cmd]
    except ValueError:
        return [cmd]


def desktop_exec_argv(spec, desktop_path=None):
    """Expand a freedesktop Exec line when no files/URLs are selected.

    File and URL placeholders make their entire argument unavailable; dropping
    the whole token avoids debris such as ``--url=`` or ``prepost``. The name,
    desktop-file and icon codes retain their specified argument semantics.
    """
    import shlex
    try:
        words = shlex.split(spec.get("Exec", ""))
    except ValueError:
        return []
    out = []
    unavailable = set("fFuUhdDnNvm")
    for word in words:
        if word == "%i":
            icon = spec.get("Icon")
            if icon:
                out.extend(["--icon", icon])
            continue
        if word == "%c":
            if spec.get("Name"):
                out.append(spec["Name"])
            continue
        if word == "%k":
            if desktop_path:
                out.append(os.path.abspath(desktop_path))
            continue

        expanded = []
        drop = False
        index = 0
        while index < len(word):
            if word[index] != "%" or index + 1 >= len(word):
                expanded.append(word[index])
                index += 1
                continue
            code = word[index + 1]
            if code == "%":
                expanded.append("%")
            elif code in unavailable or code in {"i"}:
                drop = True
                break
            elif code == "c":
                expanded.append(spec.get("Name", ""))
            elif code == "k":
                expanded.append(os.path.abspath(desktop_path)
                                if desktop_path else "")
            else:
                expanded.extend(("%", code))
            index += 2
        value = "".join(expanded)
        if not drop and value:
            out.append(value)
    return out


def shell_quote(s):
    import shlex
    return shlex.quote(s)


SSH_ENABLE_WARNING = (
    "Turn on the SSH server?",
    "",
    "Every account on this computer that has a password can then log in over",
    "the network. Anyone who can reach this computer and knows or guesses one",
    "of those passwords can log in as that account.",
    "",
)


def ssh_enable_command(helper):
    """Start > System > Remote login (SSH) > Turn SSH on, as a bash command:
    warn, ask [y/N] in the tab, and run the helper only on an explicit yes.
    Enter, end of input or anything else changes nothing and shows the state."""
    quoted = shell_quote(helper)
    lines = " ".join(shell_quote(line) for line in SSH_ENABLE_WARNING)
    return (f'printf "%s\\n" {lines}; '
            'printf "Turn SSH on now? [y/N] "; '
            'answer=""; read -r answer; '
            'case "$answer" in '
            f'[yY]|[yY][eE][sS]) sudo {quoted} enable ;; '
            f'*) echo "SSH was not changed."; {quoted} status ;; '
            'esac')
