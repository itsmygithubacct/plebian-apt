#!/usr/bin/env python3
"""kilix 95 — the Games section: registry + on-demand installers.

`games.py doom` is what Start ▸ Programs ▸ Games ▸ Doom runs (in a new kilix
tab). If the Kilix 95 games config points at a working DOSBox and Doom, it
boots straight in; otherwise it downloads the official shareware episode
(id's doom19s.zip from the idgames mirrors — the shareware episode is freely
redistributable) and, when no dosbox is installed, a dosbox-staging release
build, stores everything under ~/.local/gpu_terminal/kilix-95/data/games/,
writes the
config, and boots. Nothing is written inside the kilix tree.

No DOS needed for the install: doom19s.zip's DEICE parts (DOOMS_19.1/.2)
concatenate into a self-extracting ZIP that python's zipfile reads directly.

Inside kilix the game runs through `kilix run` (DOSBox on a private X server,
streamed into the pane); on a plain X session it just runs DOSBox.
"""
import configparser
import hashlib
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import zipfile

import host as kilix_host
import storage

HOME = os.path.expanduser("~")
CONF = storage.config_dir("games.conf")
GAMES_DIR = storage.data_dir("games")
APPS_DIR = storage.data_dir("apps")
KILIX_HOME = kilix_host.find_kilix_home()
from kilix_sdk import content as kilix_content
from kilix_sdk import settings as shared_settings

DOOM_URLS = [  # idgames mirrors of id Software's shareware installer
    "https://www.gamers.org/pub/idgames/idstuff/doom/doom19s.zip",
    "https://ftp.fu-berlin.de/pc/games/idgames/idstuff/doom/doom19s.zip",
    "https://youfailit.net/pub/idgames/idstuff/doom/doom19s.zip",
]
DOOM_ZIP_SHA256 = "cacf0142b31ca1af00796b4a0339e07992ac5f21bc3f81e7532fe1b5e1b486e6"
DOOM1_WAD_MD5 = "f0cefca49926d00903cf57551d901abe"      # shareware 1.9

DOSBOX_VER = "v0.82.2"
DOSBOX_URL = ("https://github.com/dosbox-staging/dosbox-staging/releases/"
              f"download/{DOSBOX_VER}/dosbox-staging-linux-x86_64-"
              f"{DOSBOX_VER}.tar.xz")
DOSBOX_SHA256 = "bc229df72ea103b7865cdca67324772dbffa8e58866477e69a79638b723a0442"

CONTENT_CATALOG = kilix_content.default_catalog()


def _catalog_source(content_id):
    spec = CONTENT_CATALOG.require(content_id)
    return spec.repository, spec.ref


BASHED_REPO, BASHED_REF = _catalog_source("bashed-earth")
JPAK_REPO, JPAK_REF = _catalog_source("kilix-jpak")
RANCHER_REPO, RANCHER_REF = _catalog_source("kilix-rancher")
PONG_REPO, PONG_REF = _catalog_source("kilix-pong")
JOUSTIX_REPO, JOUSTIX_REF = _catalog_source("joustix")
CHESS_BASH_REPO, CHESS_BASH_REF = _catalog_source("chess-bash")
FISHTANK_REPO, FISHTANK_REF = _catalog_source("kilix-fishtank")
LANDER_REPO, LANDER_REF = _catalog_source("terminal-lander")
BROKEOUT_REPO, BROKEOUT_REF = _catalog_source("kitty-brokeout")
AMP_REPO, AMP_REF = _catalog_source("kilix-amp")


def _menu_entry(spec):
    return {
        "label": spec.label,
        "icon": spec.icon,
        "blurb": (spec.description.rstrip(".")
                  + ".\nInstall into Kilix 95's private data directory and launch?"),
    }


_INSTALLABLE_SOURCES = frozenset({"git", "archive"})


def _catalog_game_supported(spec):
    """Whether this desktop knows how to install and launch a catalog entry."""
    if spec.content_id in ("doom", "dosbox"):
        return True
    return (spec.kind == "game"
            and spec.source_type in _INSTALLABLE_SOURCES
            and spec.launch_mode == "terminal")


# The Start-menu registry is a view of the host-owned content catalog. DOSBox
# remains in Games even though the catalog classifies the prompt as an app.
# Do not advertise entries whose source/launch contract this provider cannot
# satisfy: a host catalog may grow independently of Kilix 95.
GAMES = {
    spec.content_id: _menu_entry(spec)
    for spec in CONTENT_CATALOG
    if _catalog_game_supported(spec)
}


def game_enabled(game):
    """Whether the shared GPU Terminal settings expose ``game``."""
    return shared_settings.game_enabled(game)


def available_games(availability=None):
    """The enabled registry entries, retaining catalog menu order."""
    availability = (shared_settings.game_availability()
                    if availability is None else availability)
    return {
        name: meta for name, meta in GAMES.items()
        if availability[name]
    }


def load():
    # interpolation=None so a '%' in a stored path is literal, not a token;
    # a malformed conf reads as empty (== "no game installed") instead of
    # taking down whatever called a *_ready() check.
    cp = configparser.ConfigParser(interpolation=None)
    try:
        cp.read(CONF)
    except configparser.Error:
        cp = configparser.ConfigParser(interpolation=None)
    return cp


def save(cp):
    directory = os.path.dirname(CONF)
    os.makedirs(directory, exist_ok=True)
    fd, pending = tempfile.mkstemp(prefix=".games.conf.", dir=directory)
    try:
        # mkstemp creates the file as 0600 regardless of the caller's umask.
        # Replacing the destination also avoids following a pre-existing
        # games.conf symlink and reconciles older, overly broad file modes.
        with os.fdopen(fd, "w") as stream:
            fd = -1
            cp.write(stream)
        os.replace(pending, CONF)
        pending = None
    finally:
        if fd >= 0:
            os.close(fd)
        if pending is not None:
            try:
                os.unlink(pending)
            except FileNotFoundError:
                pass


def _find(d, name):
    """Case-insensitive file search under d; returns a path or None."""
    for root, _dirs, files in os.walk(d):
        for f in files:
            if f.lower() == name.lower():
                return os.path.join(root, f)
    return None


def doom_ready(cp=None):
    """(dosbox, doom_exe) if the config points at a working install."""
    cp = cp or load()
    if not cp.has_section("doom"):
        return None
    dosbox = os.path.expanduser(cp.get("doom", "dosbox", fallback=""))
    ddir = os.path.expanduser(cp.get("doom", "dir", fallback=""))
    if not (dosbox and os.access(dosbox, os.X_OK) and os.path.isdir(ddir)):
        return None
    exe = _find(ddir, "DOOM.EXE")
    wad = _find(ddir, "DOOM1.WAD") or _find(ddir, "DOOM.WAD")
    return (dosbox, exe) if exe and wad else None


def dosbox_ready(cp=None):
    """Path to a runnable dosbox if one is already available (no install):
    config > $PATH > previously vendored."""
    cp = cp or load()
    cur = os.path.expanduser(cp.get("dosbox", "exe", fallback=""))
    if cur and os.access(cur, os.X_OK):
        return cur
    for name in ("dosbox", "dosbox-staging", "dosbox-x"):
        p = shutil.which(name)
        if p:
            return p
    vend = os.path.join(GAMES_DIR, "dosbox-staging")
    exe = _find(vend, "dosbox") if os.path.isdir(vend) else None
    return exe if exe and os.access(exe, os.X_OK) else None


def game_ready(game, cp=None):
    """Installed-and-runnable check dispatched by game name (None if not)."""
    cp = cp or load()
    if game == "doom":
        return doom_ready(cp)
    if game == "dosbox":
        return dosbox_ready(cp)
    spec = CONTENT_CATALOG.get(game)
    if spec is not None and _catalog_game_supported(spec):
        return _catalog_ready(game, cp)
    return None


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _fetch(urls, dest, report, sha256=None):
    """Compatibility wrapper around the host's checksum-bound downloader."""
    try:
        return kilix_content.download(
            urls, dest, report=report, expected_sha256=sha256 or "")
    except kilix_content.InstallError:
        # The Content mirror error includes the final URL, which may contain
        # private paths or credentials. Keep it out of the desktop message.
        raise kilix_content.InstallError("content download failed") from None


def _inside(root, path):
    root = os.path.abspath(root)
    path = os.path.abspath(path)
    return os.path.commonpath([root, path]) == root


def _safe_extract_tar(tar, dest):
    """Compatibility wrapper around the host's safe tar extractor."""
    return kilix_content.safe_extract_tar(tar, dest)


def _safe_extract_zip(archive, dest):
    """Compatibility wrapper around the host's safe ZIP extractor."""
    return kilix_content.safe_extract_zip(archive, dest)


def ensure_dosbox(cp, report):
    """A runnable dosbox: config > $PATH > previously vendored > download."""
    cur = os.path.expanduser(cp.get("doom", "dosbox", fallback=""))
    if cur and os.access(cur, os.X_OK):
        return cur
    for name in ("dosbox", "dosbox-staging", "dosbox-x"):
        p = shutil.which(name)
        if p:
            report(f"using system {name}: {p}")
            return p
    vend = os.path.join(GAMES_DIR, "dosbox-staging")
    exe = _find(vend, "dosbox") if os.path.isdir(vend) else None
    if exe and os.access(exe, os.X_OK):
        return exe
    if os.uname().machine != "x86_64":
        raise RuntimeError(
            "no dosbox on PATH and the dosbox-staging release build is "
            f"x86_64-only (this is {os.uname().machine}) — install dosbox "
            "with your package manager, or set [doom] dosbox= in "
            f"{CONF}")
    os.makedirs(vend, exist_ok=True)
    tar = os.path.join(vend, "dosbox.tar.xz")
    _fetch(DOSBOX_URL, tar, report, sha256=DOSBOX_SHA256)
    report("unpacking dosbox-staging …")
    with tarfile.open(tar, "r:xz") as t:
        _safe_extract_tar(t, vend)
    os.unlink(tar)
    exe = _find(vend, "dosbox")
    if not (exe and os.path.isfile(exe) and os.access(exe, os.X_OK)):
        raise RuntimeError("dosbox-staging unpack yielded no dosbox binary")
    return exe


def ensure_doom(cp, report):
    """A directory with DOOM.EXE + DOOM1.WAD: config > vendored > download."""
    cur = os.path.expanduser(cp.get("doom", "dir", fallback=""))
    if cur and _find(cur, "DOOM.EXE") and (_find(cur, "DOOM1.WAD")
                                           or _find(cur, "DOOM.WAD")):
        return cur
    ddir = os.path.join(GAMES_DIR, "doom")
    if _find(ddir, "DOOM.EXE") and _find(ddir, "DOOM1.WAD"):
        return ddir
    os.makedirs(ddir, exist_ok=True)
    outer = os.path.join(ddir, "doom19s.zip")
    _fetch(DOOM_URLS, outer, report, sha256=DOOM_ZIP_SHA256)
    report("extracting the shareware episode …")
    with zipfile.ZipFile(outer) as z:
        _safe_extract_zip(z, ddir)
    # DEICE's split archive: DOOMS_19.1 + DOOMS_19.2 = a self-extracting ZIP
    joined = os.path.join(ddir, "dooms_19.sfx")
    with open(joined, "wb") as out:
        for part in ("DOOMS_19.1", "DOOMS_19.2"):
            p = _find(ddir, part)
            if not p:
                raise RuntimeError(f"{part} missing from doom19s.zip")
            with open(p, "rb") as f:
                out.write(f.read())
    with zipfile.ZipFile(joined) as z:      # zipfile handles the MZ stub
        _safe_extract_zip(z, ddir)
    for junk in ("doom19s.zip", "dooms_19.sfx", "DOOMS_19.1", "DOOMS_19.2",
                 "DOOMS_19.DAT", "DEICE.EXE", "INSTALL.BAT"):
        p = _find(ddir, junk)
        if p:
            os.unlink(p)
    wad = _find(ddir, "DOOM1.WAD")
    if not (wad and _find(ddir, "DOOM.EXE")):
        raise RuntimeError("extraction yielded no DOOM.EXE/DOOM1.WAD")
    md5 = hashlib.md5(open(wad, "rb").read()).hexdigest()
    if md5 != DOOM1_WAD_MD5:
        raise RuntimeError(
            f"DOOM1.WAD md5 {md5} differs from the known 1.9 build")
    return ddir


# DOSBox: fullscreen on its private X server, which `kilix run` sizes to the
# pane's exact pixel area — so the game fills the WHOLE pane, no letterbox
# (aspect=false: pane aspect wins over VGA aspect). Sound on (Doom autodetects
# the emulated Sound Blaster). Understood by classic DOSBox and staging.
DOSBOX_CONF = """\
[sdl]
fullscreen=true
fullresolution=desktop
output=opengl

[render]
aspect=false

[mixer]
nosound=false
rate=44100
"""

# Doom merges this with its built-in defaults: fire on Space (57), use/open
# on Ctrl (157 = right-ctrl) — swapped from the DOS defaults per taste — and
# the Sound Blaster settings SETUP.EXE would normally write (without them the
# engine defaults to NO sound devices). Device 3 = Sound Blaster: digital sfx
# + OPL FM music, exactly what DOSBox emulates at 220/7/1.
DOOM_CFG = """\
key_fire\t\t57
key_use\t\t\t157
sfx_volume\t\t8
music_volume\t\t8
snd_channels\t\t3
snd_musicdevice\t\t3
snd_sfxdevice\t\t3
snd_sbport\t\t544
snd_sbirq\t\t7
snd_sbdma\t\t1
"""


def _write_settings(ddir, report):
    """Drop the dosbox conf + key bindings next to the game (created once;
    a user-edited file is never overwritten)."""
    conf = os.path.join(ddir, "dosbox-kilix.conf")
    if not os.path.exists(conf):
        with open(conf, "w") as f:
            f.write(DOSBOX_CONF)
        report("wrote dosbox-kilix.conf (fullscreen, aspect, sound on)")
    exe = _find(ddir, "DOOM.EXE")
    cfg = os.path.join(os.path.dirname(exe), "DEFAULT.CFG") if exe else None
    if cfg and not os.path.exists(cfg):
        with open(cfg, "w") as f:
            f.write(DOOM_CFG)
        report("wrote DEFAULT.CFG (fire = Space, use = Ctrl)")
    return conf


def _write_dosbox_conf(report):
    """The shared fullscreen/sound dosbox conf in the games dir (once)."""
    os.makedirs(GAMES_DIR, exist_ok=True)
    conf = os.path.join(GAMES_DIR, "dosbox-kilix.conf")
    if not os.path.exists(conf):
        with open(conf, "w") as f:
            f.write(DOSBOX_CONF)
        report("wrote dosbox-kilix.conf (fullscreen, sound on)")
    return conf


def _audio_check(report):
    import subprocess
    try:
        r = subprocess.run(["pactl", "info"], capture_output=True, text=True,
                           timeout=5)
        if r.returncode == 0:
            srv = next((ln.split(":", 1)[1].strip()
                        for ln in r.stdout.splitlines()
                        if ln.startswith("Server Name")), "PulseAudio")
            report(f"audio: {srv} reachable — DOSBox sound will work")
            return
    except (OSError, subprocess.TimeoutExpired):
        pass
    report("audio: no PulseAudio/PipeWire found — Doom will run silent")


def _verify_source_checkout(repo, ref, dest):
    """Require the expected origin, pinned HEAD, and clean dependencies."""
    return kilix_content.verify_git_checkout(repo, ref, dest)


def _clone_and_make(repo, ref, dest, binary, dep_hint, report):
    """Compatibility entry point backed by the host's atomic installer."""
    dest = os.path.abspath(os.path.expanduser(dest))
    build = [] if os.path.isdir(repo) and os.access(
        os.path.join(repo, binary), os.X_OK) else ["make"]
    spec = kilix_content.ContentSpec.from_mapping({
        "id": os.path.basename(dest),
        "label": os.path.basename(dest),
        "source": {"type": "git", "repository": repo, "ref": ref},
        "binary": binary,
        "build": build,
        "dependency_hint": dep_hint,
    })
    return kilix_content.Installer(os.path.dirname(dest)).ensure(spec, report)


def _repo_ready(cp, section, binary, managed_dir, repo, ref):
    if not cp.has_section(section):
        return None
    d = os.path.expanduser(cp.get(section, "dir", fallback=""))
    if not d:
        return None
    spec = kilix_content.ContentSpec.from_mapping({
        "id": os.path.basename(managed_dir),
        "label": section,
        "source": {"type": "git", "repository": repo, "ref": ref},
        "binary": binary,
    })
    return kilix_content.Installer(os.path.dirname(managed_dir)).ready(
        spec, directory=d)


def _content_root(spec):
    return APPS_DIR if spec.kind == "app" else GAMES_DIR


def _configured_content_dir(cp, content_id):
    if not cp.has_section(content_id):
        return None
    directory = os.path.expanduser(
        cp.get(content_id, "dir", fallback=""))
    return directory or None


def _catalog_ready(content_id, cp=None):
    cp = cp or load()
    spec = CONTENT_CATALOG.require(content_id)
    if spec.source_type not in _INSTALLABLE_SOURCES:
        return None
    directory = _configured_content_dir(cp, content_id)
    if directory is None:
        return None
    return kilix_content.Installer(_content_root(spec)).ready(
        spec, directory=directory)


def _catalog_ensure(content_id, cp, report):
    """Return the executable and the install root to persist in config."""
    spec = CONTENT_CATALOG.require(content_id)
    if spec.source_type not in _INSTALLABLE_SOURCES:
        raise RuntimeError(
            f"{content_id} does not use a shared installable source")
    installer = kilix_content.Installer(_content_root(spec))
    directory = _configured_content_dir(cp, content_id)
    ready = (installer.ready(spec, directory=directory)
             if directory is not None else None)
    if ready:
        return ready, directory
    return installer.ensure(spec, report), installer.destination(spec)


def bashed_ready(cp=None):
    return _repo_ready(
        cp or load(), "bashed-earth", "bashed-earth",
        os.path.join(GAMES_DIR, "bashed-earth"), BASHED_REPO, BASHED_REF)


def ensure_bashed(cp, report):
    return bashed_ready(cp) or _clone_and_make(
        BASHED_REPO, BASHED_REF, os.path.join(GAMES_DIR, "bashed-earth"), "bashed-earth",
        "needs gcc/clang, zlib, make", report)


def jpak_ready(cp=None):
    return _repo_ready(
        cp or load(), "kilix-jpak", "kilix-jpak",
        os.path.join(GAMES_DIR, "kilix-jpak"), JPAK_REPO, JPAK_REF)


def ensure_jpak(cp, report):
    return jpak_ready(cp) or _clone_and_make(
        JPAK_REPO, JPAK_REF, os.path.join(GAMES_DIR, "kilix-jpak"),
        "kilix-jpak", "needs a C compiler, zlib, libm, pthreads, and make",
        report)


def rancher_ready(cp=None):
    return _repo_ready(
        cp or load(), "kilix-rancher", "kilix-rancher",
        os.path.join(GAMES_DIR, "kilix-rancher"),
        RANCHER_REPO, RANCHER_REF)


def ensure_rancher(cp, report):
    return rancher_ready(cp) or _clone_and_make(
        RANCHER_REPO, RANCHER_REF,
        os.path.join(GAMES_DIR, "kilix-rancher"), "kilix-rancher",
        "needs a C compiler, make, zlib, libm, and pthreads", report)


def pong_ready(cp=None):
    return _repo_ready(
        cp or load(), "kilix-pong", "kilix-pong",
        os.path.join(GAMES_DIR, "kilix-pong"), PONG_REPO, PONG_REF)


def ensure_pong(cp, report):
    return pong_ready(cp) or _clone_and_make(
        PONG_REPO, PONG_REF, os.path.join(GAMES_DIR, "kilix-pong"),
        "kilix-pong", "needs a C compiler, make, zlib, libm, and pthreads",
        report)


def joustix_ready(cp=None):
    return _repo_ready(
        cp or load(), "joustix", "joustix",
        os.path.join(GAMES_DIR, "joustix"), JOUSTIX_REPO, JOUSTIX_REF)


def ensure_joustix(cp, report):
    return joustix_ready(cp) or _clone_and_make(
        JOUSTIX_REPO, JOUSTIX_REF, os.path.join(GAMES_DIR, "joustix"),
        "joustix", "needs a C compiler + zlib, make", report)


def chess_bash_ready(cp=None):
    return _repo_ready(
        cp or load(), "chess-bash", "chess-bash",
        os.path.join(GAMES_DIR, "chess-bash"),
        CHESS_BASH_REPO, CHESS_BASH_REF)


def ensure_chess_bash(cp, report):
    return chess_bash_ready(cp) or _clone_and_make(
        CHESS_BASH_REPO, CHESS_BASH_REF,
        os.path.join(GAMES_DIR, "chess-bash"), "chess-bash",
        "needs a C compiler + zlib, make; Stockfish is optional", report)


def fishtank_ready(cp=None):
    return _repo_ready(
        cp or load(), "kilix-fishtank", "kilix-fishtank",
        os.path.join(GAMES_DIR, "kilix-fishtank"),
        FISHTANK_REPO, FISHTANK_REF)


def ensure_fishtank(cp, report):
    return fishtank_ready(cp) or _clone_and_make(
        FISHTANK_REPO, FISHTANK_REF,
        os.path.join(GAMES_DIR, "kilix-fishtank"), "kilix-fishtank",
        "needs a C compiler + zlib, libm, pthreads, and make", report)


def lander_ready(cp=None):
    return _repo_ready(
        cp or load(), "terminal-lander", "terminal-lander",
        os.path.join(GAMES_DIR, "terminal-lander"), LANDER_REPO, LANDER_REF)


def ensure_lander(cp, report):
    return lander_ready(cp) or _clone_and_make(
        LANDER_REPO, LANDER_REF, os.path.join(GAMES_DIR, "terminal-lander"),
        "terminal-lander", "needs a C compiler + zlib, make", report)


def brokeout_ready(cp=None):
    return _repo_ready(
        cp or load(), "kitty-brokeout", "kitty-brokeout",
        os.path.join(GAMES_DIR, "kitty-brokeout"), BROKEOUT_REPO, BROKEOUT_REF)


def ensure_brokeout(cp, report):
    return brokeout_ready(cp) or _clone_and_make(
        BROKEOUT_REPO, BROKEOUT_REF, os.path.join(GAMES_DIR, "kitty-brokeout"),
        "kitty-brokeout", "needs a C compiler + zlib, make", report)


def amp_ready(cp=None):
    # Keep the complete catalog recipe, including optional native dependencies;
    # the content installer owns ordinary managed-cache readiness semantics.
    cp = cp or load()
    spec = CONTENT_CATALOG.require("kilix-amp")
    directory = _configured_content_dir(cp, "kilix-amp")
    return kilix_content.Installer(_content_root(spec)).ready(
        spec, directory=directory)


def ensure_amp(cp, report):
    spec = CONTENT_CATALOG.require("kilix-amp")
    installer = kilix_content.Installer(_content_root(spec))
    ready = installer.ready(spec, directory=_configured_content_dir(cp, "kilix-amp"))
    return ready or installer.ensure(spec, report)


def ensure(game, report=print):
    cp = load()
    if not cp.has_section(game):
        cp.add_section(game)
    if game == "doom":
        dosbox = ensure_dosbox(cp, report)
        ddir = ensure_doom(cp, report)
        conf = _write_settings(ddir, report)
        _audio_check(report)
        cp.set("doom", "dosbox", dosbox)
        cp.set("doom", "dir", ddir)
        payload = (dosbox, conf, _find(ddir, "DOOM.EXE"))
    elif game == "dosbox":
        dosbox = ensure_dosbox(cp, report)
        conf = _write_dosbox_conf(report)
        _audio_check(report)
        cp.set("dosbox", "exe", dosbox)
        payload = (dosbox, conf)
    elif ((spec := CONTENT_CATALOG.get(game)) is not None
          and spec.source_type in _INSTALLABLE_SOURCES):
        exe, directory = _catalog_ensure(game, cp, report)
        cp.set(game, "dir", directory)
        payload = exe
    else:
        raise SystemExit(f"kilix games: unknown game {game!r}")
    save(cp)
    report(f"ready — config saved to {CONF}")
    return payload


def _launch_doom(payload):
    dosbox, conf, exe = payload
    kilix = os.path.join(KILIX_HOME, "kilix")
    argv = [dosbox, "-conf", conf, exe, "-exit"]
    if os.environ.get("KITTY_WINDOW_ID") and os.access(kilix, os.X_OK):
        # already in our own tab: run DOSBox in-place through `kilix run`.
        # 640x400 = Doom's own 16:10, so DOSBox fullscreen has zero bars;
        # --fill then stretches the placement over the WHOLE pane.
        os.environ["KILIX_IN_OVERLAY"] = "1"
        os.execv(kilix, [kilix, "run", "--fill", "--size", "640x400"] + argv)
    elif os.environ.get("DISPLAY"):
        os.execv(dosbox, argv)                # plain X session
    raise SystemExit("kilix games: no display (run inside kilix or X)")


def _launch_dosbox(payload):
    dosbox, conf = payload
    kilix = os.path.join(KILIX_HOME, "kilix")
    # boot to a DOS prompt with C: mounted at the games folder, so any DOS
    # programs dropped there are one `C:` away
    argv = [dosbox, "-conf", conf,
            "-c", f'mount c "{GAMES_DIR}"', "-c", "c:"]
    if os.environ.get("KITTY_WINDOW_ID") and os.access(kilix, os.X_OK):
        # 640x400 = 80x25 VGA text, so the prompt is crisp; --fill stretches
        # the placement over the whole pane (aspect=false in the conf)
        os.environ["KILIX_IN_OVERLAY"] = "1"
        os.execv(kilix, [kilix, "run", "--fill", "--size", "640x400"] + argv)
    elif os.environ.get("DISPLAY"):
        os.execv(dosbox, argv)                # plain X session
    raise SystemExit("kilix games: no display (run inside kilix or X)")


def _launch_native(exe):
    # a native terminal game that speaks the kitty graphics protocol itself:
    # runs right here in the tab
    os.chdir(os.path.dirname(exe))
    os.execv(exe, [exe])


def host_game_ready(game):
    """Whether the HOST already has `game` installed and runnable.

    Once the play verb exists the install truth lives host-side, so the
    menu's play-immediately-or-ask-first decision must ask the authority
    that will do the installing — otherwise a game the host installed would
    prompt "isn't set up yet" forever. `kilix install --json` is that
    authority's own report. Only called behind a host_play_argv() probe, so
    an old host is never handed a subcommand it does not know.
    """
    import json
    kilix = os.path.join(KILIX_HOME, "kilix")
    if not os.access(kilix, os.X_OK):
        return False
    try:
        result = subprocess.run(
            [kilix, "install", "--json"], stdin=subprocess.DEVNULL,
            capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.TimeoutExpired):
        return False
    if result.returncode != 0:
        return False
    try:
        rows = json.loads(result.stdout)
    except ValueError:
        return False
    return any(row.get("id") == game and row.get("installed")
               for row in rows if isinstance(row, dict))


def host_play_argv(game, setup_only=False):
    """argv for the host's `kilix games play`, or None when the host
    predates the verb.

    The host verb is the one install-and-boot implementation, backed by the
    same pinned content catalog: delegating keeps a Start-menu launch, a
    typed command, and every other desktop's launch on one build, installed
    once in the host's private data directory. Probed rather than assumed so
    this checkout still boots games by itself on an older host.
    """
    kilix = os.path.join(KILIX_HOME, "kilix")
    if not os.access(kilix, os.X_OK):
        return None
    try:
        probe = subprocess.run(
            [kilix, "games", "help"], stdin=subprocess.DEVNULL,
            capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if probe.returncode != 0 or "play GAME" not in probe.stdout:
        return None
    argv = [kilix, "games", "play", game]
    if setup_only:
        argv.append("--setup-only")
    return argv


def main():
    try:
        shared_settings.ensure_file()
    except OSError as error:
        raise SystemExit(
            f"kilix games: cannot initialize shared settings: {error}")
    args = [a for a in sys.argv[1:]]
    setup_only = "--setup-only" in args
    args = [a for a in args if a != "--setup-only"]
    game = args[0] if args else "doom"
    if game in GAMES and not game_enabled(game):
        label = GAMES[game]["label"]
        raise SystemExit(
            f"kilix games: {label} is disabled; "
            f"run 'kilix games enable {game}' to make it available")
    # A working local install keeps working — offline boxes and pre-verb
    # setups must never be forced through a reinstall. Everything else is
    # delegated to the host, which owns install-and-boot from here on.
    host_argv = None if game_ready(game) else host_play_argv(game, setup_only)
    if host_argv:
        try:
            os.execv(host_argv[0], host_argv)
        except OSError:
            pass                # fall back to this checkout's own installer
    try:
        payload = ensure(game)
    except Exception as e:      # BadZipFile/TarError/configparser.Error too
        # keep the message readable in the tab instead of vanishing with it
        print(f"\x1b[1;31mkilix games: {e}\x1b[0m", file=sys.stderr)
        try:
            input("\n[Enter to close]")
        except EOFError:
            pass
        sys.exit(1)
    if setup_only:
        return
    if game == "doom":
        _launch_doom(payload)
    elif game == "dosbox":
        _launch_dosbox(payload)
    else:
        _launch_native(payload)


if __name__ == "__main__":
    main()
