"""kilix desktop — Media Player: kilix-amp (Winamp 2.x clone) in an XPane.

Packaged desktops launch the installed player. A configured source install
uses the content catalog. Both run inside the same private XPane.
"""
import os

import wm
import storage
from . import xpane


def _runtime_env():
    """Private app state, with receipts resolved at the desktop installer root."""
    import games

    roots = {
        "XDG_CONFIG_HOME": storage.config_dir("app-state"),
        "XDG_DATA_HOME": storage.data_dir("app-state"),
        "XDG_STATE_HOME": storage.state_dir("app-state"),
        "XDG_CACHE_HOME": storage.cache_dir("app-state"),
    }
    environment = {name: storage.private_dir(path) for name, path in roots.items()}
    environment["KILIX_CONTENT_ROOT"] = os.path.normpath(games.APPS_DIR)
    return environment


def open_amp(desk, path=None):
    import games
    config = games.load()
    exe = None
    if not config.get("kilix-amp", "dir", fallback="") and os.path.isfile(
            os.path.join(games.KILIX_HOME, "PACKAGED")):
        from kilix_sdk._content_runtime import packaged_amp
        try:
            exe = packaged_amp(games.KILIX_HOME)
        except FileNotFoundError as error:
            wm.msgbox(desk, "Media Player", str(error), icon="amp")
            return
    exe = exe or games.amp_ready(config)
    if exe:
        _spawn(desk, exe, path)
        return

    def answered(ans):
        if ans == "Install":
            desk.wm.add(xpane.InstallerWindow(
                desk, "kilix-amp", "Media Player",
                on_ok=lambda: _spawn(desk, games.amp_ready(), path)))

    wm.msgbox(desk, "Media Player",
              "The media player isn't built yet.\n\n"
              "Clone and build kilix-amp (a Winamp 2.x clone,\n"
              "github.com/itsmygithubacct/kilix-amp) into\n"
              "~/.local/gpu_terminal/kilix-95/data/apps?\n"
              "(Needs libsdl2-dev, libsdl2-image-dev,\n"
              "libsndfile1-dev, zlib1g-dev, libfluidsynth-dev\n"
              "and a GM SoundFont to compile and play MIDI.)",
              icon="amp", buttons=("Install", "Cancel"), cb=answered)


def _seed_sample(amp_dir):
    """Copy the bundled sample track into ~/Music (where kilix-amp's Open
    dialog opens) so the player has something to try on first use. Once."""
    try:
        src = os.path.join(amp_dir, "samples", "ode-to-joy.ogg")
        if not os.path.isfile(src):
            return
        music = os.path.expanduser("~/Music")
        os.makedirs(music, exist_ok=True)
        dst = os.path.join(music, "Ode to Joy.ogg")
        if not os.path.exists(dst):
            import shutil
            shutil.copyfile(src, dst)
    except Exception:
        pass


def _seed_chimes():
    """Copy the bundled startup/shutdown chimes into ~/Music/Kilix so they can
    be played in the media player, not only heard at boot and shutdown.

    Only these short cues are placed here. They are the same files the desktop
    already ships, so this adds a convenience copy rather than distributing
    anything new.
    """
    cues = (
        ("95", "startup", "Kilix 95 Startup.wav"),
        ("95", "shutdown", "Kilix 95 Shutdown.wav"),
        ("xp", "startup", "Kilix XP Startup.wav"),
        ("xp", "shutdown", "Kilix XP Shutdown.wav"),
    )
    try:
        import shutil

        import sounds
        folder = os.path.join(os.path.expanduser("~/Music"), "Kilix")
        os.makedirs(folder, exist_ok=True)
        for flavor, cue, title in cues:
            src = sounds._asset_path(cue, flavor)
            dst = os.path.join(folder, title)
            if os.path.isfile(src) and not os.path.exists(dst):
                shutil.copyfile(src, dst)
    except Exception:
        pass


def _spawn(desk, exe, path=None):
    if not exe:
        wm.msgbox(desk, "Media Player",
                  "The Media Player install completed, but the pinned "
                  "executable did not pass its readiness check.",
                  icon="error")
        return
    d = os.path.dirname(os.path.realpath(exe))
    _seed_sample(d)
    _seed_chimes()
    cmd = [exe] + ([os.path.abspath(os.path.expanduser(path))] if path
                   else [])
    try:
        desk.wm.add(xpane.XPane(
            desk, cmd, "Media Player", icon="amp",
            # no app_size: the region fills the desktop working area, so the
            # skin can be dragged anywhere like Winamp and its stacked windows
            # (EQ / playlist) are never clipped
            # private, persistent config: window layout survives sessions and
            # never collides with a user-level kilix-amp install
            env=_runtime_env(),
            cwd=d))
    except Exception as e:
        wm.msgbox(desk, "Media Player",
                  f"Could not open Media Player:\n{e}", icon="error")
