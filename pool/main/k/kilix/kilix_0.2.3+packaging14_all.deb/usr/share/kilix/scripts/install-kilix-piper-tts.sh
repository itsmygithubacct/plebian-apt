#!/usr/bin/env bash
# Install the pinned Piper runtime only when the user selects its TTS tier.
set -euo pipefail
umask 077

KILIX_HOME="${KILIX_HOME:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
GPU_TERMINAL_HOME="${GPU_TERMINAL_HOME:-$HOME/.local/gpu_terminal}"
GPU_TERMINAL_SOURCE_HOME="${GPU_TERMINAL_SOURCE_HOME:-$GPU_TERMINAL_HOME/sources}"
KILIX_DATA_HOME="${KILIX_DATA_HOME:-$GPU_TERMINAL_HOME/kilix/data}"
KILIX_PIPER_REF=ad84b296c432797bc193a01c53e10253f9a291cf
KILIX_PIPER_REPO=https://github.com/itsmygithubacct/kilix-piper-tts.git

fail() { printf 'kilix piper: %s\n' "$*" >&2; exit 1; }
root="$KILIX_DATA_HOME/voice/piper"
source_dir="$GPU_TERMINAL_SOURCE_HOME/.kilix-piper-tts-$KILIX_PIPER_REF"
current="$root/current"

if [ "${1:-}" = --print-ref ]; then
  [ "$#" = 1 ] || fail 'usage: install-kilix-piper-tts.sh [--print-ref|--print-path]'
  printf '%s\n' "kilix-piper-tts=$KILIX_PIPER_REF"
  exit 0
fi
if [ "${1:-}" = --print-path ]; then
  [ "$#" = 1 ] || fail 'usage: install-kilix-piper-tts.sh [--print-ref|--print-path]'
  printf '%s\n' "$current/bin/kilix-piper-tts"
  exit 0
fi
[ "$#" = 0 ] || fail 'usage: install-kilix-piper-tts.sh [--print-ref|--print-path]'
content="$KILIX_HOME/third_party/kilix-content"
# Bind the runtime's authority to the host's selected Content gitlink. An old
# standalone pin rejected every newer RC2 catalog, even on a fresh install.
KILIX_CONTENT_REF="$(git -C "$KILIX_HOME" rev-parse HEAD:third_party/kilix-content)" \
  || fail 'could not identify the host Content pin'
[[ "$KILIX_CONTENT_REF" =~ ^[0-9a-f]{40}$ ]] || fail 'invalid host Content pin'
generation="$root/generations/$KILIX_PIPER_REF-$KILIX_CONTENT_REF"
binary="$generation/bin/kilix-piper-tts"
[ "$(id -u)" -ne 0 ] || fail 'run this as the desktop user'
case "$root" in /|"$HOME") fail 'refusing a broad runtime directory' ;; esac
case "$source_dir" in /|"$HOME") fail 'refusing a broad source directory' ;; esac
mkdir -p -- "$GPU_TERMINAL_SOURCE_HOME" "$root/generations"
[ ! -e "$current" ] || [ -L "$current" ] \
  || fail 'the managed Piper current path is not a symlink'
exec 9<"$root"
flock 9
if [ -L "$current" ]; then
  previous="$(readlink -- "$current")"
  case "$previous" in "$root/generations/"*) ;; \
    *) fail 'the managed Piper current link points outside the generation store' ;; esac
fi

# A completed generation is reusable; no package or model fetch on repeat use.
if [ -L "$current" ] && [ "$(readlink -- "$current")" = "$generation" ] \
    && [ -x "$binary" ] && "$binary" --version >/dev/null 2>&1 \
    && "$generation/bin/python" -c 'import kilix_content, kilix_license' >/dev/null 2>&1; then
  exit 0
fi

[ -f "$content/pyproject.toml" ] && [ ! -L "$content" ] \
  || fail 'the pinned Kilix Content checkout is unavailable'
command -v git >/dev/null || fail 'git is required for the pinned Piper source'
command -v uv >/dev/null || fail 'uv is required for the pinned Piper runtime'
[ "$(git -C "$content" rev-parse HEAD 2>/dev/null)" = "$KILIX_CONTENT_REF" ] \
  || fail 'the Kilix Content checkout has the wrong pinned commit'
[ -z "$(git -C "$content" status --porcelain 2>/dev/null)" ] \
  || fail 'the Kilix Content checkout has local changes'
if [ ! -d "$source_dir" ]; then
  stage="$(mktemp -d "$GPU_TERMINAL_SOURCE_HOME/.kilix-piper-tts-stage.XXXXXX")" \
    || fail 'could not stage the Piper source'
  trap 'rm -rf -- "$stage"' EXIT
  git -C "$stage" init -q
  git -C "$stage" remote add origin "$KILIX_PIPER_REPO"
  git -C "$stage" fetch -q --depth=1 origin "$KILIX_PIPER_REF" \
    || fail 'could not fetch the pinned Piper source'
  git -C "$stage" checkout -q --detach "$KILIX_PIPER_REF"
  mv -- "$stage" "$source_dir" || fail 'could not publish the pinned Piper source'
  trap - EXIT
fi
[ "$(git -C "$source_dir" rev-parse HEAD 2>/dev/null)" = "$KILIX_PIPER_REF" ] \
  || fail 'the managed Piper source has a different commit'
[ -z "$(git -C "$source_dir" status --porcelain 2>/dev/null)" ] \
  || fail 'the managed Piper source has local changes'

UV_PROJECT_ENVIRONMENT="$generation" uv sync --locked --no-dev \
  --directory "$source_dir" --project "$source_dir" --python 3.12.8 \
  || fail 'the pinned Piper environment could not be installed'
# Build from a disposable archive: setuptools writes build/ and egg-info,
# which must never contaminate the host's verified vendored authority tree.
content_stage="$(mktemp -d "$root/.content-build.XXXXXX")" \
  || fail 'could not stage the pinned Content build'
trap 'rm -rf -- "$content_stage"' EXIT
git -C "$content" archive "$KILIX_CONTENT_REF" | tar -x -C "$content_stage" \
  || fail 'could not extract the pinned Content tree'
uv pip install --python "$generation/bin/python" --no-deps \
  "$content_stage/third_party/kilix-license" "$content_stage" \
  || fail 'the pinned Content and licence packages could not be installed for Piper'
rm -rf -- "$content_stage"
trap - EXIT
[ -x "$binary" ] && "$binary" --version >/dev/null 2>&1 \
  && "$generation/bin/python" -c 'import kilix_content, kilix_license' >/dev/null 2>&1 \
  || fail 'the pinned Piper command failed verification'
link="$root/.current-$$"
ln -s -- "$generation" "$link"
mv -fT -- "$link" "$current" || fail 'could not publish the Piper runtime'
printf 'kilix piper: runtime ready; model downloads when first selected\n' >&2
