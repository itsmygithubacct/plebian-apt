"""Apply standard licence policy and collect decisions on additional terms."""
import hashlib
from pathlib import Path
from contextlib import nullcontext
import sys


class InstallFailures(RuntimeError):
    """Retain verified successes and exact failures from one consent batch."""

    def __init__(self, installed, declined, failures):
        self.installed = frozenset(installed)
        self.declined = frozenset(declined)
        self.failures = dict(failures)
        super().__init__('; '.join('Could not install ' + model for model in failures))


def text_key(payload):
    # Group questions by licence, but retain every distinct verbatim text.
    return hashlib.sha256(payload).hexdigest()


def ask(question, input_fn):
    while True:
        answer = input_fn(question + ' [y/N] ').strip().lower()
        if answer in ('y', 'yes'): return 'yes'
        if answer in ('', 'n', 'no'): return 'no'
        print('Please answer yes or no.')


def llm_license_covered(model, entries, saved, manifest_digest):
    """Reuse an actual prior answer only for the same manifest and licence bytes."""
    record = saved.get(model)
    if not isinstance(record, dict) or record.get('manifest_sha256') != manifest_digest:
        return False
    groups = record.get('groups')
    if not isinstance(groups, list):
        return False
    return bool(entries) and all(any(
        isinstance(group, dict) and group.get('licence') == label
        and group.get('capture_mode') == 'interactive-tty' and group.get('captured_at')
        and isinstance(group.get('text_sha256'), list)
        and text_key(payload) in group['text_sha256']
        for group in groups) for label, payload in entries)


def consent_and_install(selected, *, input_fn=input, before_install=None):
    """Return installed and declined IDs; retain successes when acquisitions fail.

    ``before_install(allowed)`` asks any remaining questions after the licence
    answers and before the first download, so the downloads run unattended.

    Every prompt names all affected assets. The authority still binds each
    affirmative capture to its own record and exact model manifest. A declined
    group creates no new receipt for, and never fetches, any affected model.
    """
    import content_models as cm
    import system_llm
    api, lic = cm._api(), cm._license()
    catalog = cm._verified_catalog(api)
    records, store = lic.load_determined_records(), lic.ReceiptStore.shared()
    content_ids = [model for model in selected if model not in system_llm.MODELS]
    llm_ids = [model for model in selected if model in system_llm.MODELS]
    specs = {model: catalog.require_asset(model) for model in content_ids}
    groups, requirements = {}, {model: set() for model in selected}
    captures, required_receipts, policy_records = {}, set(), set()
    from model_wizard import atomic_json, read_json, state_root
    with nullcontext(state_root() / 'license-documents') as scratch:
        texts = lic.load_determined_texts(Path(scratch) / 'texts')
        for model, spec in specs.items():
            documents = []
            for item in spec.licenses:
                record = cm._record(records, item.record_digest)
                digests = {'licence:' + item.license_id: item.text_sha256}
                for kind, entries in (('binding', record.binding_conditions),
                                      ('advisory', record.advisories), ('statement', record.statements)):
                    digests.update({kind + ':' + entry.id: entry.text_sha256 for entry in entries})
                digests.update({'component:' + entry.id: entry.exception_text_sha256
                                for entry in record.components if entry.exception_text_sha256})
                for label, digest in digests.items():
                    texts.get(digest, label=label)
                    documents.append({'label': label, 'sha256': digest,
                                      'path': str((texts.root / digest).absolute()),
                                      'url': (texts.root / digest).absolute().as_uri()})
                try:
                    lic.require(lic.AssetRef(model, record.digest, spec.manifest_digest),
                                records=records, store=store)
                except lic.CoverageRefused:
                    pass
                else:
                    continue
                required_receipts.add((model, record.digest))
                if lic.standard_policy_eligible(record):
                    policy_records.add((model, record.digest))
                    continue
                payload = texts.get(item.text_sha256, label=item.license_id)
                key = item.license_id
                group = groups.setdefault(key, dict(label=key, models=[], records={}, texts={}))
                group['texts'][text_key(payload)] = payload
                if model not in group['models']: group['models'].append(model)
                group['records'][record.digest] = record
                requirements[model].add(key)
            index = Path(scratch) / (model + '.json')
            atomic_json(index, {'model': model, 'manifest_sha256': spec.manifest_digest,
                                'documents': documents})
            print(f'{model}: licence documents: {index.absolute().as_uri()}')
        # Read only the pinned manifests and licence layers, never model weights.
        from model_wizard import atomic_json, read_json, state_root
        llm_licenses_path = state_root() / 'model-wizard-llm-licenses.json'
        saved = read_json(llm_licenses_path)
        failures = {}
        for model in llm_ids:
            try:
                entries = system_llm.license_texts([model]).get(model, [])
            except Exception as error:
                # An unreachable registry fails this model, not the whole batch.
                from model_wizard import error_detail
                failures[model] = error
                print(f'Could not read the licence for {model}: {error_detail(error)}', flush=True)
                print('Continuing with the other selected models.', flush=True)
                continue
            if llm_license_covered(model, entries, saved, system_llm.MODELS[model][3]):
                continue
            for label, payload in entries:
                key = label
                group = groups.setdefault(key, dict(label=key, models=[], records={}, texts={}))
                group['texts'][text_key(payload)] = payload
                if model not in group['models']: group['models'].append(model)
                requirements[model].add(key)
        accepted = set()
        for key, group in groups.items():
            print('\n' + '=' * 68)
            print('Licence: ' + group['label'])
            print('Applies to: ' + ', '.join(group['models']))
            # The base licence is shown once. Per-record binding/advisory text
            # remains verbatim, including changed-text markers from the authority.
            from kilix_license.changed import changed_texts, changed_block
            changes = {record.digest: changed_texts(record, store, records=records)
                       for record in group['records'].values()}
            for payload in group['texts'].values():
                for record in group['records'].values():
                    change = changes[record.digest].get(f'licence:{record.id}')
                    if change and change.shown_sha256 == hashlib.sha256(payload).hexdigest():
                        cm._emit(changed_block(change), 'changed licence', sys.stdout)
                cm._emit(api.first_use.crlf_to_lf(payload), 'licence', sys.stdout)
            for record in group['records'].values():
                from kilix_license.screen import _section
                changed = changes[record.digest]
                for kind, entries in (('binding', record.binding_conditions),
                                      ('advisory', record.advisories), ('statement', record.statements)):
                    for entry in entries:
                        cm._emit(api.first_use.crlf_to_lf(_section(f'{kind}:{entry.id}', entry.text_sha256, texts, changed)),
                                 'licence condition', sys.stdout)
                for component in record.components:
                    if component.exception_text_sha256:
                        cm._emit(api.first_use.crlf_to_lf(_section(f'component:{component.id}', component.exception_text_sha256, texts, changed)),
                                 'licence exception', sys.stdout)
            answer = ask('Do you accept ' + group['label'] + ' and the conditions shown for '
                         + ', '.join(group['models']) + '?', input_fn)
            if answer == 'yes':
                accepted.add(key)
                captures[key] = lic.observe_capture()
        allowed = {model for model in selected
                   if requirements[model] <= accepted and model not in failures}
        # A model whose terms could not be read was not declined; it stays pending.
        declined = set(selected) - allowed - set(failures)
        # No receipt is minted until every group has been answered; interrupted
        # batches remain pending and can be reviewed again without downloads.
        from kilix_content.receipt import catalog_sha256, release_digest
        for model in allowed & specs.keys():
            spec = specs[model]
            for item in spec.licenses:
                record = cm._record(records, item.record_digest)
                key = item.license_id
                if (model, record.digest) not in required_receipts: continue
                if (model, record.digest) in policy_records:
                    agreement = lic.capture_standard_policy(record)
                else:
                    if key not in captures: continue
                    agreement = lic.capture_agreement(record,
                        'yes' if record.expected_decision == 'accept' else None,
                        acceptance=captures[key])
                store.write(lic.receipt_from_agreement(record, agreement,
                    manifest_digest=spec.manifest_digest, release_digest=release_digest(),
                    catalogue_digest=catalog_sha256()))
        if allowed & set(llm_ids):
            for model in allowed & set(llm_ids):
                if not requirements[model]:
                    continue
                saved[model] = {'manifest_sha256': system_llm.MODELS[model][3],
                    'groups': [{'licence': key, 'text_sha256': [hashlib.sha256(text).hexdigest()
                               for text in groups[key]['texts'].values()],
                                'captured_at': captures[key].captured_at,
                                'capture_mode': captures[key].capture_mode}
                               for key in requirements[model]]}
            atomic_json(llm_licenses_path, saved)
        if before_install is not None:
            before_install(set(allowed))
        from kilix_sdk._content_runtime import apps_root
        installer = api.Installer(apps_root())
        from wizard_converters import prepare_converters
        prepare_converters(api, installer, [specs[model] for model in selected
                                           if model in allowed and model in specs], input_fn=input_fn)
        installed = set()
        for model in selected:
            if model not in allowed: continue
            print('\nInstalling ' + model + '…', flush=True)
            try:
                if model in specs:
                    installer.ensure_upstream_asset(specs[model], store=store, records=records,
                        notices=texts, report=lambda message: print(message, flush=True))
                else:
                    # The current or saved licence-group Yes also covers the download.
                    system_llm.acquire(model, consented=True)
            except Exception as error:
                failures[model] = error
                # Say why now: the setup terminal may stop at a later question.
                from model_wizard import error_detail
                print(f'Could not install {model}: {error_detail(error)}', flush=True)
                print('Continuing with the other accepted models.', flush=True)
            else:
                installed.add(model)
                print(f'Installed {model}.', flush=True)
        if failures:
            raise InstallFailures(installed, declined, failures) from next(iter(failures.values()))
    return installed, declined
