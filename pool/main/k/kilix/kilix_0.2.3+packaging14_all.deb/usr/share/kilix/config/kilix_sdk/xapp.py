"""Private X11 application sessions for Kilix providers.

The host owns process supervision, display authentication, capture fallback,
and input cleanup.  Providers own presentation and any desktop-specific window
management layered on top of the private display.
"""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
import os
import re
import select
import shlex
import shutil
import stat
import sys
import tempfile
import time
from threading import Lock, RLock, get_ident
from pathlib import Path
import subprocess
from typing import Iterable, Mapping

import stream
import xcapture
import xinject
from Xlib import display as xdisplay
from .browser_portals import prepare_browser
from .mpv_inhibit import prepare_player
from .private_bus import PrivateBus
from .launch_transport import literal_launch
from .clipboard import _XAUTHORITY_LOCK
from . import capture_registry


_PROCESS_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")


@contextmanager
def _temporary_xauthority(path: str):
    """Scope python-xlib's process-global XAUTHORITY lookup to one connect."""
    if not path:
        raise RuntimeError("private X display has no authority file")
    with _XAUTHORITY_LOCK:
        marker = object()
        previous = os.environ.get("XAUTHORITY", marker)
        os.environ["XAUTHORITY"] = path
        try:
            yield
        finally:
            if previous is marker:
                os.environ.pop("XAUTHORITY", None)
            else:
                os.environ["XAUTHORITY"] = previous


def _positive(value: int | None, fallback: int, label: str) -> int:
    selected = fallback if value is None else int(value)
    if selected <= 0:
        raise ValueError(f"{label} must be positive")
    return selected


class SessionCleanupError(RuntimeError):
    """Independent cleanup failures, with the session retained for retry."""
    def __init__(self, failures, session=None):
        self.failures = dict(failures)
        self.session = session
        super().__init__("X app cleanup incomplete: " + "; ".join(
            f"{name}: {error}" for name, error in self.failures.items()))


def _stop_process(process, timeout: float = 2.0) -> None:
    if process is None:
        return
    errors = {}
    if getattr(process, "_kilix_unpinned_gated", False):
        retry = getattr(process, "_kilix_pin_retry", None)
        if retry is None:
            raise SessionCleanupError({"process": "gated primary has no immutable identity"})
        process = retry()  # Same retained socket; never reopen a numeric PID.
    try:
        if process.poll() is None:
            try:
                process.terminate()
                process.wait(timeout=timeout)
            except Exception as term_error:
                try:
                    process.kill()
                    process.wait(timeout=1)
                except Exception as kill_error:
                    errors["process"] = RuntimeError(f"{term_error}; {kill_error}")
        if process.poll() is None:
            errors["process"] = RuntimeError("owned process has no exit evidence")
    except Exception as error:
        errors["process"] = error
    for name in ("stdin", "stdout", "stderr"):
        handle = getattr(process, name, None)
        if handle is not None and not getattr(handle, "closed", False):
            try:
                handle.close()
            except Exception as error:
                errors[name] = error
    if errors:
        raise SessionCleanupError(errors)


@dataclass(frozen=True)
class CaptureStart:
    """Result of selecting a private-display capture backend."""

    backend: str
    initial_frame: bytes | None = None
    damage_error: Exception | None = None


def _open_private_log(path: Path):
    """Append to an owner-only log; never follow a link or widen it first."""
    try:
        # O_NONBLOCK: a FIFO planted at the path must not block the open.
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND | os.O_NOFOLLOW
                     | os.O_CLOEXEC | os.O_NONBLOCK, 0o600)
    except OSError:
        return None  # A substituted log only costs the diagnostics.
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            os.close(fd)  # A FIFO or device is never a log.
            return None
        os.set_blocking(fd, True)  # The child inherits it as stderr.
        os.fchmod(fd, 0o600)  # A log left by an older version keeps no group access.
        return os.fdopen(fd, "ab")
    except OSError:
        os.close(fd)
        return None


class XAppSession:
    """Own one authenticated private X server and its application processes."""

    def __init__(self, session: str, width: int, height: int, fps: int = 30,
                 *, supervisor=None):
        width, height, fps = int(width), int(height), int(fps)
        if width <= 0 or height <= 0:
            raise ValueError("X app dimensions must be positive")
        if fps <= 0:
            raise ValueError("X app capture rate must be positive")
        self.session = session
        self.width = width
        self.height = height
        self.fps = fps
        self.supervisor = supervisor or stream.StreamSupervisor(session)
        self.number = None
        self.display = None
        self.server = None
        self.xd = None
        self.app = None
        self._app_bus = None
        self.window_manager = None
        self.clipboard_process = None
        self.injector = None
        self.dnd_bridge = None
        self._dnd_starting = False
        self.capture = None
        self.capture_process = None
        self.capture_backend = "pending"
        self._capture_seq = 0
        self._closed = False
        self._closing = False
        self._cleanup_done = set()
        self._cleanup_lock = RLock()
        self._cleanup_active = None
        self._cleanup_steps = set()
        self._supervisor_pending = []
        self._local_capture_source = False
        self._capture_publication = None

    def _require_open(self):
        if self._closing or self._closed:
            raise RuntimeError("X app session is closing")

    @property
    def xauthority(self) -> str | None:
        return self.supervisor.xauth

    def _select_number(self, number: int | None) -> int:
        if self.number is not None:
            raise RuntimeError("private X display is already started")
        selected = (
            self.supervisor.pick_display() if number is None else int(number))
        if not 0 <= selected <= 65535:
            raise ValueError("X display number must be between 0 and 65535")
        return selected

    def start_xvfb(self, *, width: int | None = None,
                   height: int | None = None, nocursor: bool = False,
                   number: int | None = None) -> int:
        self._require_open()
        selected_width = _positive(width, self.width, "X app width")
        selected_height = _positive(height, self.height, "X app height")
        number = self._select_number(number)
        self.server = self.supervisor.start_xvfb(
            number, selected_width, selected_height,
            nocursor=nocursor)
        self.number, self.display = number, f":{number}"
        self._local_capture_source = True
        return number

    def start_xvnc(self, port: int, password_file: str, *,
                   desktop: str = "kilix", width: int | None = None,
                   height: int | None = None,
                   number: int | None = None) -> int:
        self._require_open()
        selected_width = _positive(width, self.width, "X app width")
        selected_height = _positive(height, self.height, "X app height")
        port = int(port)
        if not 1 <= port <= 65535:
            raise ValueError("VNC port must be between 1 and 65535")
        number = self._select_number(number)
        self.server = self.supervisor.start_xvnc(
            number, selected_width, selected_height, port,
            password_file, desktop=desktop)
        self.number, self.display = number, f":{number}"
        return number

    def environment(self, extra: Mapping[str, str] | None = None) -> dict[str, str]:
        if self.display is None or not self.xauthority:
            raise RuntimeError("private X display has not started")
        env = dict(os.environ)
        if extra:
            env.update(extra)
        # The application/capture always belongs to this private display;
        # provider-supplied environment cannot redirect either X client.
        env["DISPLAY"] = self.display
        env["XAUTHORITY"] = self.xauthority
        # These describe the containing terminal, not the app's private X
        # desktop. Inheriting them can route children back to the host or
        # recursively create another streamed desktop.
        for key in ("WAYLAND_DISPLAY", "WAYLAND_SOCKET", "KITTY_WINDOW_ID",
                    "KITTY_LISTEN_ON", "KITTY_PID", "KILIX_IN_OVERLAY",
                    "KILIX_RC_PASSWORD_FILE", "KILIX_STREAM", "SESSION_MANAGER"):
            env.pop(key, None)
        env.update(GDK_BACKEND="x11", QT_QPA_PLATFORM="xcb",
                   SDL_VIDEODRIVER="x11", MOZ_ENABLE_WAYLAND="0",
                   KILIX_PRIVATE_XAPP="1", KILIX_RUN_ALIASES="0")
        return env

    def connect(self):
        self._require_open()
        if self.xd is None:
            if self.display is None or not self.xauthority:
                raise RuntimeError("private X display has not started")
            with _temporary_xauthority(self.xauthority):
                self.xd = xdisplay.Display(self.display)
        return self.xd

    def start_window_manager(self, *, timeout: float = 5.0) -> bool:
        """Run bare Openbox on this owned display, never openbox-session.

        A normal app fills the pane; dialogs, menus and focus remain the WM's
        responsibility. Explicit desktop sessions must not call this method.
        """
        self._require_open()
        if self.window_manager is not None:
            return True
        mode = os.environ.get("KILIX_RUN_WM", "auto")
        if mode == "none":
            return False
        if mode not in {"auto", "openbox"}:
            raise RuntimeError("KILIX_RUN_WM must be auto, openbox, or none")
        executable = shutil.which("openbox")
        if executable is None:
            if mode == "openbox":
                raise RuntimeError("kilix run needs Openbox: install openbox")
            return False
        xd = self.connect()
        root = xd.screen().root
        wm_check = xd.intern_atom("_NET_SUPPORTING_WM_CHECK")
        profile = Path(__file__).resolve().parents[1] / "openbox-pane.xml"
        # Openbox advertises _NET_SUPPORTING_WM_CHECK before installing its
        # event handlers. Mapping an app at that point can lose its MapRequest
        # and leave it invisible forever. --startup runs after WM setup, so
        # wait for that callback as well as the X11 ownership property.
        with tempfile.TemporaryDirectory(prefix="kilix-openbox-ready-") as ready_dir:
            ready = Path(ready_dir) / "ready"
            startup = shlex.join([
                sys.executable, "-c",
                "from pathlib import Path; import sys; Path(sys.argv[1]).touch()",
                str(ready),
            ])
            self.window_manager = self.supervisor.spawn(
                "wm", [executable, "--config-file", str(profile), "--sm-disable",
                       "--startup", startup],
                env=self.environment(), stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL)
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                if self.window_manager.poll() is not None:
                    raise RuntimeError("pane Openbox exited before becoming ready")
                prop = root.get_full_property(wm_check, 0)
                if ready.is_file() and prop is not None and len(prop.value):
                    return True
                time.sleep(0.02)
        raise RuntimeError("pane Openbox did not become ready")

    def launch_app(self, command: Iterable[str], *,
                   env: Mapping[str, str] | None = None,
                   cwd: str | None = None,
                   isolate_bus: bool = False,
                   clipboard: bool = True,
                   capture_source: bool = True,
                   capture_label: str | None = None,
                   stdout=subprocess.DEVNULL,
                   stderr=subprocess.DEVNULL):
        self._require_open()
        if self.app is not None:
            raise RuntimeError("private X application is already running")
        argv = list(command)
        if not argv:
            raise ValueError("X app command must not be empty")
        label = capture_label or os.path.basename(argv[0])
        app_env = self.environment(env)
        if isolate_bus:
            # GtkApplication and other singleton apps otherwise ask the
            # host's existing process to open a native window over Kilix.
            runner = shutil.which("dbus-daemon")
            if runner is None:
                raise RuntimeError("pane apps need dbus-daemon")
            host_bus = (app_env.get("PLEB_DESKTOP_BUS_ADDRESS") or
                        app_env.get("KILIX_PORTAL_HOST_BUS") or
                        app_env.get("DBUS_SESSION_BUS_ADDRESS"))
            app_env.pop("DBUS_SESSION_BUS_ADDRESS", None)
            app_env.pop("DBUS_SESSION_BUS_PID", None)
            if host_bus:
                app_env["KILIX_PORTAL_HOST_BUS"] = host_bus
                app_env.setdefault("GTK_USE_PORTAL", "1")
                argv, app_env = prepare_browser(argv, app_env)
                argv = prepare_player(argv, app_env)
                bridge = Path(__file__).with_name("portal_bridge.py")
                argv = [sys.executable, str(bridge), "--wrap", "--", *argv]
            # The bus owner also crosses the Unicode-only supervisor boundary.
            # Keep the original environment until the private-bus policy has
            # removed inherited variables and supplied its own address.
            _, owner_env, _ = literal_launch(argv, app_env, cwd)
            try:
                self._app_bus = PrivateBus(self.supervisor, owner_env)
            except BaseException as error:
                retained = getattr(error, "resource", None)
                if isinstance(retained, PrivateBus):
                    self._app_bus = retained
                raise
            app_env = self._app_bus.environment(app_env)
        try:
            if self._app_bus is not None:
                # Restore only the finalized environment in the unprivileged
                # primary, after the supervisor's checks and credential drop.
                argv, app_env, cwd = literal_launch(argv, app_env, cwd)
            if clipboard:
                self.start_clipboard()
            self.app = self.supervisor.spawn(
                "app", argv, env=app_env, cwd=cwd,
                _kilix_remote_launcher=self._app_bus.launch_primary if self._app_bus is not None else None,
                stdout=stdout, stderr=stderr)
            if self._app_bus is not None:
                self._app_bus.bind(self.app)
        except BaseException as launch_error:
            if self._app_bus is not None:
                try:
                    self._app_bus.close()
                except BaseException as cleanup_error:
                    launch_error.resource = self._app_bus
                    launch_error.cleanup_errors = (cleanup_error,)
            raise
        if self._local_capture_source and capture_source:
            self._capture_publication = capture_registry.publish(self, label)
        return self.app

    def start_clipboard(self, *, timeout: float = 3.0) -> bool:
        """Mirror ordinary clipboard data to the containing desktop display.

        Providers supplying their own rich hub pass clipboard=False at launch.
        Clipboard failure is logged and never prevents opening an application.
        """
        self._require_open()
        if self.clipboard_process is not None:
            return self.clipboard_process.poll() is None
        if os.environ.get("KILIX_HOST_CLIP", "1") == "0":
            return False
        host = (os.environ.get("PLEB_DESKTOP_DISPLAY") or
                os.environ.get("KILIX_CLIPBOARD_HOST_DISPLAY") or
                os.environ.get("DISPLAY"))
        if not host or host == self.display or self.display is None:
            return False
        authority = (os.environ.get("PLEB_DESKTOP_XAUTHORITY") or
                     os.environ.get("KILIX_CLIPBOARD_HOST_XAUTHORITY") or
                     os.environ.get("XAUTHORITY"))
        read_fd, write_fd = os.pipe()
        process = None
        log = None
        try:
            runtime_dir = getattr(self.supervisor, "runtime_dir", None)
            if runtime_dir:
                log = _open_private_log(Path(runtime_dir) / "clipboard.log")
            argv = [sys.executable, str(Path(__file__).with_name("clipboard.py")),
                    "--host-display", host, "--private-display", self.display,
                    "--private-authority", self.xauthority,
                    "--parent-pid", str(os.getpid()), "--ready-fd", str(write_fd)]
            if authority:
                argv.extend(["--host-authority", authority])
            process = self.supervisor.spawn(
                "clipboard", argv, env=dict(os.environ), pass_fds=(write_fd,),
                stdout=subprocess.DEVNULL, stderr=log or subprocess.DEVNULL)
            os.close(write_fd)
            write_fd = None
            ready, _, _ = select.select([read_fd], [], [], timeout)
            if not ready or os.read(read_fd, 1) != b"1":
                _stop_process(process)
                return False
            self.clipboard_process = process
            return True
        except (OSError, ValueError):
            _stop_process(process)
            return False
        finally:
            if log is not None:
                log.close()
            os.close(read_fd)
            if write_fd is not None:
                os.close(write_fd)

    def make_injector(self, *, width: int | None = None,
                      height: int | None = None):
        self._require_open()
        if self.injector is None:
            selected_width = _positive(width, self.width, "X app width")
            selected_height = _positive(height, self.height, "X app height")
            self.injector = xinject.Injector(
                self.connect(), selected_width, selected_height)
        return self.injector

    def set_geometry(self, width: int, height: int) -> None:
        width, height = int(width), int(height)
        if width <= 0 or height <= 0:
            raise ValueError("X app dimensions must be positive")
        self.width, self.height = width, height
        if self.injector is not None:
            self.injector.app_w, self.injector.app_h = self.width, self.height

    def make_dnd_bridge(self, write, image_box, *, diagnostic=None):
        """Connect this pane's terminal drag protocol to native private XDND."""
        self._require_open()
        if self.dnd_bridge is None:
            if self._dnd_starting:
                raise RuntimeError("XDND bridge startup is already in progress")
            from .xdnd import NativeDndBridge
            self._dnd_starting = True
            try:
                bridge = NativeDndBridge(self.display, self.xauthority,
                    write, image_box, self.make_injector(), diagnostic=diagnostic)
            finally:
                self._dnd_starting = False
            # Public callbacks can close or replace the session during startup.
            if self._closed or self._closing or self.dnd_bridge is not None:
                bridge.close()
                if self._closed or self._closing:
                    raise RuntimeError("X app session closed during XDND startup")
            else:
                self.dnd_bridge = bridge
        return self.dnd_bridge

    def start_capture(self, *, fps: int | None = None,
                      draw_cursor: bool = True, prefer_damage: bool = True,
                      capture_name: str = "cap") -> CaptureStart:
        """Use XDamage/MIT-SHM when available, otherwise supervised ffmpeg."""
        self._require_open()
        if self.display is None or not self.xauthority:
            raise RuntimeError("private X display has not started")
        rate = _positive(fps, self.fps, "X app capture rate")
        if not isinstance(capture_name, str) or not _PROCESS_NAME.fullmatch(
                capture_name):
            raise ValueError("capture name must be a short, plain process name")
        self.stop_capture()
        damage_error = None
        if prefer_damage and os.environ.get("KILIX_XDAMAGE_CAPTURE", "1") != "0":
            candidate = None
            try:
                # python-xlib resolves XAUTHORITY from the process environment.
                # Keep both the connection and its first request scoped to the
                # private display's cookie without leaking it to the host.
                with _temporary_xauthority(self.xauthority):
                    candidate = xcapture.XDamageCapture(
                        self.display, self.width, self.height,
                        draw_cursor=draw_cursor)
                    initial = candidate.snapshot()
            except Exception as error:
                damage_error = error
                if candidate is not None:
                    try:
                        candidate.close()
                    except Exception:
                        pass
            else:
                self.capture = candidate
                self.capture_backend = "xdamage+mit-shm"
                return CaptureStart(self.capture_backend, initial)

        self._capture_seq += 1
        name = capture_name if self._capture_seq == 1 else f"{capture_name}-{self._capture_seq}"
        argv = [
            "ffmpeg", "-loglevel", "quiet", "-f", "x11grab",
            "-draw_mouse", "1" if draw_cursor else "0",
            "-framerate", str(rate), "-video_size",
            f"{self.width}x{self.height}", "-i", self.display,
            "-f", "rawvideo", "-pix_fmt", "rgb24", "-",
        ]
        process = self.supervisor.spawn(
            name, argv, env=self.environment(), stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL)
        self.capture_process = process
        try:
            if process.stdout is None:
                raise RuntimeError("capture process has no stdout pipe")
            os.set_blocking(process.stdout.fileno(), False)
        except Exception:
            self.capture_process = None
            _stop_process(process)
            self.capture_backend = "stopped"
            raise
        self.capture_backend = f"ffmpeg@{rate}"
        return CaptureStart(self.capture_backend, damage_error=damage_error)

    def stop_capture(self) -> None:
        failures = {}
        if self.capture is not None:
            try:
                self.capture.close()
                self.capture = None
            except Exception as error:
                failures["capture"] = error
        if self.capture_process is not None:
            try:
                _stop_process(self.capture_process)
                self.capture_process = None
            except Exception as error:
                failures["capture-process"] = error
        self.capture_backend = "cleanup-incomplete" if failures else "stopped"
        if failures:
            raise SessionCleanupError(failures, self)

    def release_input(self) -> None:
        if self.injector is not None:
            self.injector.release_all()

    def _cleanup_supervisor(self) -> None:
        # StreamSupervisor's existing best-effort cleanup can clear its direct
        # Popen list even when wait failed. Preserve those exact handles here;
        # they are neither a process-tree census nor authority over other apps.
        for _name, process, handles, _path in getattr(self.supervisor, "children", ()):
            if not any(process is p for p, _h in self._supervisor_pending):
                self._supervisor_pending.append((process, tuple(handles)))
        failures = {}
        try:
            self.supervisor.cleanup()
        except Exception as error:
            failures["supervisor"] = error
        for process, handles in list(self._supervisor_pending):
            errors = []
            try:
                _stop_process(process)
            except Exception as error:
                errors.append(error)
            for handle in handles:
                if not getattr(handle, "closed", False):
                    try:
                        handle.close()
                    except Exception as error:
                        errors.append(error)
            if errors:
                failures[f"owned-process-{id(process)}"] = RuntimeError("; ".join(map(str, errors)))
            else:
                self._supervisor_pending.remove((process, handles))
        if failures:
            raise SessionCleanupError(failures, self)

    def close(self) -> dict | None:
        """Finish cleanup, or expose pending reentry without claiming closure."""
        caller = get_ident()
        attempt = (caller, Lock())
        try:
            with attempt[1]:
                with self._cleanup_lock:
                    active = self._cleanup_active
                    if (isinstance(active, tuple) and len(active) == 2 and
                        type(active[1]) is type(attempt[1]) and not active[1].locked()):
                        self._cleanup_active = None
                    if self._closed:
                        return
                    active = self._cleanup_active
                    if self._cleanup_active is not None:
                        live = (not isinstance(active, tuple) or len(active) != 2 or
                                type(active[1]) is not type(attempt[1]) or active[1].locked())
                        if live:
                            active_caller = active[0] if isinstance(active, tuple) else active
                            if active_caller == caller:
                                return {"state": "incomplete", "pending": tuple(self._cleanup_steps)}
                            raise SessionCleanupError({"cleanup-in-progress": RuntimeError("another cleanup attempt is active")}, self)
                    self._cleanup_active = attempt
                    self._closing = True
                return self._close_resources()
        finally:
            with self._cleanup_lock:
                if self._cleanup_active is attempt:
                    self._cleanup_active = None

    def _close_resources(self):
        failures = {}
        def resource(name, attribute):
            if name in self._cleanup_done:
                return
            value = getattr(self, attribute)
            self._cleanup_steps.add(name)
            try:
                if value is not None:
                    result = value.close()
                    if isinstance(result, dict) and result.get("state") == "incomplete":
                        raise RuntimeError("cleanup resource is still in progress")
                if getattr(self, attribute) is not value:
                    raise RuntimeError("cleanup resource changed during its callback")
                setattr(self, attribute, None)
                self._cleanup_done.add(name)
            except Exception as error:
                failures[name] = error
            finally:
                self._cleanup_steps.discard(name)
        def action(name, callback):
            if name in self._cleanup_done:
                return
            self._cleanup_steps.add(name)
            try:
                callback()
                self._cleanup_done.add(name)
            except Exception as error:
                failures[name] = error
            finally:
                self._cleanup_steps.discard(name)
        resource("XDND", "dnd_bridge")
        resource("bus", "_app_bus")
        resource("publication", "_capture_publication")
        action("input", self.release_input)
        action("capture", self.stop_capture)
        def clipboard():
            _stop_process(self.clipboard_process)
            self.clipboard_process = None
        action("clipboard", clipboard)
        resource("X-connection", "xd")
        action("supervisor", self._cleanup_supervisor)
        if failures:
            raise SessionCleanupError(failures, self)
        self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, _kind, _value, _traceback):
        self.close()


__all__ = ["CaptureStart", "SessionCleanupError", "XAppSession"]
