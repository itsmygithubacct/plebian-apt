#!/usr/bin/env python3
"""Generate packaged asset/v3 records from verified upstream pins (R4-050..R4-065)."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PIN_DIR = ROOT / "tools" / "upstream-pins"
CATALOG = ROOT / "src" / "kilix_content" / "catalog" / "plebian.json"
RECEIPT = ROOT / "src" / "kilix_content" / "receipt.py"
SCHEMA = ROOT / "src" / "kilix_content" / "contracts" / "kilix.content.asset-v3.schema.json"
LICENSE_SRC = ROOT / "third_party" / "kilix-license" / "src"
TEXTS = LICENSE_SRC / "kilix_license" / "data" / "texts"

PIN_NAMES = (
    "needle3-kilix-commands.json",
    "lfm2-kilix-commands.json",
    "lfm3-kilix-commands.json",
    'kilix-diarization-cpu.json',
    "whistle.json",
    "vosk-model-small-en-us-0.15.json",
    "vosk-model-en-us-0.22-lgraph.json",
    "qwen3-tts-0.6b-base.json",
    "qwen3-tts-0.6b-customvoice.json",
    "qwen3-tts-1.7b-voicedesign.json",
    "whisper-tiny-ggml.json",
    # Owner determination 2026-09-29: the default Kilix dictation model on
    # capable hardware, run by kilix-whisper-stt (faster-whisper).
    "faster-whisper-small-en.json",
    # Owner determination 2026-11-07: Whisper medium English, a second
    # dictation model with its own record and small.en's MIT terms.
    "faster-whisper-medium-en.json",
    "piper-en-us-kristin-medium.json",
    "kilix-female-02.json",
    "paradee-8m-v1.2.json",
    # Owner decision 2026-11-10: Paradee's offline front end. The wheel is
    # MIT; LICENSES_SOURCES ships as a statement, not a binding condition.
    "en-core-web-sm-3.8.0.json",
    # Owner direction 2026-11-09: an option for kilix avatar and kilix chat,
    # loaded through kilix-llm, from the kilix-llm release.
    "qwen-0.8b-no-loop-02.json",
    "vibevoice-asr-bitnet.json",
    "yolox_s.json",
    "yolox_tiny.json",
    "yolox_nano.json",
    "yamnet.json",
    "bonsai-8b.json",
    "bonsai-27b.json",
    "bitnet-b1.58-2b4t.json",
    "granite4.1-3b.json",
    "nomic-embed-text-v1.5.json",
    "granite3.2-vision-2b.json",
    "qwen3.5-4b.json",
    "pocket-tts-english-q8_0.json",
    "pocket-tts-english-python-alba.json",
    "bonsai-image-4b-ternary-gemlite.json",
    "bonsai-image-4b-binary-gemlite.json",
    # OD-AY: the kilix-pdf-conversion [granite] engine models, and only those.
    "granite-docling-258m.json",
    "documentfigureclassifier-v2.5.json",
    "granite-vision-4.1-4b.json",
    # Owner determination 2026-11-10, which widens OD-AY from three PDF models
    # to five: "go with Apache-2.0, note the reality. 2: go with 5. ship them
    # with the image if they are small." kilix-pdf-conversion page OCR's
    # PP-OCRv6 small detector and recogniser, shipped in the Plebian-OS image.
    "pp-ocrv6-small-det.json",
    "pp-ocrv6-small-rec.json",
    # OD-AR: both EnCodec checkpoints, downloaded from upstream on first use
    # under CC BY-NC 4.0 and converted locally (R4-068).
    "encodec-24khz-stateful.json",
    "encodec-48khz-frame.json",
    # Owner direction 2026-09-22: the kilix-needle engine, an application
    # record in kilix-license's determinations-apps.json. Not a release model.
    "needle2.json",
    # Owner direction 2026-09-22, round 2: the runtime library that loads a
    # fine-tuned model, and the checkpoint and tokenizer fine-tuning starts from.
    "needle2-runtime.json",
    "needle2-train.json",
    "basic-pitch-icassp-2022-onnx.json",
    # Owner request 2026-11-08: route kilix split through kilix-license. Meta's
    # htdemucs_6s weights under the Demucs MIT licence, in a family of its own.
    "demucs-htdemucs-6s.json",
    # Owner determination 2026-11-08: Whisper large-v3 for Kilix Playalong
    # lyrics in any language, installed only after a yes; medium.en's terms.
    "faster-whisper-large-v3.json",
)

LICENSORS = {
    "basic-pitch-icassp-2022-onnx": ["Spotify AB"],
    "demucs-htdemucs-6s": ["Meta Platforms, Inc. and affiliates"],
    "needle3-kilix-commands": ["Cactus Compute, Inc.", "needle-rs contributors"],
    "lfm3-kilix-commands": ["Liquid AI, Inc.", "ggml and bundled runtime contributors"],
    "lfm2-kilix-commands": ["Liquid AI, Inc.", "ggml and bundled runtime contributors"],
    'kilix-diarization-cpu':['IIC / Alibaba Cloud','pyannote contributors','sherpa-onnx and bundled runtime contributors'],
    "whistle": ["Cactus Compute, Inc."],
    "small-en-us": ["Alpha Cephei Inc."],
    "lgraph-en-us": ["Appen", "Alpha Cephei"],
    "qwen3-tts-0.6b-base": ["Alibaba Cloud"],
    "qwen3-tts-0.6b-customvoice": ["Alibaba Cloud"],
    "qwen3-tts-1.7b-voicedesign": ["Alibaba Cloud"],
    "whisper-tiny-ggml": ["OpenAI"],
    "faster-whisper-small-en": ["OpenAI", "SYSTRAN"],
    "faster-whisper-medium-en": ["OpenAI", "SYSTRAN"],
    "faster-whisper-large-v3": ["OpenAI", "SYSTRAN"],
    "piper-en-us-kristin-medium": ["Bryce Beattie"],
    "kilix-female-02": ["itsmygithubacct"],
    "paradee-8m-v1.2": ["Sahil Mahendrakar"],
    "en-core-web-sm-3.8.0": ["ExplosionAI GmbH"],
    "qwen-0.8b-no-loop-02": ["Alibaba Cloud / Qwen"],
    "vibevoice-asr-bitnet": ["Microsoft Corporation"],
    "yolox_s": ["Megvii (Base Detection / Megvii Inc.)"],
    "yolox_tiny": ["Megvii (Base Detection / Megvii Inc.)"],
    "yolox_nano": ["Megvii (Base Detection / Megvii Inc.)"],
    "yamnet": ["Google"],
    "bonsai-8b": ["Prism ML, Inc."],
    "bonsai-27b": ["Prism ML, Inc."],
    "bitnet-b1.58-2b4t": ["Microsoft Corporation"],
    "granite4.1:3b": ["IBM"],
    "nomic-embed-text:v1.5": ["Nomic AI"],
    "granite3.2-vision:2b": ["IBM"],
    "qwen3.5:4b": ["Alibaba Cloud / Qwen"],
    "pocket-tts-english-q8_0": ["Kyutai"],
    "pocket-tts-english-python-alba": ["Kyutai"],
    "bonsai-image-4b:ternary-gemlite": ["Prism ML, Inc."],
    "bonsai-image-4b:binary-gemlite": ["Prism ML, Inc."],
    "granite-docling-258m": ["IBM"],
    "documentfigureclassifier-v2.5": ["docling-project"],
    "granite-vision-4.1-4b": ["IBM"],
    "pp-ocrv6-small-det": ["PaddlePaddle"],
    "pp-ocrv6-small-rec": ["PaddlePaddle"],
    "encodec-24khz-stateful": ["Meta Platforms"],
    "encodec-48khz-frame": ["Meta Platforms"],
    "needle2": ["Cactus Compute, Inc."],
    "needle2-runtime": ["Cactus Compute, Inc."],
    "needle2-train": ["Cactus Compute, Inc."],
}

LICENSE_ROW_IDS = {
    "LFM-Open-License-1.0": "lfm-open-license-1.0",
    "Apache-2.0": "apache-2.0",
    "MIT": "mit",
    "Public domain, per the trainer's statement": "public-domain",
    "CC-BY-4.0": "cc-by-4.0",
    # OD-AR: both EnCodec checkpoints, licensor Meta Platforms.
    "CC BY-NC 4.0": "cc-by-nc-4.0",
}

NOTICE_PATHS = {
    "lfm-open-license-1.0": "notices/LICENSE-LFM.txt",
    "apache-2.0": "notices/LICENSE-apache-2.0.txt",
    "mit": "notices/LICENSE-mit.txt",
    "public-domain": "notices/public-domain.txt",
    "cc-by-4.0": "notices/LICENSE-cc-by-4.0.txt",
    "cc-by-nc-4.0": "notices/LICENSE-cc-by-nc-4.0.txt",
    "llama-3-community": "notices/LICENSE-llama-3-community.txt",
}

# Component exceptions that are shown as a second licence row (OD-AB).
COMPONENT_LICENSE_ROWS = {
    "qwen2.5-1.5b-decoder-lineage": {
        "decision": "affirmative",
        "license_id": "apache-2.0",
        "licensors": ["Alibaba Cloud"],
        "notice_path": "notices/LICENSE-apache-2.0.txt",
    },
    "tokenizer-derived-from-llama-3": {
        "decision": "affirmative",
        "license_id": "llama-3-community",
        "licensors": ["Meta Platforms, Inc."],
        "notice_path": "notices/LICENSE-llama-3-community.txt",
    },
    # qwen-0.8b-no-loop-02: the weight edit is adapted from CC BY 4.0 material.
    # The owner approved this component on 2026-11-09 (kilix-license
    # determinations-noloop02.json, owner_determination). The row is affirmative.
    "weight-edit-from-lm-understand-logs": {
        "decision": "affirmative",
        "license_id": "cc-by-4.0",
        "licensors": ['the authors of "LLMs can understand and write neural network weights"'],
        "notice_path": "notices/LICENSE-cc-by-4.0.txt",
    },
}

# qwen-0.8b-no-loop-02's modification notice, CC BY attribution and the edit
# source's own licence file, at the names those notices refer to.
NOLOOP02_STATEMENT_PATHS = {
    "modified-model": "notices/modified-model.txt",
    "weight-edit-attribution": "notices/weight-edit-attribution.txt",
    "weight-edit-source-licence": "notices/LICENSE-lm_understand-logs.txt",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    digest.update(path.read_bytes())
    return digest.hexdigest()


def load_license(record_id: str):
    sys.path.insert(0, str(LICENSE_SRC))
    from kilix_license.catalog import load_determined_records

    return load_determined_records().by_id(record_id)


def license_row_id(record) -> str:
    if not record.licence_ids:
        raise SystemExit(f"{record.id} has no licence_ids")
    try:
        return LICENSE_ROW_IDS[record.licence_ids[0]]
    except KeyError as exc:
        raise SystemExit(f"{record.id} has unsupported licence {record.licence_ids[0]!r}") from exc


def notice_blob(digest: str, path: str, label: str) -> dict[str, object]:
    data = (TEXTS / digest).read_bytes()
    if hashlib.sha256(data).hexdigest() != digest:
        raise SystemExit(f"notice text digest mismatch for {label}")
    return {"bytes": len(data), "path": path, "sha256": digest}


def notice_file(record) -> dict[str, object]:
    return notice_blob(
        record.text_sha256, NOTICE_PATHS[license_row_id(record)], record.id
    )


def notice_files(record) -> list[dict[str, object]]:
    files = [notice_file(record)]
    if record.id == 'en-core-web-sm-3.8.0':
        sources = next(item for item in record.statements if item.id == 'training-sources')
        files.append(notice_blob(sources.text_sha256, 'notices/LICENSES_SOURCES.txt', record.id))
    if record.id == "basic-pitch-icassp-2022-onnx":
        notice = next(s for s in record.statements if s.id == "upstream-notice")
        files.append(notice_blob(notice.text_sha256, "notices/NOTICE-basic-pitch.txt", record.id))
        return files
    if record.id == 'needle3-kilix-commands':
        runtime = next(x for x in record.components if x.id == 'cached-runtime')
        files.append(notice_blob(runtime.exception_text_sha256, 'notices/LICENSE-runtime.txt', record.id))
        for statement in record.statements:
            files.append(notice_blob(statement.text_sha256, 'notices/' + statement.id + '.txt', record.id))
        return files
    if record.id in ('lfm2-kilix-commands', 'lfm3-kilix-commands'):
        runtime = next(x for x in record.components if x.id == 'native-runtime')
        changed = next(x for x in record.statements if x.id == ('upstream-model' if record.id == 'lfm3-kilix-commands' else 'modified-model'))
        files.append(notice_blob(runtime.exception_text_sha256, 'notices/LICENSE-runtime.txt', record.id))
        files.append(notice_blob(changed.text_sha256, 'notices/NOTICE.txt', record.id))
        return files
    if record.id == 'kilix-diarization-cpu':
        for item in record.components:
            if item.exception_text_sha256:
                files.append(notice_blob(item.exception_text_sha256,'notices/'+item.id+'.txt',record.id))
        determination = json.loads((TEXTS.parent/'determinations-diarization.json').read_text())
        files.append(notice_blob(determination['authority']['native_software_notice_sha256'],
                                'notices/native-runtime.txt',record.id))
        for item in record.statements:
            files.append(notice_blob(item.text_sha256,'notices/'+item.id+'.txt',record.id))
        return files
    if record.id == 'qwen-0.8b-no-loop-02':
        for statement in record.statements:
            files.append(notice_blob(statement.text_sha256, NOLOOP02_STATEMENT_PATHS[statement.id], record.id))
    for component in record.components:
        extra = COMPONENT_LICENSE_ROWS.get(component.id)
        if extra is None:
            continue
        if component.exception_text_sha256 is None:
            raise SystemExit(f"{record.id} component {component.id} has no text")
        files.append(
            notice_blob(
                component.exception_text_sha256,
                extra["notice_path"],
                f"{record.id}:{component.id}",
            )
        )
    return files


def license_rows(pin: dict, record) -> list[dict[str, object]]:
    rows = [
        {
            "decision": record.decision_class,
            "id": license_row_id(record),
            "licensors": list(LICENSORS[pin["license_record_id"]]),
            "record_digest": record.digest,
            "text_sha256": record.text_sha256,
        }
    ]
    for component in record.components:
        extra = COMPONENT_LICENSE_ROWS.get(component.id)
        if extra is None:
            continue
        if component.exception_text_sha256 is None:
            raise SystemExit(f"{record.id} component {component.id} has no text")
        rows.append(
            {
                "decision": extra["decision"],
                "id": extra["license_id"],
                "licensors": list(extra["licensors"]),
                "record_digest": record.digest,
                "text_sha256": component.exception_text_sha256,
            }
        )
    return rows


def member_files(pin: dict) -> list[dict[str, object]]:
    files = []
    for item in pin["members"]:
        files.append(
            {"bytes": item["bytes"], "path": item["path"], "sha256": item["sha256"]}
        )
    return files


def build_archive_asset(pin: dict) -> dict:
    record = load_license(pin["license_record_id"])
    files = member_files(pin)
    files.extend(notice_files(record))
    files.sort(key=lambda item: item["path"])
    installed = sum(int(item["bytes"]) for item in files)
    download = pin["archive_bytes"]
    return {
        "compatibility": {
            "consumer_schema": pin.get("consumer_schema", "kilix.speech.models/v1"),
            "maximum": 1,
            "minimum": 1,
        },
        "files": files,
        "id": pin["id"],
        "label": pin["id"],
        "licenses": license_rows(pin, record),
        "provider": pin.get("provider", "kilix-voice"),
        "schema": "kilix.content.asset/v3",
        "sizes": {
            "download_bytes": download,
            "installed_bytes": installed,
            "temporary_bytes": download + installed,
        },
        "source": {
            "archive_bytes": pin["archive_bytes"],
            "archive_sha256": pin["archive_sha256"],
            "format": pin["format"],
            "mode": "upstream-archive",
            "provenance": dict(pin["provenance"]),
            "root": pin["root"],
            "url": pin["archive_url"],
        },
        "stream": "F104",
        "version": pin["version"],
        **({"storage": pin["storage"]} if "storage" in pin else {}),
    }


def build_files_asset(pin: dict) -> dict:
    record = load_license(pin["license_record_id"])
    files = member_files(pin)
    files.extend(notice_files(record))
    files.sort(key=lambda item: item["path"])
    fetch = [{"path": item["path"], "url": item["url"]} for item in pin["members"]]
    fetch.sort(key=lambda item: item["path"])
    download = sum(int(item["bytes"]) for item in pin["members"])
    installed = sum(int(item["bytes"]) for item in files)
    return {
        "compatibility": {
            "consumer_schema": pin["consumer_schema"],
            "maximum": 1,
            "minimum": 1,
        },
        "files": files,
        "id": pin["id"],
        "label": pin.get("label", pin["id"]),
        "licenses": license_rows(pin, record),
        "provider": pin["provider"],
        "schema": "kilix.content.asset/v3",
        "sizes": {
            "download_bytes": download,
            "installed_bytes": installed,
            "temporary_bytes": installed,
        },
        "source": {
            "fetch": fetch,
            "mode": "upstream-files",
            "provenance": dict(pin["provenance"]),
        },
        "stream": "F104",
        "version": pin["version"],
    }


def build_convert_asset(pin: dict) -> dict:
    """An upstream-convert record, in one of two layouts.

    `members`: the fetched upstream files are the installed tree, and the
    conversion derives something beside it.

    `outputs`: the conversion's own output is the installed tree (OD-AR's
    EnCodec records). The inputs are then not installed files at all -- the
    converter requires an empty output directory -- so the primary one stays in
    `input` and any others are pinned in `inputs`, by exact size and digest.
    """
    record = load_license(pin["license_record_id"])
    primary = pin["input"]
    source = {
        "conversion": {
            "argv": list(pin["conversion"]["argv"]),
            "tool_asset_id": pin["conversion"]["tool_asset_id"],
        },
        "input": {
            "bytes": primary["bytes"],
            "sha256": primary["sha256"],
            "url": primary["url"],
        },
        "mode": "upstream-convert",
        "provenance": dict(pin["provenance"]),
    }
    if "path" in primary:
        source["input"]["path"] = primary["path"]

    if "outputs" in pin:
        if "members" in pin:
            raise SystemExit(f"{pin['id']} pins both members and outputs")
        files = [
            {"bytes": item["bytes"], "path": item["path"], "sha256": item["sha256"]}
            for item in pin["outputs"]
        ]
        extra_inputs = [
            {
                "bytes": item["bytes"],
                "path": item["path"],
                "sha256": item["sha256"],
                "url": item["url"],
                **({'provenance':dict(item['provenance'])} if 'provenance' in item else {}),
            }
            for item in pin.get("inputs", [])
        ]
        extra_inputs.sort(key=lambda item: item["path"])
        if extra_inputs:
            source["inputs"] = extra_inputs
        download = int(primary["bytes"]) + sum(
            int(item["bytes"]) for item in extra_inputs
        )
    else:
        files = member_files(pin)
        extra = [
            {"path": item["path"], "url": item["url"]}
            for item in pin["members"]
            if item["path"] != primary["path"]
        ]
        extra.sort(key=lambda item: item["path"])
        if extra:
            source["fetch"] = extra
        download = sum(int(item["bytes"]) for item in pin["members"])

    files.extend(notice_files(record))
    files.sort(key=lambda item: item["path"])
    installed = sum(int(item["bytes"]) for item in files)
    floor = download + installed
    # An override may only raise the floor, and it is refused here rather than
    # written into a record the suite then fails on (C4-FIX-VERIFY V-F2). The
    # floor includes the notice files, which the pin generator cannot see, so
    # a value it accepted can still be refused here -- by name, with the
    # number that would be accepted.
    temporary = int(pin.get("temporary_bytes", floor))
    if temporary < floor:
        raise SystemExit(
            f"{pin['id']}: temporary_bytes {temporary} is below the record's "
            f"floor of {floor} (download {download} + installed {installed}, "
            "licence notices included)"
        )
    return {
        "compatibility": {
            "consumer_schema": pin["consumer_schema"],
            "maximum": 1,
            "minimum": 1,
        },
        "files": files,
        "id": pin["id"],
        "label": pin.get("label", pin["id"]),
        "licenses": license_rows(pin, record),
        "provider": pin["provider"],
        "schema": "kilix.content.asset/v3",
        "sizes": {
            "download_bytes": download,
            "installed_bytes": installed,
            "temporary_bytes": temporary,
        },
        "source": source,
        "stream": pin.get("stream", "F104"),
        "version": pin["version"],
    }


def build_registry_asset(pin: dict) -> dict:
    record = load_license(pin["license_record_id"])
    files = [
        {"bytes": item["bytes"], "path": item["path"], "sha256": item["sha256"]}
        for item in pin["blobs"]
    ]
    files.extend(notice_files(record))
    files.sort(key=lambda item: item["path"])
    blobs = [{"path": item["path"], "url": item["url"]} for item in pin["blobs"]]
    blobs.sort(key=lambda item: item["path"])
    download = int(pin["manifest_bytes"])
    installed = sum(int(item["bytes"]) for item in files)
    return {
        "compatibility": {
            "consumer_schema": pin["consumer_schema"],
            "maximum": 1,
            "minimum": 1,
        },
        "files": files,
        "id": pin["id"],
        "label": pin.get("label", pin["id"]),
        "licenses": license_rows(pin, record),
        "provider": pin["provider"],
        "schema": "kilix.content.asset/v3",
        "sizes": {
            "download_bytes": download,
            "installed_bytes": installed,
            "temporary_bytes": download + installed,
        },
        "source": {
            "blobs": blobs,
            "manifest_sha256": pin["manifest_sha256"],
            "manifest_url": pin["manifest_url"],
            "mode": "registry-manifest",
            "provenance": dict(pin["provenance"]),
        },
        "stream": "F104",
        "version": pin["version"],
    }


def build_from_pin(pin: dict) -> dict:
    mode = pin.get("mode", "upstream-archive")
    if mode == "upstream-files":
        return build_files_asset(pin)
    if mode == "upstream-archive":
        return build_archive_asset(pin)
    if mode == "upstream-convert":
        return build_convert_asset(pin)
    if mode == "registry-manifest":
        return build_registry_asset(pin)
    raise SystemExit(f"unsupported pin mode {mode!r} for {pin.get('id')}")


def _pin_match(path: Path, name: str) -> tuple[str, re.Match[str]]:
    text = path.read_text(encoding="utf-8")
    pattern = rf"({name} = \(\n    \")([0-9a-f]{{64}})(\"\n\))"
    match = re.search(pattern, text)
    if match is None:
        raise SystemExit(f"could not find {name} in {path}")
    return text, match


def _bindings(tree: ast.Module, name: str) -> list[ast.AST]:
    """Every node in the module that binds or unbinds name."""
    found: list[ast.AST] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            bound = node.id if not isinstance(node.ctx, ast.Load) else None
        elif isinstance(node, ast.alias):
            bound = node.asname or node.name.split(".")[0]
        elif isinstance(
            node,
            (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.ExceptHandler,
             ast.MatchAs, ast.MatchStar),
        ):
            bound = node.name
        elif isinstance(node, ast.MatchMapping):
            bound = node.rest
        else:
            bound = None
        if bound == name or bound == "*":
            found.append(node)
    return found


def check_pin(path: Path, name: str, expected: str) -> None:
    """--check: a hand-edited pin fails like a hand-edited catalog (C2E-VERIFY F7).

    The runtime uses the last binding of the name, so exactly one binding is
    allowed: a module-level string assignment (C2E-FIX-VERIFY R5).
    """
    text, match = _pin_match(path, name)
    relative = path.relative_to(ROOT)
    tree = ast.parse(text, filename=str(relative))
    bindings = _bindings(tree, name)
    if len(bindings) != 1:
        lines = ", ".join(str(getattr(node, "lineno", "?")) for node in bindings)
        raise SystemExit(
            f"{name} is bound {len(bindings)} times in {relative} (lines {lines}); "
            "make pins allows exactly one assignment"
        )
    assignment = next(
        (
            node
            for node in tree.body
            if isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and node.targets[0] is bindings[0]
            and isinstance(node.value, ast.Constant)
            and isinstance(node.value.value, str)
        ),
        None,
    )
    if assignment is None:
        raise SystemExit(f"{name} in {relative} is not a module-level string assignment")
    value = assignment.value.value
    if value != match.group(2):
        raise SystemExit(f"{name} in {relative} is {value}, not the pin text {match.group(2)}")
    if value != expected:
        raise SystemExit(
            f"{name} in {relative} is {value}, "
            f"but the generated bytes hash to {expected}"
        )


def replace_pin(path: Path, name: str, new_sha: str, old_sha: str | None) -> None:
    text, match = _pin_match(path, name)
    current = match.group(2)
    if current == new_sha:
        return
    if current != "0" * 64 and old_sha is not None and current != old_sha:
        raise SystemExit(
            f"{name} old-value guard failed: have {current}, expected {old_sha}"
        )
    if current != "0" * 64 and old_sha is None:
        raise SystemExit(f"{name} refuses to change {current} without --old")
    path.write_text(text[: match.start(2)] + new_sha + text[match.end(2) :], encoding="utf-8")


def render_catalog(catalog: dict) -> str:
    return json.dumps(catalog, indent=2, ensure_ascii=False) + "\n"


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--old", dest="old_sha", default=None)
    parser.add_argument('--old-schema',default='0'*64)
    args = parser.parse_args(argv[1:])
    pins = [
        json.loads((PIN_DIR / name).read_text(encoding="utf-8")) for name in PIN_NAMES
    ]
    assets = [build_from_pin(pin) for pin in pins]
    catalog = json.loads(CATALOG.read_text(encoding="utf-8"))
    catalog["schema_version"] = 4
    catalog["assets"] = assets
    rendered = render_catalog(catalog)
    catalog_sha = hashlib.sha256(rendered.encode("utf-8")).hexdigest()
    schema_sha = sha256_file(SCHEMA)
    if args.check:
        if CATALOG.read_text(encoding="utf-8") != rendered:
            raise SystemExit("catalog/plebian.json does not match the generator")
        check_pin(RECEIPT, "_CATALOG_SHA256", catalog_sha)
        check_pin(RECEIPT, "_ASSET_V3_SCHEMA_SHA256", schema_sha)
        return 0
    CATALOG.write_text(rendered, encoding="utf-8")
    replace_pin(RECEIPT, "_CATALOG_SHA256", catalog_sha, args.old_sha)
    replace_pin(RECEIPT, "_ASSET_V3_SCHEMA_SHA256", schema_sha, args.old_schema)
    print(f"catalog sha256 {catalog_sha}")
    print(f"schema sha256 {schema_sha}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
