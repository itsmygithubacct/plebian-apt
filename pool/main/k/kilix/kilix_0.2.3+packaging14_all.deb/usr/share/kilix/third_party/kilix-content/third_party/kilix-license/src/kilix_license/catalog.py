"""Load generated determination records and their text blobs."""

from __future__ import annotations

from pathlib import Path

from kilix_license.generate import (
    APP_RECORDS_DIRNAME,
    DATA_DIR,
    RECORDS_DIRNAME,
    TEXTS_DIRNAME,
    data_dir,
    record_filename,
)
from kilix_license.records import LicenseRecord, RecordIndex
from kilix_license.texts import TextStore


def records_dir(root: Path | None = None) -> Path:
    return data_dir(root) / RECORDS_DIRNAME


def texts_dir(root: Path | None = None) -> Path:
    return data_dir(root) / TEXTS_DIRNAME


def app_records_dir(root: Path | None = None) -> Path:
    return data_dir(root) / APP_RECORDS_DIRNAME


def load_determined_records(root: Path | None = None) -> RecordIndex:
    """Release records and application records; an id in both is refused."""
    records = []
    for directory in (records_dir(root), app_records_dir(root), data_dir(root)/'diarization-records', data_dir(root)/'lfm2-records', data_dir(root)/'lfm3-records', data_dir(root)/'needle3-records', data_dir(root)/'female02-records', data_dir(root)/'paradee-records', data_dir(root)/'noloop02-records', data_dir(root)/'basic-pitch-records', data_dir(root)/'whisper-medium-records', data_dir(root)/'demucs-records', data_dir(root)/'whisper-large-v3-records', data_dir(root)/'en-core-web-sm-records', data_dir(root)/'pp-ocrv6-small-records'):
        for path in sorted(directory.glob("*.json")):
            records.append(LicenseRecord.from_bytes(path.read_bytes()))
    return RecordIndex(records)


def load_determined_texts(store_root: Path, *, package_root: Path | None = None) -> TextStore:
    store = TextStore(store_root)
    directory = texts_dir(package_root)
    for path in sorted(directory.iterdir()):
        if not path.is_file() or path.name.startswith("."):
            continue
        store.put(path.read_bytes(), label=path.name)
    return store


def record_path(record_id: str, root: Path | None = None) -> Path:
    """Locate a release, application or separately pinned diarization record."""
    for directory in (app_records_dir(root),data_dir(root)/'diarization-records', data_dir(root)/'lfm2-records', data_dir(root)/'lfm3-records', data_dir(root)/'needle3-records', data_dir(root)/'female02-records', data_dir(root)/'paradee-records', data_dir(root)/'noloop02-records', data_dir(root)/'basic-pitch-records', data_dir(root)/'whisper-medium-records', data_dir(root)/'demucs-records', data_dir(root)/'whisper-large-v3-records', data_dir(root)/'en-core-web-sm-records', data_dir(root)/'pp-ocrv6-small-records',records_dir(root)):
        path=directory/record_filename(record_id)
        if path.is_file():return path
    return records_dir(root)/record_filename(record_id)


# Default package data location, used by tools when cwd is the repository root.
PACKAGE_DATA = DATA_DIR
