"""Small, credentialed pane primitives for the bundled agent skills.

This is a client of the existing terminal authorizer, not a permissions layer
or an agent supervisor. Input acceptance does not prove application delivery.
No model menus are guessed and no shell command strings are evaluated.
"""
from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import re
import selectors
import shutil
import stat
import subprocess
import sys
import time

SCHEMA = "kilix.agent-control/v1"
DEFAULT_RPC_TIMEOUT = 10.0
BROKER = re.compile(r"[0-9a-f]{16,64}\Z")
KEYS = {"enter": b"\r", "escape": b"\x1b", "up": b"\x1b[A",
        "down": b"\x1b[B", "right": b"\x1b[C", "left": b"\x1b[D",
        "tab": b"\t", "ctrl-c": b"\x03"}
LOCATIONS = {"right": "vsplit", "left": "vsplit-before",
             "down": "hsplit", "up": "hsplit-before"}
AGENTS = ("codex", "claude", "kimi", "grok", "qwen-omp")
# The executable each agent name runs, and the argv it starts with.
PROGRAMS = {"qwen-omp": "omp"}
DEFAULT_MODELS = {"qwen-omp": "qwen3.8-max"}
# Each client's own "skip my approval prompts" flag, used only when Kilix's
# coding-yolo setting is on and the launch asks to follow it.
YOLO_FLAGS = {"claude": ["--dangerously-skip-permissions"],
              "codex": ["--dangerously-bypass-approvals-and-sandbox"],
              "grok": ["--always-approve"], "qwen-omp": ["--auto-approve"]}
# omp's task executor forces its child agents to yolo independently of the
# parent's approval mode.  Keep the omp 18.3.2 tools loaded under the default
# configuration except `task` when Kilix coding-yolo is off.  Optional tools
# cannot appear here: omp rejects requested tools which its config disabled.
# Not here: `ast_grep` (astGrep.enabled defaults to false) and `find`
# (find.enabled defaults to "auto", on only for some models), both of which
# omp would reject as unknown (review R13 round 4, KX-R13-38).
# Proven against omp 18.3.2 itself (review R13 round 5, KX-R13-42): with a
# scratch HOME, `omp -p --tools=<one>` gets past tool validation for each of
# these, and rejects `ask` and `ida` (loaded only with a UI / an IDA install)
# as well as `ast_grep` and `find`.
OMP_NON_YOLO_TOOLS = ("read", "bash", "edit", "ast_edit", "debug", "eval", "glob",
                      "grep", "lsp", "wait", "todo", "web_search", "write")
ASK_FLAGS = {"qwen-omp": ["--approval-mode=always-ask",
                           "--tools=" + ",".join(OMP_NON_YOLO_TOOLS)]}
# Every accepted extra is one self-contained argv item.  Values are inline so
# a following item can never be reinterpreted as an unrestricted option value.
AGENT_ARG_PATTERNS = {
    "claude": (),
    "codex": (),
    "grok": (re.compile(r"--effort=[A-Za-z0-9_-]+\Z"),),
    "qwen-omp": (re.compile(r"--thinking=[A-Za-z0-9_-]+\Z"),),
    "kimi": (),
}
REASONING_EFFORTS = ("low", "medium", "high", "xhigh", "max")
_SUBCOMMANDS = {}


def client_subcommands(executable, deadline=float("inf")):
    """The client's own subcommand names and aliases, read from its --help.
    A prompt whose first word is one of them would run that command instead."""
    if executable in _SUBCOMMANDS:
        return _SUBCOMMANDS[executable]
    remaining = min(30, deadline - time.monotonic())
    if remaining <= 0:
        raise ControlError("client help deadline expired")
    try:
        done = subprocess.run([executable, "--help"], stdin=subprocess.DEVNULL,
                              capture_output=True, text=True, timeout=remaining, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ControlError(f"cannot read {Path(executable).name} --help to check the prompt") from exc
    names, inside = set(), False
    for line in (done.stdout + "\n" + done.stderr).splitlines():
        if re.fullmatch(r"(?i)commands:?\s*", line.strip()) and not line.startswith(" "):
            inside = True
            continue
        if inside and line and not line.startswith(" "):
            inside = False
        if inside:
            match = re.match(r"\s{1,4}([a-z][\w|-]*)", line)
            if match:
                names.update(match[1].split("|"))
            names.update(re.findall(r"\[alias(?:es)?: ([^\]]+)\]", line) and
                         [a.strip() for group in re.findall(r"\[alias(?:es)?: ([^\]]+)\]", line)
                          for a in group.split(",")] or [])
    if not names:
        raise ControlError(f"cannot read {Path(executable).name}'s commands to check the prompt")
    _SUBCOMMANDS[executable] = frozenset(n.casefold() for n in names)
    return _SUBCOMMANDS[executable]


SESSION_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
PROCESS_AGENTS = {"codex": "codex", "codex.js": "codex", "claude": "claude", "kimi": "kimi",
                  "grok": "grok", "omp": "qwen-omp"}


class ControlError(RuntimeError):
    pass


def positive(value):
    number = int(value)
    if number <= 0:
        raise argparse.ArgumentTypeError("expected a positive pane ID")
    return number


def delivery_message_id(value):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", value):
        raise argparse.ArgumentTypeError("expected a 1–64 character delivery ID")
    return value


def plain_text(value, label, limit=1024):
    if not value or len(value.encode("utf-8")) > limit:
        raise ControlError(f"{label} must contain 1–{limit} UTF-8 bytes")
    if any(ord(c) < 32 or 127 <= ord(c) <= 159 for c in value):
        raise ControlError(f"{label} must be a single line without control characters")
    return value


def _git_marker_above(directory):
    """Whether a path is visibly within a Git worktree, even if git refuses it."""
    current = directory.resolve()
    return any((parent / ".git").exists() or (parent / ".git").is_symlink()
               for parent in (current, *current.parents))


def grok_trust_is_exact(cwd, deadline=float("inf")):
    """Refuse Grok trust when its repository-scoped grant would exceed cwd."""
    # A jj workspace above cwd may be the root grok trusts: only its root.
    if any((parent / ".jj").is_dir() for parent in cwd.resolve().parents):
        raise ControlError("grok --trust-folder inside a jj workspace needs --cwd to be its root")
    try:
        remaining = min(10, deadline - time.monotonic())
        if remaining <= 0:
            raise ControlError("repository check deadline expired")
        # The caller's GIT_DIR/GIT_WORK_TREE must not redefine the repository
        # (KX-R13-39).
        env = {k: v for k, v in os.environ.items() if not k.startswith("GIT_")}
        done = subprocess.run(
            ["git", "-C", os.fspath(cwd), "rev-parse", "--show-toplevel"],
            stdin=subprocess.DEVNULL, capture_output=True, timeout=remaining, check=False, env=env)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ControlError("cannot determine the Git repository root for grok --trust-folder") from exc
    if done.returncode:
        if _git_marker_above(cwd):
            raise ControlError("cannot determine the Git repository root for grok --trust-folder")
        return
    top = Path(os.fsdecode(done.stdout.strip())).resolve()
    if cwd.resolve() != top:
        raise ControlError("grok --trust-folder requires --cwd to be the Git repository root; "
                           f"refusing repository-wide trust from {cwd}")


# The pane's PTY broker identity, recovered with the route so a restored pane
# can be rebound to the terminal that replaced the one that launched it.
BROKER_IDENTITY = ("KITTY_PID", "KITTY_PTY_BROKER_SESSION", "KITTY_PTY_BROKER_RUNTIME",
                   "KITTY_PTY_BROKER_EXECUTABLE")


def refresh_route(values):
    """Rebind a stale route after the terminal that launched this tool exited.

    A persistent shell or agent keeps the socket, window id, public key and
    password-file path of its original terminal. kilix_sdk.frontend_context,
    the same check every SDK pane command uses, replaces those fields only
    when the original terminal is gone and exactly one verified attach helper
    of this pane's own broker session runs under a live terminal; otherwise
    nothing changes. Returns whether the route was replaced.
    """
    try:
        from kilix_sdk.frontend_context import refresh
    except ImportError:
        return False
    return refresh(values)


ROUTE = ("KITTY_LISTEN_ON", "KITTY_WINDOW_ID", "KILIX_RC_PASSWORD_FILE", "KITTY_PUBLIC_KEY")


REFRESHED = "_route_refreshed"     # set by connection_values(); never an environment name


def connection_values():
    """Recover this pane's connection metadata, rebound to a replacement terminal."""
    values = recovered_values()
    # recovered_values is diagnostic metadata, never a route authorization.
    # A broker claim requires positive owner proof even if no matching process
    # could be found (including a surviving broker with an old executable).
    from kilix_sdk.caller_context import CallerContextError, require_pane_local
    try:
        require_pane_local(values)
    except CallerContextError as exc:
        raise ControlError(str(exc)) from None
    if refresh_route(values):
        values[REFRESHED] = "1"
    return values


def recovered_values():
    """Collect raw diagnostic metadata; use connection_values to authorize it.

    Missing ownership proof may be reported by diagnostics. Conflicts and
    shared-server ancestry still refuse. No helper credentials or RPC are
    accepted here; connection_values and the SDK require positive proof.
    """
    from kilix_sdk.caller_context import (BrokerOwnershipUnavailable,
                                         CallerContextError, require_pane_local)
    try:
        require_pane_local()
    except BrokerOwnershipUnavailable:
        pass
    except CallerContextError as exc:
        raise ControlError(str(exc)) from None
    names = (*ROUTE, "KILIX_KITTEN", "KILIX_BUILD_DIRECTORY", "KILIX_PREBUILT_HOME",
             *BROKER_IDENTITY)
    values = {name: os.environ[name] for name in names if os.environ.get(name)}
    # Keep walking until the broker identity is found too: a caller that kept
    # the route but lost the identity could otherwise never be rebound.
    needed = (*ROUTE, *BROKER_IDENTITY)
    pid = os.getppid()
    for _ in range(24):
        if all(values.get(name) for name in needed) or pid <= 1:
            break
        proc = Path("/proc") / str(pid)
        try:
            if proc.stat().st_uid != os.getuid():
                break
            entries = (proc / "environ").read_bytes().split(b"\0")
            parent_values = {}
            for entry in entries:
                key, sep, value = entry.partition(b"=")
                name = key.decode("ascii", errors="ignore")
                if sep and name in names:
                    parent_values[name] = os.fsdecode(value)
            # Never combine metadata belonging to different terminal instances.
            if (not values.get("KITTY_LISTEN_ON") or
                    parent_values.get("KITTY_LISTEN_ON") == values["KITTY_LISTEN_ON"]):
                # The broker identity selects which pane to rebind, so it comes
                # only from an ancestor of this same pane: one that names a
                # socket, and no other window of that terminal.
                same_pane = bool(parent_values.get("KITTY_LISTEN_ON")) and (
                    not values.get("KITTY_WINDOW_ID") or not parent_values.get("KITTY_WINDOW_ID")
                    or parent_values["KITTY_WINDOW_ID"] == values["KITTY_WINDOW_ID"])
                for name, value in parent_values.items():
                    if name in BROKER_IDENTITY and not same_pane:
                        continue
                    values.setdefault(name, value)
            status = (proc / "status").read_text()
            pid = int(next(line.split()[1] for line in status.splitlines()
                           if line.startswith("PPid:")))
        except (OSError, ValueError, StopIteration):
            break
    # The caller may have gained its complete claim only during this walk.
    # connection_values validates that completed claim before route selection.
    return values


#: The kitten of the kilix-engine Debian package. A fixed system path, never
#: taken from the environment: the kitten receives the password file.
PACKAGED_KITTEN = "/usr/lib/kilix/engine/bin/kitten"


def kitten_path(values, from_socket=True):
    """The kitten matching this terminal. The process a socket names is trusted
    to locate it only for the inherited socket: a refreshed route names a
    process found by inspection, and the kitten receives the password file."""
    candidates = [values.get("KILIX_KITTEN", "")]
    match = re.fullmatch(r"unix:@kilix-(\d+)", values.get("KITTY_LISTEN_ON", ""))
    if match and from_socket:
        try:
            candidates.append(str(Path(os.readlink(f"/proc/{match[1]}/exe")).with_name("kitten")))
        except OSError:
            pass
    if build := values.get("KILIX_BUILD_DIRECTORY"):
        candidates.append(str(Path(build) / "current/src/kitty/launcher/kitten"))
    candidates.append(PACKAGED_KITTEN)
    if prebuilt := values.get("KILIX_PREBUILT_HOME"):
        candidates.append(str(Path(prebuilt) / "bin/kitten"))
    candidates.append(shutil.which("kitten") or "")
    for candidate in candidates:
        if candidate and Path(candidate).is_file() and os.access(candidate, os.X_OK):
            return candidate
    raise ControlError("matching kitten is unavailable; inspect the installed Kilix engine")


class Client:
    def __init__(self, caller_pane=None):
        values = connection_values()
        refreshed = bool(values.pop(REFRESHED, ""))
        socket = values.get("KITTY_LISTEN_ON", "")
        credential = values.get("KILIX_RC_PASSWORD_FILE", "")
        if not socket or not credential:
            raise ControlError("no inherited Kilix connection; select the intended instance explicitly")
        info = Path(credential).lstat()
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or stat.S_IMODE(info.st_mode) != 0o600 or info.st_nlink != 1):
            raise ControlError("Kilix credential must be a private, owned 0600 regular file")
        inherited = int(values.get("KITTY_WINDOW_ID", "0"))
        if caller_pane and inherited and caller_pane != inherited:
            raise ControlError("--caller-pane conflicts with the inherited caller identity")
        self.caller = caller_pane or inherited
        self.command = [kitten_path(values, from_socket=not refreshed), "@", "--to", socket,
                        "--password-file", credential]
        # The kitten forwards KITTY_WINDOW_ID and KITTY_PUBLIC_KEY to the engine,
        # so its environment carries the same (possibly refreshed) route.
        self.command_env = {k: v for k, v in os.environ.items()
                            if k not in ROUTE and k != "KITTY_PID"}
        for name in (*ROUTE, "KITTY_PID"):
            if values.get(name):
                self.command_env[name] = values[name]

    def run(self, args, payload=None):
        process = None
        try:
            # Structured operations install one absolute deadline shared by
            # their identity checks, mutations and observations. Do not let a
            # shorter per-RPC default cut that operation off mid-flight. A
            # direct, unbounded client call still gets a local safety limit.
            deadline = getattr(self, "deadline", float("inf"))
            if deadline == float("inf"):
                deadline = time.monotonic() + DEFAULT_RPC_TIMEOUT
            if deadline <= time.monotonic():
                raise ControlError("terminal request deadline expired; inspect state before retrying")
            process = subprocess.Popen(self.command + args,
                                       stdin=subprocess.PIPE if payload is not None else subprocess.DEVNULL,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                       env=getattr(self, "command_env", None))
            if payload is not None:
                if len(payload) > 1024:
                    raise ControlError("input exceeds 1024 bytes")
                process.stdin.write(payload)
                process.stdin.close()
            output = {"stdout": bytearray(), "stderr": bytearray()}
            total = 0
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout, selectors.EVENT_READ, "stdout")
                selector.register(process.stderr, selectors.EVENT_READ, "stderr")
                while selector.get_map():
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise ControlError("terminal request timed out; inspect state before retrying")
                    for key, _ in selector.select(remaining):
                        block = os.read(key.fd, 65536)
                        if not block:
                            selector.unregister(key.fileobj)
                            continue
                        total += len(block)
                        if total > 1024 * 1024:
                            raise ControlError("terminal response exceeded 1 MiB; inspect state before retrying")
                        output[key.data].extend(block)
            code = process.wait(timeout=max(0.01, deadline - time.monotonic()))
            if code:
                raise ControlError(output["stderr"].decode("utf-8", errors="replace").strip()
                                   or f"terminal client exited {code}")
            return output["stdout"].decode("utf-8", errors="replace")
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise ControlError("terminal request failed; inspect state before retrying") from exc
        finally:
            if process is not None:
                if process.poll() is None:
                    process.kill()
                    process.wait(timeout=2)
                for stream in (process.stdin, process.stdout, process.stderr):
                    if stream is not None:
                        stream.close()

    def snapshot(self):
        result = []
        state = json.loads(self.run(["ls"]))
        for os_window in state:
            for tab in os_window.get("tabs", []):
                # Overlays share their parent's window group; layouts count groups.
                groups = ((tab.get("layout_state") or {}).get("all_windows") or {}).get("window_groups")
                for pane in tab.get("windows", []):
                    result.append({**pane, "tab_id": tab["id"],
                                   "tab_title": tab.get("title", ""),
                                   "layout": tab.get("layout", ""),
                                   "tab_window_groups": len(groups) if isinstance(groups, list) else None,
                                   "tab_focused": bool(tab.get("is_focused")),
                                   "os_window_focused": bool(os_window.get("is_focused")),
                                   "os_window_id": os_window["id"]})
        return result

    def resolve(self, pane_id, expected=None, input_target=False):
        panes = self.snapshot()
        matches = [pane for pane in panes if pane.get("id") == pane_id]
        if len(matches) != 1:
            raise ControlError("pane is absent or ambiguous; take a new snapshot")
        pane = matches[0]
        broker = (pane.get("env") or {}).get("KITTY_PTY_BROKER_SESSION", "")
        if expected is not None:
            if not BROKER.fullmatch(expected) or broker != expected:
                raise ControlError("pane/broker identity changed; no input or launch attempted")
            if sum((p.get("env") or {}).get("KITTY_PTY_BROKER_SESSION") == broker
                   for p in panes) != 1:
                raise ControlError("broker session does not identify exactly one pane")
        if input_target:
            if not self.caller or not any(p.get("id") == self.caller for p in panes):
                raise ControlError("caller identity unknown; provide the verified --caller-pane")
            if pane_id == self.caller:
                raise ControlError("refusing input into the controlling agent's own pane")
        return pane

    def input(self, pane_id, expected, payload):
        self.resolve(pane_id, expected, input_target=True)
        if not 0 < len(payload) <= 1024:
            raise ControlError("input exceeds the existing 1024-byte authorization boundary")
        self.run(["send-text", "--match", f"env:KITTY_PTY_BROKER_SESSION={expected}",
                  "--stdin", "--bracketed-paste=disable"], payload)


def describe(pane):
    """Do not publish full environments or prompt-bearing process arguments."""
    processes = []
    agents = set()
    for process in pane.get("foreground_processes") or []:
        argv = process.get("cmdline") or []
        if argv:
            # Some processes overwrite argv[0] with their entire display title.
            # Keep only a bounded program token, never that argument-like title.
            program = Path(argv[0].split(" ", 1)[0]).name[:80]
            processes.append({"pid": process.get("pid"), "program": program})
            for arg in argv[:2]:
                name = Path(arg).name
                if name in PROCESS_AGENTS:
                    agents.add(PROCESS_AGENTS[name])
    return {"pane_id": pane["id"], "tab_id": pane["tab_id"],
            "os_window_id": pane["os_window_id"], "title": pane.get("title", ""),
            "tab_title": pane["tab_title"], "cwd": pane.get("cwd", ""),
            "layout": pane["layout"], "active_in_tab": bool(pane.get("is_focused")),
            "focused": bool(pane.get("is_focused") and pane.get("tab_focused")
                            and pane.get("os_window_focused")),
            "broker": (pane.get("env") or {}).get("KITTY_PTY_BROKER_SESSION", ""),
            "agent": next(iter(agents)) if len(agents) == 1 else None,
            "foreground_processes": processes,
            "lines": pane.get("lines"), "columns": pane.get("columns"),
            "neighbors": pane.get("neighbors", {})}


def launch(client, args, *, explicit_argv=None):
    target = client.resolve(args.pane, args.expect_broker)
    if not client.caller or not any(p["id"] == client.caller for p in client.snapshot()):
        raise ControlError("caller identity unknown; provide the verified --caller-pane")
    cwd = Path(args.cwd).expanduser()
    if not cwd.is_absolute() or not cwd.is_dir():
        raise ControlError("--cwd must be an existing absolute directory")
    title = plain_text(args.title, "title", 200)
    # Share the coding-agent installer's executable resolution, including
    # vendor locations that desktop PATH values may omit.
    if explicit_argv is None:
        from agent_programs import resolve_agent_command
        executable = resolve_agent_command(PROGRAMS.get(args.agent, args.agent))
        if not executable:
            raise ControlError(f"{args.agent} is not installed; use kilix install explicitly")
        argv = agent_argv(args, executable, cwd, deadline=getattr(client, "deadline", float("inf")))
    else:
        argv = explicit_argv
    trusted = None
    if args.trust_folder and not args.dry_run:
        from agent_trust import TrustError, trust
        try:
            trusted = trust(args.agent, str(cwd))
        except TrustError as exc:
            raise ControlError(f"folder not trusted: {exc}") from exc
    if args.action == "new-tab" and joins_grid(args, explicit_argv):
        import session_grid
        name = getattr(args, "grid", None) or session_grid.DEFAULT_GRID
        if args.dry_run:
            return {"schema": SCHEMA, "status": "dry_run", "target": describe(target),
                    "placement": {"grid": name, "layout": session_grid.LAYOUT,
                                  "capacity": session_grid.CAPACITY}, "argv": argv}
        if explicit_argv is None:
            from coding_launch import wrapper
            argv = wrapper(args.agent, argv, prompt=args.prompt)
        placed = session_grid.place(client, source=describe(target), argv=argv, cwd=str(cwd),
                                    title=title, name=name, hold=True,
                                    retarget=getattr(client, "retarget", None))
        return {"schema": SCHEMA, "status": "created", "pane": placed["pane"],
                "grid": {key: placed[key] for key in ("grid", "tab_id", "new_tab", "layout", "fallback",
                                                     "count", "capacity", "slot")},
                "agent_startup_verified": False, "prompt_submitted": False,
                "prompt_passed": bool(args.prompt), "resumed": args.resume or None,
                "folder_trust": trusted}
    options = ["launch", "--match", f"window_id:{args.pane}",
               "--next-to", f"id:{args.pane}", "--source-window", f"id:{args.pane}",
               "--keep-focus", "--hold", "--cwd", str(cwd), "--title", title]
    required = ["--next-to", "--source-window", "--keep-focus"]
    if args.action == "new-tab":
        options.extend(["--type", "tab", "--tab-title", title])
    else:
        if target["layout"] != "splits":
            raise ControlError("target tab is not in splits layout; no layout or permission changes made")
        if not 0 < args.bias < 100:
            raise ControlError("split bias must be greater than 0 and less than 100")
        location = LOCATIONS[args.direction]
        options.extend(["--location", location, "--bias", str(args.bias)])
        required.extend(["--bias", location])
    help_text = client.run(["launch", "--help"])
    if any(option not in help_text for option in required):
        raise ControlError("running engine lacks required explicit-target launch options")
    if args.dry_run:
        return {"schema": SCHEMA, "status": "dry_run", "target": describe(target),
                "launch_argv": options + ["--"] + argv}
    before = {pane["id"] for pane in client.snapshot()}
    current = client.resolve(args.pane, args.expect_broker)
    if any(current[key] != target[key] for key in ("tab_id", "os_window_id", "layout")):
        raise ControlError("anchor geometry changed; inspect state before launching")
    if explicit_argv is None:
        from coding_launch import wrapper
        argv = wrapper(args.agent, argv, prompt=args.prompt)
    raw_id = client.run(options + ["--"] + argv).strip()
    if not raw_id.isdecimal() or int(raw_id) in before or int(raw_id) <= 0:
        raise ControlError("launch returned no new pane ID; inspect state, do not blindly relaunch")
    pane = client.resolve(int(raw_id))
    if ((args.action == "split" and pane["tab_id"] != target["tab_id"])
            or (args.action == "new-tab" and pane["tab_id"] == target["tab_id"])
            or pane["os_window_id"] != target["os_window_id"]):
        raise ControlError(f"created pane {raw_id} in unexpected geometry; retained for inspection")
    return {"schema": SCHEMA, "status": "created", "pane": describe(pane),
            "agent_startup_verified": False, "prompt_submitted": False,
            "prompt_passed": bool(args.prompt), "resumed": args.resume or None,
            "folder_trust": trusted}


def joins_grid(args, explicit_argv):
    """A coding session opened into a new tab joins a session grid by default.

    An agent launch always counts; an explicit argv counts when its program is
    a known coding client. --own-tab, or the coding_session_grid setting off,
    keeps the old one-tab-per-session behaviour.
    """
    import session_grid
    if getattr(args, "own_tab", False):
        return False
    if explicit_argv is not None and not session_grid.is_agent_command(explicit_argv):
        return False
    return session_grid.enabled()


def validate_reasoning_effort(agent, effort):
    """Typed Codex setting; never turn arbitrary config into launch arguments."""
    if agent != "codex":
        raise ControlError("reasoning_effort is supported only for codex")
    if not isinstance(effort, str) or effort not in REASONING_EFFORTS:
        raise ControlError("reasoning_effort must be " + ", ".join(REASONING_EFFORTS))
    return effort


def agent_argv(args, executable, cwd, deadline=float("inf"), *, interactive=True):
    """The client's argv: its own flags, then resume, then a prompt, each one
    literal item. Nothing here comes from a shell string."""
    agent = args.agent
    if (args.prompt or args.resume) and agent == "kimi":
        raise ControlError("kimi takes no launch prompt or resume here; start it, then send")
    argv = [executable]
    if agent == "codex" and interactive:
        # Tool children must inherit this pane, not a shared server's old pane.
        # This is a top-level flag, before `resume`; `exec` does not accept it.
        argv.append("--no-daemon")
    resume = None
    if args.resume:
        if not SESSION_ID.fullmatch(args.resume):
            raise ControlError("--resume takes one session id")
        resume = args.resume
        if agent == "codex":
            argv.append("resume")      # `codex resume [OPTIONS] [SESSION_ID] [PROMPT]`
    model = args.model or DEFAULT_MODELS.get(agent)
    if model:
        model = plain_text(model, "model", 200)
        if model.startswith("-"):
            raise ControlError("a model name may not begin with '-'")
        argv.extend(["--model", model])
    effort = getattr(args, "reasoning_effort", None)
    if effort is not None:
        validate_reasoning_effort(agent, effort)
        argv.extend(["-c", f'model_reasoning_effort="{effort}"'])
    yolo = False
    if args.coding_yolo:
        from kilix_sdk import settings
        yolo = settings.coding_yolo()
    argv.extend(YOLO_FLAGS.get(agent, []) if yolo else ASK_FLAGS.get(agent, []))
    if getattr(args, "trust_folder", False) and agent == "grok":
        grok_trust_is_exact(cwd, deadline=deadline)
        argv.append("--trust")         # grok records its own folder trust
    if agent == "qwen-omp" and cwd == Path.home():
        argv.append("--allow-home")
    for item in args.agent_arg:
        if not any(pattern.fullmatch(item) for pattern in AGENT_ARG_PATTERNS[agent]):
            raise ControlError(f"--agent-arg {item!r} is not allowed for {agent}")
    argv.extend(args.agent_arg)
    if resume and agent == "codex":
        argv.append(resume)
    elif resume and agent in ("claude", "grok"):
        argv.extend(["--resume", resume])
    elif resume and agent == "qwen-omp":
        argv.append(f"--resume={resume}")
    if args.prompt is not None:
        prompt = plain_text(args.prompt, "prompt")
        stripped = prompt.lstrip()
        if stripped and stripped[0] in "/!#@-":
            raise ControlError("a prompt may not begin with '/', '!', '#', '@', or '-'")
        words = prompt.split()
        if not words:
            raise ControlError("prompt must contain non-whitespace text")
        if len(words) == 1:
            raise ControlError("a one-word prompt could select a client subcommand")
        first = words[0].casefold()
        if first in client_subcommands(executable, deadline=deadline):
            # "codex logout", "claude update": the first word would run a command.
            raise ControlError(f"a prompt may not begin with {first!r}, one of "
                               f"{Path(executable).name}'s own commands")
        if agent == "qwen-omp" and any(w.startswith("@") for w in words):
            # omp: the first word can name a command, and @word includes a file.
            raise ControlError("an omp prompt must be more than one word, with no @file words")
        argv.append(prompt)
    return argv


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--caller-pane", type=positive,
                        help="verified source pane, only when its environment was stripped")
    commands = result.add_subparsers(dest="action", required=True)
    commands.add_parser("list", help="redacted JSON snapshot; no inferred idle state")
    context = commands.add_parser("context", help="compact read-only identity and installation facts")
    context.add_argument("--target", type=positive, help="inspect this explicit pane only")
    context.add_argument("--expect-broker", help="report a stale target if this broker no longer matches")
    dump = commands.add_parser("dump", help="read a pane's visible screen")
    dump.add_argument("pane", type=positive)
    dump.add_argument("--lines", type=int, default=80)
    for name in ("send", "deliver", "key", "new-tab", "split"):
        command = commands.add_parser(name)
        command.add_argument("pane", type=positive,
                             help="input target, or explicit anchor for a new tab/split")
        command.add_argument("--expect-broker", required=True,
                             help="exact broker identity from the inspected snapshot")
        if name in ("send", "deliver"):
            text = command.add_mutually_exclusive_group(required=name == "send")
            text.add_argument("--text")
            text.add_argument("--file", type=Path,
                              help=("single-line UTF-8 message; 900 bytes including the ID prefix"
                                    if name == "deliver" else "single-line UTF-8 input, at most 1024 bytes"))
            if name == "deliver":
                command.add_argument("--message-id", required=True,
                                     help="stable unique ID; reuse it for retries of this message")
                command.add_argument("--timeout", type=float, default=15,
                                     help="total delivery deadline in seconds (1–60)")
                command.add_argument("--mode", choices=("steer", "defer"), default="steer",
                                     help="Enter for steering, or Tab for deliberate next-turn deferral")
                command.add_argument("--envelope", action="store_true",
                                     help="opt in: store the exact text in a private content-addressed file and type only a short one-row pointer, so a long message needs no wrapped-draft proof")
                command.add_argument("--finish-staged", action="store_true",
                                     help="finish an exact earlier staged message; provide its original body for proof, never repaste it")
                command.add_argument("--previous-completed-suggestion-id", type=delivery_message_id,
                                     help="authorize a named faint Claude suggestion only with matching same-source private submitted receipts")
            else:
                command.add_argument("--submit", action="store_true",
                                     help="send a separate Enter after text; verify the result")
                command.add_argument("--allow-command", action="store_true",
                                     help="explicitly allow leading / or ! client commands")
        elif name == "key":
            command.add_argument("key", choices=KEYS)
        else:
            command.add_argument("--agent", required=True, choices=AGENTS)
            command.add_argument("--cwd", required=True)
            command.add_argument("--title", required=True)
            command.add_argument("--model")
            command.add_argument("--reasoning-effort", choices=REASONING_EFFORTS,
                                 help="Codex only; pass this exact requested effort, without model substitution")
            command.add_argument("--agent-arg", action="append", default=[],
                                 help="one explicit agent argv item; use --agent-arg=--flag")
            command.add_argument("--prompt", help="one line of initial task text, passed as "
                                 "the client's own launch prompt")
            command.add_argument("--resume", help="resume this session id of the client")
            command.add_argument("--coding-yolo", action="store_true",
                                 help="add the client's approval-skip flag when Kilix's "
                                      "coding-yolo setting is on (never otherwise)")
            command.add_argument("--trust-folder", action="store_true",
                                 help="record the client's trust for exactly --cwd first")
            command.add_argument("--dry-run", action="store_true")
            if name == "new-tab":
                command.add_argument("--grid", metavar="NAME",
                                     help="session grid to join (default agent-sessions); coding sessions "
                                          "join a grid unless --own-tab or the coding_session_grid setting is off")
                command.add_argument("--own-tab", action="store_true",
                                     help="open a tab of its own instead of joining a session grid")
            if name == "split":
                command.add_argument("--direction", choices=LOCATIONS, default="right")
                command.add_argument("--bias", type=float, default=50,
                                     help="percentage of anchor area allocated to the NEW pane")
    return result


def main(argv=None):
    args = parser().parse_args(argv)
    if args.action == "deliver":
        has_body = args.text is not None or args.file is not None
        if not has_body:
            parser().error("deliver requires --text or --file, including with --finish-staged")
        if args.previous_completed_suggestion_id is not None and (
                args.previous_completed_suggestion_id == args.message_id or
                args.mode != "steer" or args.finish_staged or
                not math.isfinite(args.timeout) or not 1 <= args.timeout <= 60):
            parser().error("completed-suggestion authorization requires a different prior ID and a fresh steer delivery")
    if args.action == "context":
        if args.expect_broker is not None and (not args.target or not BROKER.fullmatch(args.expect_broker)):
            parser().error("context --expect-broker requires --target and an exact broker identity")
        from agent_context import collect, encode
        result = collect(caller_pane=args.caller_pane, target=args.target,
                         expected=args.expect_broker)
        output = encode(result)
        print(output, end="")
        return 0 if json.loads(output)["status"] == "observed" else 1
    try:
        client = Client(args.caller_pane)
        if args.action == "list":
            result = {"schema": SCHEMA, "caller_pane": client.caller,
                      "panes": [describe(pane) for pane in client.snapshot()]}
        elif args.action == "dump":
            if not 1 <= args.lines <= 500:
                raise ControlError("--lines must be between 1 and 500")
            client.resolve(args.pane)
            output = client.run(["get-text", "--match", f"id:{args.pane}", "--extent", "screen"])
            print("\n".join(output.splitlines()[-args.lines:]))
            return 0
        elif args.action in ("new-tab", "split"):
            result = launch(client, args)
        elif args.action == "deliver":
            previous_deadline = getattr(client, "deadline", float("inf"))
            try:
                if args.previous_completed_suggestion_id is not None:
                    client.deadline = min(previous_deadline,
                                          time.monotonic() + args.timeout)
                    import agent_actions
                    source = agent_actions.current_cli_source_identity(client)
                    target = {"pane_id": args.pane, "broker": args.expect_broker}
                    args._previous_completed_suggestion_source_identity = source
                    args._previous_completed_suggestion_scope_verified = (
                        agent_actions.previous_completed_suggestion_scope(
                            client, args.previous_completed_suggestion_id, source, target))
                from agent_delivery import deliver
                result = deliver(client, args)
            finally:
                client.deadline = previous_deadline
            print(json.dumps(result, ensure_ascii=True))
            return 0 if result["delivery_verified"] else 1
        else:
            if args.action == "key":
                payload = KEYS[args.key]
            else:
                if args.file:
                    descriptor = os.open(args.file, os.O_RDONLY | os.O_NONBLOCK)
                    with os.fdopen(descriptor, "rb") as handle:
                        if not stat.S_ISREG(os.fstat(handle.fileno()).st_mode):
                            raise ControlError("input file must be a regular file")
                        data = handle.read(1025)
                    value = data.decode("utf-8")
                else:
                    value = args.text
                value = plain_text(value, "input")
                stripped = value.lstrip()
                if stripped and stripped[0] in "/!#" and not args.allow_command:
                    raise ControlError("input beginning with '/', '!' or '#' is a client command; "
                                       "pass --allow-command only when that command is intended")
                payload = value.encode("utf-8")
            client.input(args.pane, args.expect_broker, payload)
            if args.action == "send" and args.submit:
                time.sleep(0.3)
                client.input(args.pane, args.expect_broker, KEYS["enter"])
            result = {"schema": SCHEMA, "status": "request_sent", "pane_id": args.pane,
                      "delivery_verified": False, "completion_verified": False}
        print(json.dumps(result, ensure_ascii=True))
        return 0
    except (ControlError, OSError, ValueError, TypeError, KeyError) as exc:
        if args.action == "deliver":
            from agent_delivery import SCHEMA as delivery_schema
            print(json.dumps({"schema": delivery_schema, "message_id": args.message_id,
                "pane_id": args.pane, "status": "blocked", "delivery_verified": False,
                "acknowledgment_verified": False, "completion_verified": False,
                "verification": "codex-screen-v1", "duplicate": False,
                "error": str(exc)[:240],
                "retry": "reuse the same message ID; never blind-resend"}, ensure_ascii=True))
        else:
            print(f"kilix agent-control: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    # Delivery imports these primitives too. Keep one ControlError class when
    # this file is invoked as a script, so refused input still yields JSON.
    sys.modules["agent_control"] = sys.modules[__name__]
    raise SystemExit(main())
