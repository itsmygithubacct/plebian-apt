"""Bind a multiplexer build to its source and installed shared codec package."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys


def data(path, maximum=32*1024**2):
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        info = os.fstat(descriptor)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid not in (0, os.geteuid())
                or info.st_mode & 0o022 or not 0 <= info.st_size <= maximum):
            raise ValueError('shared native package contains an unsafe file')
        result = bytearray()
        while len(result) < info.st_size:
            block = os.read(descriptor, min(1024**2, info.st_size-len(result)))
            if not block:
                raise ValueError('shared native package file ended early')
            result.extend(block)
        after = os.fstat(descriptor)
        if os.read(descriptor, 1) or any(getattr(after,k) != getattr(info,k) for k in
                                      ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns','st_mode')):
            raise ValueError('shared native package changed during inspection')
        return bytes(result)
    finally:
        os.close(descriptor)


def package_plan(prefix, cflags, libs):
    prefix = Path(prefix)
    if not prefix.is_absolute() or prefix != prefix.resolve(strict=True):
        raise ValueError('shared native prefix must be canonical')
    record_bytes = data(prefix/'share/doc/kilix-encodec/native-package.json', 2*1024**2)
    record = json.loads(record_bytes)
    # v2 adds package/compiler/runtime provenance; its source binding and
    # member-byte contract are unchanged and must pass the same checks below.
    if (record['schema'] not in ('kilix.encodec.native-package/v1',
                                'kilix.encodec.native-package/v2')
            or any(record['build'].get(k) != v for k,v in {'ONNX':1,'CONTENT':1,'PREFIX':'/usr'}.items())
            or not all(re.fullmatch('[0-9a-f]{40}', record[k]) for k in ('source_commit','content_commit'))):
        raise ValueError('shared native package has no enabled source binding')
    members = record['files']
    if not isinstance(members,dict) or not 10 <= len(members) <= 64:
        raise ValueError('shared native package population differs')
    required = {'usr/lib/libkilix-encodec.so.0','usr/lib/pkgconfig/kilix-encodec.pc',
                'usr/include/kilix_encodec.h','usr/include/kilix_encodec_content.h',
                'usr/share/doc/kilix-encodec/content_bundle.receipt.json'}
    if not required <= set(members):
        raise ValueError('shared native package is incomplete')
    for name, entry in members.items():
        relative = Path(name)
        if (relative.as_posix() != name or relative.parts[:1] != ('usr',)
                or '..' in relative.parts or len(relative.parts)<2):
            raise ValueError('unsafe native package member name')
        path = prefix.joinpath(*relative.parts[1:])
        if path.parent != path.parent.resolve(strict=True):
            raise ValueError('native package member parent is a link')
        if 'link' in entry:
            if name != 'usr/lib/libkilix-encodec.so' or entry != {'link':'libkilix-encodec.so.0'} or os.readlink(path) != entry['link']:
                raise ValueError('native linker name differs')
        else:
            value = data(path)
            if len(value) != entry['bytes'] or hashlib.sha256(value).hexdigest() != entry['sha256']:
                raise ValueError('shared native package member differs')
    embedded = json.loads(data(prefix/'share/doc/kilix-encodec/content_bundle.receipt.json',2*1024**2))
    if embedded['content_commit'] != record['content_commit'] or embedded['bundle_sha256'] != record['content_bundle_sha256']:
        raise ValueError('embedded Content receipt differs from the native package')
    if any('\n' in value or '\r' in value for value in (cflags,libs)):
        raise ValueError('invalid native package compiler flags')
    return {'package_sha256':hashlib.sha256(record_bytes).hexdigest(),
            'source_commit':record['source_commit'], 'content_commit':record['content_commit'],
            'cflags':cflags,'libs':libs}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',required=True)
    parser.add_argument('--commit',required=True)
    parser.add_argument('--build-dir',required=True)
    parser.add_argument('--print-kind',choices=('serve','attach'))
    parser.add_argument('--timeout',type=int,default=240)
    args=parser.parse_args()
    try:
        if not re.fullmatch('[0-9a-f]{40}',args.commit) or not 1 <= args.timeout <= 240:
            raise ValueError('exact source commit and timeout 1..240 are required')
        from multiplexer_compile import build
        value=build(args,package_plan)
        if value:
            print(value)
        return 0
    except (OSError,ValueError,KeyError,TypeError) as error:
        print('kilix remote: shared EnCodec build prerequisites are unavailable: '+str(error),file=sys.stderr)
        print('Install the source-bound libkilix-encodec package with ORT API21, libsamplerate0-dev and libssl-dev through explicit system setup; then retry.',file=sys.stderr)
        return 1


if __name__=='__main__':
    sys.exit(main())
