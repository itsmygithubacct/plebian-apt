"""`kilix install` — one list of everything this system can install.

Two collections that were previously only reachable in different places: the
pinned content catalog (games and applications, installed and verified by
kilix-content) and the coding agents (installed by their vendors' own scripts,
updated by their own updaters). A user looking for "what can I put on this
machine" should not have to know which of those a thing belongs to.

Nothing is installed here that is not already installed somewhere else in the
stack. The catalog half calls the same `Installer` the Kilix 95 Start menu
calls, so a launch and a typed command cannot end up running different builds.
The agent half downloads the vendor script the rollout tool already pins,
checks its sha256, and only then executes that file. The URL and the pin are
printed first.

Drivers are the third kind, and the same rule holds: `kilix install
nvidia-driver` runs the Plebian-OS helper that owns that install rather than
reimplementing it here. The row only appears on a machine that has the hardware.

Runtimes are the fourth: not a program but the environment a subprocess needs.
`kilix install yolo` builds the virtualenv and fetches the weights that
kilix-nvr's detector runs in, and `kilix install yamnet` does the same for the
sound-event classifier — both link no ML library on purpose, and this is what
turns that from a limitation into a one-line install.

Soundbanks are the fifth kind. They are optional, pinned data for an installed
application, with download and normalized disk sizes visible before the user
opts in. Kilix Techno remains usable with native fallback synthesis when none
are installed.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from kilix_sdk import content, paths  # noqa: E402
import content_app  # noqa: E402
import techno_soundbanks  # noqa: E402
import agent_skills  # noqa: E402
import agent_updates  # noqa: E402
# The same PATH/prefix resolver serves installation and pane launching.
from agent_programs import (  # noqa: E402
    resolve_agent_command as _resolve_agent_command,
    AGENT_PREFIX_BINDIRS as _AGENT_PREFIX_BINDIRS,
)

# The desktop's games module already owns catalog installation: which root a
# kind installs under, the recorded install directory, the readiness check and
# the build. Driving it is what keeps a `kilix install` and a Start-menu launch
# on one implementation instead of two that drift.
_DESKTOP = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "desktop")
if _DESKTOP not in sys.path:
    sys.path.insert(0, _DESKTOP)
try:
    import games as _games                      # noqa: E402
except Exception:                               # noqa: BLE001
    _games = None

def _providers_from_rollout():
    """The agent definitions from kilix-rollout, when that checkout is present.

    Those are the authoritative ones: the rollout-resume tool installs, updates
    and resumes each agent, so it is the thing that has to be right about their
    commands.

    The utilities are not an optional extra — Kilix installs them itself
    (`scripts/install-kilix-tui-utils.sh`, which Kilix calls for the TUI
    desktop and the tmux manager, and which `pleb install` runs), so on any
    provisioned system this import is the normal path. The copy below covers
    the window before that installer has run, not a machine that will never
    have them.

    `KILIX_TUI_UTILS_DIR` is the installer's own override and is honoured
    first; otherwise the default location it clones into is searched. Guessing
    only the default would silently fall back to the local copy on a system
    whose checkout was relocated.
    """
    # The default is the launcher's own GPU_TERMINAL_SOURCE_HOME default, where
    # the installer clones. ~/gpu_terminal was searched here too; it holds
    # development checkouts, and one with unpinned `curl | bash` installers
    # made the fallback test fail wherever it existed (2026-09-29).
    source = os.environ.get("GPU_TERMINAL_SOURCE_HOME") or os.path.join(
        os.environ.get("GPU_TERMINAL_HOME")
        or os.path.join(os.path.expanduser("~"), ".local", "gpu_terminal"),
        "sources")
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    roots = []
    if configured := os.environ.get("KILIX_TUI_UTILS_DIR"):
        roots.append(os.path.join(configured, "src"))
    for base in (source, os.path.dirname(os.path.dirname(here))):
        if base:
            roots.append(os.path.join(base, "kilix-desktops", "kilix-tui-utils",
                                      "src"))
    for root in roots:
        candidate = os.path.join(root, "kilix_rollout", "providers.py")
        if not os.path.isfile(candidate):
            continue
        if root not in sys.path:
            sys.path.insert(0, root)
        try:
            from kilix_rollout import providers
        except Exception:                        # noqa: BLE001
            return None
        # A copy whose installers are not digest-pinned predates the pins and
        # must not replace the pinned fallback below.
        if not all(getattr(item, "install_sha256", "") for item in providers.PROVIDERS):
            return None
        return tuple({
            "id": item.key,
            "label": item.label,
            "kind": "agent",
            "command": item.command,
            "install": item.install_shell,
            "install_url": getattr(item, "install_url", ""),
            "install_sha256": getattr(item, "install_sha256", ""),
            "install_interpreter": getattr(item, "install_interpreter", ""),
            "update": tuple(item.update_argv),
            "source": item.install_source,
        } for item in providers.PROVIDERS)
    return None


# Fallback definitions, used only when the utilities are not installed. They
# drifted from the authoritative copy once already — Kimi updates with
# `upgrade`, not `update` — which is why the import above is tried first.
# Digests of the vendor bootstrap scripts fetched 2026-09-25. The same pins
# live on kilix_rollout.Provider. A script that still downloads a moving
# "latest" payload is a narrower hole than piping an unpinned bootstrap.
_FALLBACK_AGENTS = (
    {
        "id": "claude",
        "label": "Claude Code",
        "kind": "agent",
        "command": "claude",
        "install_url": "https://claude.ai/install.sh",
        "install_sha256": "3a68d3406cf674e17bed1733a4dcf37805e2e47d87417700007d7e1aa766a944",
        "install_interpreter": "bash",
        "install": "bash https://claude.ai/install.sh (sha256 3a68d3406cf674e17bed1733a4dcf37805e2e47d87417700007d7e1aa766a944)",
        "update": ("claude", "update"),
        "source": "https://code.claude.com/docs/en/quickstart",
    },
    {
        "id": "codex",
        "label": "Codex",
        "kind": "agent",
        "command": "codex",
        "install_url": "https://chatgpt.com/codex/install.sh",
        "install_sha256": "150e3cf675682efeaac115aa3747add3f27887896d04ce6d0b56478d8b428bf6",
        "install_interpreter": "sh",
        "install": "sh https://chatgpt.com/codex/install.sh (sha256 150e3cf675682efeaac115aa3747add3f27887896d04ce6d0b56478d8b428bf6)",
        "update": ("codex", "update"),
        "source": "https://developers.openai.com/codex/cli/",
    },
    {
        "id": "kimi",
        "label": "Kimi Code",
        "kind": "agent",
        "command": "kimi",
        "install_url": "https://code.kimi.com/kimi-code/install.sh",
        "install_sha256": "270a86f2d2304529b6d8a3783fca9534874ebaeecb6cfcc1aebcdb6ce20ae1d7",
        "install_interpreter": "bash",
        "install": "bash https://code.kimi.com/kimi-code/install.sh (sha256 270a86f2d2304529b6d8a3783fca9534874ebaeecb6cfcc1aebcdb6ce20ae1d7)",
        "update": ("kimi", "upgrade"),
        "source": "https://moonshotai.github.io/kimi-code/",
    },
)

AGENTS = _providers_from_rollout() or _FALLBACK_AGENTS
# Grok's installed client provides its own updater. Bootstrap installation is
# deliberately separate until its installer is pinned in the provider catalog.
if not any(agent['id'] == 'grok' for agent in AGENTS):
    AGENTS += ({'id': 'grok', 'label': 'Grok', 'kind': 'agent', 'command': 'grok',
                'install': 'Update an existing installation with kilix install --update grok',
                'update': ('grok', 'update'), 'source': 'grok update --help'},)

# Hardware drivers that are a deliberate opt-in rather than part of the image.
# The install itself belongs to Plebian-OS — its helper preflights the machine,
# picks the package with nvidia-detect, builds via DKMS and refuses hardware too
# old for any driver Debian still ships. Reimplementing any of that here would
# be a second opinion on a question that already has an owner.
DRIVERS = (
    {
        "id": "nvidia-driver",
        "label": "NVIDIA driver",
        "helper": "plebian-os-nvidia-driver",
        "description": "Proprietary NVIDIA driver — CUDA, NVENC/NVDEC, full clocks",
    },
)


# Runtimes are the fourth kind, and the newest.  A component installs a
# program; a runtime installs the *environment a subprocess needs* — the
# virtualenv and weights kilix-nvr's detector runs in, which the recorder
# deliberately does not link.  That design makes where inference happens a
# launch detail, and its cost is a fresh machine whose recorder cannot detect
# anything with no obvious way to fix it.  This row is the obvious way.
RUNTIMES = (
    {
        "id": "yolo",
        "label": "YOLO object detection",
        "helper": "install-yolo.sh",
        "directory": os.path.join("runtimes", "yolo"),
        "directory_env": "KILIX_YOLO_DIR",
        "command": "kilix-look-detect",
        "description": "Ultralytics YOLO26 in its own virtualenv — what "
                       "kilix-nvr detects people and vehicles with",
    },
    {
        "id": "yolox",
        "label": "YOLOX object detection",
        "helper": "install-yolox.sh",
        "directory": os.path.join("runtimes", "yolox"),
        "directory_env": "KILIX_YOLOX_DIR",
        "command": "kilix-yolox-detect",
        "description": "Apache-2.0 YOLOX on onnxruntime in its own virtualenv — "
                       "the detector to use in anything redistributed",
    },
    {
        "id": "yamnet",
        "label": "YAMNet sound events",
        "helper": "install-yamnet.sh",
        "directory": os.path.join("runtimes", "yamnet"),
        "directory_env": "KILIX_YAMNET_DIR",
        "command": "kilix-listen-classify",
        "description": "YAMNet sound runtime — what kilix-listen and "
                       "kilix-nvr recognise barking, speech and glass with",
    },
)


def _runtime_paths(runtime: dict) -> tuple[str, str]:
    """The runtime's directory and the command it installs."""
    root = os.environ.get("GPU_TERMINAL_DATA_HOME") or os.path.join(
        os.path.expanduser("~"), ".local", "gpu_terminal")
    # Each runtime names its own override rather than sharing one: two
    # runtimes reading KILIX_YOLO_DIR would put the sound model wherever
    # somebody had redirected the detector.
    directory = os.environ.get(runtime["directory_env"]) or os.path.join(
        root, runtime["directory"])
    return directory, os.path.join(directory, "bin", runtime["command"])


def _runtime_rows() -> list[dict]:
    rows = []
    for runtime in RUNTIMES:
        directory, command = _runtime_paths(runtime)
        # A file check, not a `--check` run: the helper's own check imports
        # torch, which takes seconds, and this list is drawn every time
        # somebody opens the software centre.  The wrapper is written last
        # by the installer, after the model has been loaded once, so its
        # presence means the whole install succeeded.
        rows.append({
            "id": runtime["id"],
            "label": runtime["label"],
            "kind": "runtime",
            "description": runtime["description"],
            "installed": os.access(command, os.X_OK),
            "path": command if os.access(command, os.X_OK) else "",
        })
    return rows


def _runtime(identifier: str) -> dict | None:
    for runtime in RUNTIMES:
        if runtime["id"] == identifier:
            return runtime
    return None


def _runtime_helper(runtime: dict) -> str:
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(
        __file__))), "scripts", runtime["helper"])


def _soundbank(identifier: str) -> dict | None:
    return techno_soundbanks.by_id(identifier)


def _soundbank_helper() -> str:
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(
        __file__))), "scripts", "install-kilix-techno-soundbank.py")


def _install_soundbank(soundbank: dict, *, assume_yes: bool) -> int:
    helper = _soundbank_helper()
    if not os.access(helper, os.X_OK):
        print(f"kilix install: {helper} is missing or not executable",
              file=sys.stderr)
        return 2
    argv = [helper, "--install", soundbank["id"]]
    if assume_yes:
        argv.append("--yes")
    print(f"{soundbank['label']} installs with:")
    print(f"    {' '.join(argv)}")
    return subprocess.run(argv, check=False).returncode


def _install_runtime(runtime: dict, *, assume_yes: bool) -> int:
    helper = _runtime_helper(runtime)
    if not os.access(helper, os.X_OK):
        print(f"kilix install: {helper} is missing from this checkout",
              file=sys.stderr)
        return 2
    argv = [helper, "--install"]
    if assume_yes:
        argv.append("--yes")
    # Shown before it runs, like the agents: this one downloads hundreds of
    # megabytes and the helper says how many before asking.
    print(f"{runtime['label']} installs with:")
    print(f"    {' '.join(argv)}")
    return subprocess.run(argv, check=False).returncode


def _update_runtime(runtime: dict) -> int:
    helper = _runtime_helper(runtime)
    directory, command = _runtime_paths(runtime)
    if not os.access(command, os.X_OK):
        print(f"kilix install: {runtime['label']} is not installed yet — "
              f"`kilix install {runtime['id']}` first", file=sys.stderr)
        return 2
    print(f"{runtime['label']} updates in place at {directory}:")
    print(f"    {helper} --upgrade")
    return subprocess.run([helper, "--upgrade"], check=False).returncode


def _nvidia_gpu_present() -> bool:
    """True when this machine has an NVIDIA display device.

    Matched on the display class specifically: an NVIDIA GPU also presents an
    audio function for HDMI/DisplayPort sound, which reports the same vendor.
    """
    lspci = shutil.which("lspci")
    if not lspci:
        return False
    try:
        result = subprocess.run([lspci], capture_output=True, text=True, check=False)
    except Exception:                            # noqa: BLE001
        return False
    for line in result.stdout.splitlines():
        low = line.lower()
        if "nvidia" in low and ("vga" in low or "3d controller" in low):
            return True
    return False


def _nvidia_driver_loaded() -> bool:
    """True when the proprietary module is the one actually loaded."""
    try:
        with open("/proc/modules", "r", encoding="utf-8") as handle:
            return any(line.startswith("nvidia ") for line in handle)
    except OSError:
        return False


def _driver_rows() -> list[dict]:
    # A machine with no NVIDIA card has nothing to decide here, so the row is
    # absent rather than listed-and-inapplicable. The Start menu and the TUI
    # render whatever this returns, so an empty list is how they stay clean too.
    if not _nvidia_gpu_present():
        return []
    rows = []
    for driver in DRIVERS:
        helper = shutil.which(driver["helper"])
        rows.append({
            "id": driver["id"],
            "label": driver["label"],
            "kind": "driver",
            "description": driver["description"],
            "installed": _nvidia_driver_loaded(),
            "path": helper or "",
        })
    return rows


def _catalog_installed(entry) -> bool:
    """Read installed state from the owner of each catalog content kind."""
    if entry.source_type == "system":
        try:
            plan = content.application_plan(
                entry.content_id,
                catalog=content.default_catalog(),
                launcher=os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    "kilix",
                ),
            )
        except Exception:                         # noqa: BLE001
            return False
        command = plan.argv[0]
        if os.path.isabs(command):
            return os.path.isfile(command) and os.access(command, os.X_OK)
        return bool(shutil.which(command))
    if entry.kind in {"app", "tool"} and entry.source_type in {"git", "archive"}:
        root = os.path.join(paths.data_dir(), "desktop-apps")
        try:
            if not os.path.isdir(root):
                return entry.kind == "tool" and bool(content.Installer.system_converter(entry))
            return bool(content.Installer(root).ready(entry))
        except Exception:                          # noqa: BLE001
            return False
    if _games is not None:
        try:
            return bool(_games.game_ready(entry.content_id))
        except Exception:                         # noqa: BLE001
            return False
    return False


def _shared_application_states(catalog) -> dict[str, bool]:
    """Batch package-provided app readiness by shared install identity."""
    groups: dict[str, list] = {}
    for entry in catalog:
        if entry.kind == "app" and entry.source_type in {"git", "archive"}:
            groups.setdefault(entry.install_id, []).append(entry)
    if not groups:
        return {}
    root = os.path.join(paths.data_dir(), "desktop-apps")
    if not os.path.isdir(root):
        return {
            entry.content_id: False
            for entries in groups.values()
            for entry in entries
        }
    installer = content.Installer(root)
    states: dict[str, bool] = {}
    for entries in groups.values():
        try:
            readiness = installer.ready_provided(entries)
        except Exception:                         # noqa: BLE001
            readiness = {}
        states.update(
            (entry.content_id, bool(readiness.get(entry.content_id)))
            for entry in entries
        )
    return states


def _catalog_rows() -> list[dict]:
    try:
        catalog = content.default_catalog()
    except Exception as error:                  # noqa: BLE001 - reported, not raised
        return [{"error": str(error)}]
    rows = []
    shared_states = _shared_application_states(catalog)
    for entry in catalog:
        installed = (
            shared_states[entry.content_id]
            if entry.content_id in shared_states
            else _catalog_installed(entry)
        )
        rows.append({
            "id": entry.content_id,
            "label": entry.label,
            "kind": entry.kind,
            "description": entry.description,
            "installed": installed,
        })
    return rows


def _agent_rows() -> list[dict]:
    rows = []
    for agent in AGENTS:
        found = _resolve_agent_command(agent["command"])
        rows.append({
            "id": agent["id"],
            "label": agent["label"],
            "kind": "agent",
            "description": f"Coding agent — {agent['source']}",
            "installed": bool(found),
            "path": found or "",
        })
    return rows


def rows() -> list[dict]:
    """Everything installable, including optional application data."""
    return (_catalog_rows() + _agent_rows() + _runtime_rows() +
            techno_soundbanks.rows() + _driver_rows() + [{
                "id": "kilix-session", "label": "Kilix Session", "kind": "tool",
                "description": "Managed coding sessions, trust, logs and lifecycle (bundled with Kilix)",
                "installed": bool(_resolve_agent_command("kilix-session")),
            }])


def _agent(identifier: str) -> dict | None:
    for agent in AGENTS:
        if agent["id"] == identifier:
            return agent
    return None


def _driver(identifier: str) -> dict | None:
    for driver in DRIVERS:
        if driver["id"] == identifier:
            return driver
    return None


def install(identifier: str, *, assume_yes: bool = False) -> int:
    if identifier == "kilix-session":
        return subprocess.run([sys.executable, "-B", os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "scripts", "install-kilix-session.py")], check=False).returncode
    soundbank = _soundbank(identifier)
    if soundbank is not None:
        return _install_soundbank(soundbank, assume_yes=assume_yes)
    driver = _driver(identifier)
    if driver is not None:
        return _install_driver(driver, assume_yes=assume_yes)
    agent = _agent(identifier)
    if agent is not None:
        return _install_agent(agent, assume_yes=assume_yes)
    runtime = _runtime(identifier)
    if runtime is not None:
        return _install_runtime(runtime, assume_yes=assume_yes)
    return _install_catalog(identifier)


def _install_driver(driver: dict, *, assume_yes: bool) -> int:
    if not _nvidia_gpu_present():
        print("kilix install: no NVIDIA GPU on this machine — nothing to install",
              file=sys.stderr)
        return 2
    helper = shutil.which(driver["helper"])
    if not helper:
        print(f"kilix install: {driver['helper']} is not on PATH. It ships with "
              "Plebian-OS; on another distribution, install the driver the way "
              "that distribution expects.", file=sys.stderr)
        return 2
    # The helper decides whether this install should happen at all: it refuses
    # hardware too old for any driver Debian still ships, rather than leaving a
    # machine whose X server will not start. It needs root and asks for its own
    # confirmation, and the command is printed before it runs.
    argv = ["sudo", helper, "--install"]
    if assume_yes:
        argv.append("--yes")
    print(f"{driver['label']} installs with the Plebian-OS helper:")
    print(f"    {' '.join(argv)}")
    print("    it preflights the machine, and refuses if the GPU is too old")
    print("    for any driver Debian still ships. A reboot is required after.")
    return subprocess.run(argv, check=False).returncode


def _fetch_pinned(url: str, digest: str, *, timeout: float = 60) -> bytes:
    """Download an installer and refuse it unless it matches digest."""
    expected = digest.lower()
    request = urllib.request.Request(url, headers={"User-Agent": "kilix-install"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = response.read()
    except (OSError, urllib.error.URLError) as error:
        raise RuntimeError(f"could not download {url}: {error}") from error
    actual = hashlib.sha256(payload).hexdigest()
    if actual != expected:
        raise RuntimeError(
            f"installer from {url} sha256 {actual} does not match pin {expected}")
    return payload


def _install_agent(agent: dict, *, assume_yes: bool) -> int:
    # The URL and the pin are shown before anything is fetched. The script is
    # then written to a file and executed. It is never handed to a shell as
    # text from the network.
    url = agent.get("install_url") or ""
    digest = agent.get("install_sha256") or ""
    interpreter = agent.get("install_interpreter") or ""
    print(f"{agent['label']} installs with the vendor's own script:")
    print(f"    {url}")
    print(f"    sha256 {digest}")
    print(f"    documented at {agent['source']}")
    if interpreter not in {"bash", "sh"} or len(digest) != 64 or not url:
        print(f"kilix install: {agent['label']} has no pinned installer.",
              file=sys.stderr)
        return 2
    if not assume_yes:
        try:
            answer = input("run it? [y/N] ").strip().lower()
        except EOFError:
            answer = ""
        if answer not in ("y", "yes"):
            print("cancelled.")
            return 1
    try:
        payload = _fetch_pinned(url, digest)
    except RuntimeError as error:
        print(f"kilix install: {error}", file=sys.stderr)
        return 1
    handle = tempfile.NamedTemporaryFile(
        prefix=f"kilix-{agent['id']}-install-", suffix=".sh", delete=False)
    path = handle.name
    try:
        handle.write(payload)
        handle.close()
        os.chmod(path, 0o700)
        status = subprocess.run([interpreter, path], check=False).returncode
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
    if status != 0:
        return status
    # The vendor script exiting 0 is its claim; whether the command actually
    # resolves is the fact. Verify, and when the binary landed at a known
    # prefix that PATH cannot see, say exactly that — a plain "installed"
    # followed by `command not found` in the next shell is how this class of
    # bug stayed invisible.
    resolved = _resolve_agent_command(agent["command"])
    if resolved is None:
        print(f"kilix install: the installer finished, but "
              f"`{agent['command']}` does not resolve on PATH or in "
              f"{', '.join(_AGENT_PREFIX_BINDIRS)} — read the installer "
              "output above for where it put things.", file=sys.stderr)
        return 1
    if shutil.which(agent["command"]) is None:
        print(f"{agent['label']} is installed at {resolved}, but that "
              "directory is not on this shell's PATH.")
        print("kilix pane shells put ~/.local/bin on PATH; open a new pane, "
              "or add the directory to PATH for this shell.")
        return 0
    print(f"{agent['label']} is installed: {resolved}")
    return 0


def _install_catalog(identifier: str) -> int:
    try:
        spec = content.verified_packaged_catalog().require(identifier)
    except Exception as error:                   # noqa: BLE001
        print(f"kilix install: {error}", file=sys.stderr)
        return 2
    print(f"installing {spec.label} ({spec.kind})")
    try:
        if spec.kind in {"app", "tool"} and spec.source_type in {"git", "archive"}:
            content_app.ensure_application(spec, install=True)
        elif spec.kind == "app" and spec.source_type == "system":
            if not _catalog_installed(spec):
                raise RuntimeError("its system command is not installed")
        elif _games is not None:
            _games.ensure(identifier)
        else:
            raise RuntimeError("the desktop content module is unavailable")
    except SystemExit as error:
        print(f"kilix install: {error}", file=sys.stderr)
        return 1
    except Exception as error:                   # noqa: BLE001
        print(f"kilix install: {spec.label}: {error}", file=sys.stderr)
        return 1
    print(f"{spec.label} is installed.")
    return 0


def update(identifier: str) -> int:
    if identifier == "kilix-session":
        return install(identifier, assume_yes=True)
    soundbank = _soundbank(identifier)
    if soundbank is not None:
        return _install_soundbank(soundbank, assume_yes=True)
    driver = _driver(identifier)
    if driver is not None:
        return _update_driver(driver)
    runtime = _runtime(identifier)
    if runtime is not None:
        return _update_runtime(runtime)
    agent = _agent(identifier)
    if agent is None:
        # Catalog content is pinned; "updating" it means installing the pin the
        # current Kilix carries, which is what ensure() already does.
        return _install_catalog(identifier)
    command = _resolve_agent_command(agent["command"])
    if not command:
        print(f"{agent['label']} is not installed", file=sys.stderr)
        return 1
    return agent_updates.update(agent, command)


def _update_driver(driver: dict) -> int:
    """A packaged driver has no separate updater — apt is its updater.

    Saying so is more useful than inventing an action: system upgrades carry
    new driver versions, and DKMS rebuilds the module on each kernel upgrade
    without being asked. Report the current state instead of pretending.
    """
    helper = shutil.which(driver["helper"])
    print(f"{driver['label']} is an apt package: system upgrades carry new")
    print("versions, and DKMS rebuilds its module on every kernel upgrade.")
    if not helper:
        return 0
    print(f"\ncurrent state ({helper} --status):")
    return subprocess.run([helper, "--status"], check=False).returncode


def _print_table(entries: list[dict]) -> None:
    width = max((len(r.get("id", "")) for r in entries), default=2)
    kinds = ("agent", "app", "game", "runtime", "soundbank", "driver", "tool")
    for kind in kinds:
        group = [r for r in entries if r.get("kind") == kind]
        if not group:
            continue
        print(f"\n{kind}s")
        for row in sorted(group, key=lambda r: r["label"].lower()):
            mark = "installed" if row.get("installed") else ""
            size = row.get("size", "")
            detail = " · ".join(part for part in (mark, size) if part)
            print(f"  {row['id']:<{width}}  {row['label']:<34} {detail}")
    print("\ninstall one with:  kilix install <id>")
    print("update one with:   kilix install --update <id>")
    print("include bundled skills:  kilix install <codex|claude|kimi> --skills")


def main(argv: list[str]) -> int:
    args = list(argv)
    as_json = "--json" in args
    assume_yes = "--yes" in args or "-y" in args
    do_update = "--update" in args
    with_skills = "--skills" in args
    args = [a for a in args if a not in ("--json", "--yes", "-y", "--update",
                                         "--list", "--skills")]
    if with_skills and (len(args) != 1 or args[0] not in agent_skills.AGENTS):
        print("kilix install: --skills requires exactly one coding agent",
              file=sys.stderr)
        return 2
    entries = rows()
    failure = next((r for r in entries if "error" in r), None)
    if failure is not None:
        print(f"kilix install: {failure['error']}", file=sys.stderr)
        return 2
    if not args:
        if as_json:
            print(json.dumps(entries, indent=2))
        else:
            _print_table(entries)
        return 0
    if do_update:
        # Validate the entire selection before updating any client.
        known = {r['id'] for r in entries}
        if any(item not in known for item in args) or (len(args) > 1 and
                any(_agent(item) is None for item in args)):
            print('kilix install: select known coding agents for a batch update', file=sys.stderr)
            return 2
        results = []
        for identifier in dict.fromkeys(args):
            try:
                status = update(identifier)
            except KeyboardInterrupt:
                print('\nAgent updates interrupted; remaining clients were not updated.')
                return 130
            except (OSError, ValueError) as error:
                print(f'{identifier}: {error}', file=sys.stderr)
                status = 1
            results.append((identifier, status))
        for identifier, status in results:
            print(f'{identifier}: '+('updated' if status == 0 else f'failed (exit {status})'))
        if len(results) == 1:
            status = results[0][1]
            if status == 0 and with_skills:
                return agent_skills.main(['install', '--agent', args[0]])
            return status
        return 0 if all(status == 0 for _, status in results) else 1
    if len(args) != 1:
        print('kilix install: install one item at a time', file=sys.stderr)
        return 2
    identifier = args[0]
    known = {r["id"] for r in entries}
    if identifier not in known:
        print(f"kilix install: unknown item: {identifier}", file=sys.stderr)
        print("run `kilix install` for the list", file=sys.stderr)
        return 2
    result = update(identifier) if do_update else install(identifier,
                                                         assume_yes=assume_yes)
    if result == 0 and with_skills:
        # An explicit second setup step, also available without a vendor install
        # via `kilix skills install`. Failure leaves the installed agent intact.
        return agent_skills.main(["install", "--agent", identifier])
    return result


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
