"""Complete admission for the five-tool local model contract.

The original request supplies every argument. Model proposals must match the
complete reading, including order, literal payloads and host-owned defaults.
This module never executes a command or installs an application. Its only
filesystem access is a stat that tells whether an unquoted spaced path exists.
"""
import contextvars
from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import unicodedata

import agents
import apps


@dataclass(frozen=True)
class Admission:
    job: str | None
    actions: tuple = ()
    reason: str = ""


TOOLS = json.loads(Path(__file__).with_name('commands-tools.json').read_text())
_SCHEMAS = {tool['name']: tool['parameters'] for tool in TOOLS}
_PROPERTIES = {name: set(schema['properties']) for name, schema in _SCHEMAS.items()}
_REQUIRED = {name: set(schema.get('required', ())) for name, schema in _SCHEMAS.items()}
_APPS = set(_SCHEMAS['open_app']['properties']['app']['enum'])
_APP_WORDS = {"pdf viewer":"kilix-pdf", "pdf reader":"kilix-pdf",
              "calculator":"kilix-calculator", "notepad":"kilix-notepad",
              "file manager":"kilix-file", **{x:x for x in _APPS}}
_NOUN = "(?:" + "|".join(map(re.escape, sorted(_APP_WORDS, key=len, reverse=True))) + ")"
_PATH = r'(?:"(?:[^"\\]|\\.)+"|~?/[^\s;?]+)'
_PREAMBLE = re.compile(r"^(?:please\s+)?(?:(?:can|could|would|will)\s+you\s+(?:please\s+)?|"
                       r"I\s+(?:want|need|would like)\s+(?:you\s+)?to\s+|I['’]d\s+like\s+(?:you\s+)?to\s+)?", re.I)
_LAUNCH_VERB = r'(?:start(?: up)?|launch|open|run|bring up|get(?: me)?|create|fire up|spin up|kick off)'
_SEPARATOR = re.compile(r";\s*(?:(?:then|next|also|after that|afterwards)\s*,?\s+)?|"
                        r",\s*(?=(?:open|launch|start|bring|show|get|wait|tell|send|message)\b)|"
                        r",?\s+(?:and\s+then|and|then)\s+", re.I)
_DIRECTORY = r'(?:"(?:[^"\\]|\\.)+"|~?/[^\s;,?]+)'
_LOCATION = re.compile(r'\b(?:working\s+)?(?:in|at|inside|within)\s+(?P<path>'+_DIRECTORY+r')|'
                       r'\bwith\s+(?P<working>'+_DIRECTORY+r')\s+as\s+(?:(?:its|the)\s+)?working\s+directory|'
                       r'\b(?P<here>here|in (?:the )?(?:current directory|current folder|this folder|this directory))\b', re.I)
# Models the compact contract admits for each agent (see _canonical).
_MODELS = {'start_claude': ('sonnet', 'opus'), 'start_codex': ('gpt-6.1-sol', 'gpt-6')}
_MODEL_NAME = r'[A-Za-z0-9][A-Za-z0-9._/-]*'
_MODEL = re.compile(r'(?:\b(?:with\s+model|using(?:\s+model)?|on\s+model)\s+|'
                    r'\bmodel\s*=\s*|\bmodel\s+|(?<!\S)--model(?:=|\s+))('+_MODEL_NAME+r')\b', re.I)
_PLACEMENTS = [
    ('right', r'(?:in\s+)?(?:a\s+)?split\s+(?:to\s+)?(?:the\s+|my\s+)?right|(?:on|to)\s+(?:the\s+|my\s+)?right'),
    ('left', r'(?:in\s+)?(?:a\s+)?split\s+(?:to\s+)?(?:the\s+|my\s+)?left|(?:on|to)\s+(?:the\s+|my\s+)?left'),
    ('up', r'(?:in\s+)?(?:a\s+)?split\s+(?:above(?:\s+(?:me|this pane|the current pane))?|up)|above\s+(?:me|this pane|the current pane)'),
    ('down', r'(?:in\s+)?(?:a\s+)?split\s+(?:below(?:\s+(?:me|this pane|the current pane))?|down)|below\s+(?:me|this pane|the current pane)'),
    ('tab', r'(?:in\s+)?(?:a\s+)?(?:(?:new|fresh)\s+)?tab'),
]
# Trailing idle wording on a launch that captured no task. A removed field leaves
# a NUL gap, and these clauses do not cross it. A task plus one of them is said
# both ways and is not a reading.
_COMPACT_NO_TASK = re.compile(
    r'(?:\s+with\s+no\s+task\b(?:\s+or\s+(?:initial\s+)?prompt\b)?'
    r'|(?:[;,.]\s*|\s+)leave\s+the\s+session\s+open\b)\s*[.!]?\s*$',
    re.I)
_CLAUDE_CODE_NOUN = re.compile(
    r'\s+(?:(?:kilix\s+)?pane|(?:coding\s+)?(?:client|session|workspace|agent|instance|worker))\b',
    re.I)
# Owner decision 2026-11-07: an unquoted path may contain single spaces. Words
# after a path cannot be told apart from a task, a courtesy or a second sentence
# ("in ~/proj fix the tests"), so a spaced reading is taken only when that exact
# path exists: a directory for an agent, a file for the PDF viewer. The longest
# existing reading wins, and the words after it are parsed as before. This is
# the only filesystem access here: a stat, never a create, open or listing.
_SPACED_WORD = re.compile(r' [^\s;,?:="\'\\/~\-][^\s;,?:="\\]*')


def _path_exists(path, *, directory):
    """Whether an absolute or home path names an existing directory or file."""
    try:
        target = os.path.expanduser(path) if path.startswith('~/') else path
        if not target.startswith('/') or len(target.encode()) > 4096:
            return False
        return os.path.isdir(target) if directory else os.path.isfile(target)
    except (OSError, ValueError):
        return False


# One reading of a request at a time: which existing path to take when two
# readings of the same unquoted path both exist (see exact_calls).
_PATH_CHOICE = contextvars.ContextVar('_PATH_CHOICE', default=None)


def _spaced_words(tail):
    """The single-spaced words directly after an unquoted path."""
    words = []
    match = _SPACED_WORD.match(tail)
    while match:
        words.append(match[0])
        match = _SPACED_WORD.match(tail, match.end())
    return words


def _literal(raw, *, sentence_end=False):
    try:
        if raw.startswith('"'):
            return json.loads(raw)
        # Outside quotes a final full stop/exclamation mark ends the sentence.
        # Preserve dot path components; quote a filename ending in punctuation.
        return re.sub(r'(?<=[^/.!])[.!]$', '', raw) if sentence_end else raw
    except ValueError:
        return None


def _without_idle_clause(text):
    """Drop a trailing idle clause. The flag is true when at least one was removed."""
    removed = False
    for _ in range(4):
        shorter = _COMPACT_NO_TASK.sub('', text)
        if shorter == text:
            return text, removed
        text = shorter
        removed = True
    return text, removed


def _without_courtesy(text):
    """Remove complete courtesy suffixes outside literals, never message text."""
    while True:
        match = re.search(r',?\s+(?:for\s+me|please|now)[.!]?$', text, re.I)
        if not match or not _outside_quotes(text, match.start()):
            return text
        text = text[:match.start()]


def _take_location(text, gap=' ', *, sentence_end=False):
    matches = [m for m in _LOCATION.finditer(text) if _outside_quotes(text, m.start())]
    if len(matches) > 1:
        return None, None
    if not matches:
        return text, None
    match = matches[0]
    raw = match['path'] or match['working']
    end = match.end()
    if match['path'] and not raw.startswith('"'):
        words = _spaced_words(text[end:])
        found = []
        for count in range(len(words), 0, -1):
            extension = ''.join(words[:count])
            stop = end + len(extension)
            candidate = _literal(raw + extension,
                                 sentence_end=sentence_end and stop==len(text.rstrip()))
            if candidate and _path_exists(candidate, directory=True):
                found.append((raw + extension, stop))
        if found:
            # The path as written, without the spaced words, is the other reading
            # when it exists too ("~/proj new tab" beside a folder "~/proj new").
            base = _literal(raw, sentence_end=sentence_end and end==len(text.rstrip()))
            if base and _path_exists(base, directory=True):
                found.append((raw, end))
            choice = _PATH_CHOICE.get()
            if choice is not None and len(found) > 1:
                choice['ambiguous'] = True
            raw, end = found[-1] if choice is not None and choice['shortest'] else found[0]
    directory = _literal(raw, sentence_end=sentence_end and end==len(text.rstrip())) if raw else 'here'
    if not directory:
        return None, None
    return text[:match.start()] + gap + text[end:], directory


def _quoted_payload(text):
    """Decode an explicit quoted argument, never silently discard its tail."""
    try:
        value, end = json.JSONDecoder().raw_decode(text)
    except ValueError:
        return None
    if (not isinstance(value, str) or not value
            or not re.fullmatch(r'(?:exactly)?[.!]?', text[end:].strip(), re.I)):
        return None
    return value


def _payload(text, *, closed=False):
    """A complete quoted argument has a boundary; an unquoted tail does not."""
    quoted = _quoted_payload(text)
    if quoted is not None:
        return quoted
    if closed:
        return None
    if text.startswith('"'):
        # Preserve the existing literal colon form: '"words", please.'
        # Other text outside a quoted argument needs its own complete reading.
        try:
            value, end = json.JSONDecoder().raw_decode(text)
        except ValueError:
            return None
        if not isinstance(value, str) or not re.fullmatch(r',\s+please[.!]?', text[end:], re.I):
            return None
    return text


def _extended_agent_calls(request, *, closed_payload=False, _meta=None):
    """Parse explicit fields without normalizing the literal task or message.

    _meta, when given, receives how a launch was said, for the scope rules
    in _read_parts: whether its directory was fronted ("in /w, start ..."),
    whether it states a location of its own ("here" too, which the call
    omits), whether its own directory or placement follows its model (the model is
    inside the launch), and whether a comma sets the model off.
    """
    text = request.strip()
    preamble = _PREAMBLE.match(text)
    polite = bool(re.search(r'\b(?:can|could|would|will)\s+you\b', preamble[0], re.I))
    text = text[preamble.end():]
    text = re.sub(r'^I\s+need\s+a\s+(?:new|fresh)\s+(?=(?:claude|codex)\b)',
                  'start a new ', text, flags=re.I)
    if re.match(r'^a new (?:claude|codex) (?:session|agent)\b',text,re.I):
        text='start '+re.sub(r',?\s+please[.!]?$', '', text, flags=re.I)
    # A final question mark belongs to the polite request only when no payload
    # is present. Payload punctuation is preserved below.
    if polite and ':' not in text and text.endswith('?'):
        text = text[:-1].rstrip()
    front = re.match(r'^(?:in|at|inside|within)\s+(?P<path>'+_DIRECTORY+r'),\s*', text, re.I)
    front_directory = None
    if front:
        front_directory = _literal(front['path'])
        if not front_directory:return None
        text = text[front.end():]
    head = re.match(r'^'+_LAUNCH_VERB+r'\s+'
                    r'(?:one\s+)?(?:(?:a|an|the|new|fresh)\s+)*(?P<agent>claude|codex)\b'
                    r'(?:\s+(?:coding\s+)?(?:client|session|workspace|agent|instance|worker))?'
                    r'(?:\s+(?:running|started))?', text, re.I)
    if head:
        rest = text[head.end():]
        named_session = bool(re.search(
            r'\bthe\b|\b(?:client|session|workspace|agent|instance|worker|running|started)\b',
            head[0], re.I))
        # "claude code" is the product name. "code" is not part of the codex name,
        # and a following noun is still the session, not a task.
        if head['agent'].casefold() == 'claude':
            coded = re.match(r'\s+code\b', rest, re.I)
            if coded:
                rest = rest[coded.end():]
                noun = _CLAUDE_CODE_NOUN.match(rest)
                if noun:
                    rest = rest[noun.end():]
                running = re.match(r'\s+(?:running|started)\b', rest, re.I)
                if running:
                    rest = rest[running.end():]
                named_session = named_session or bool(noun or running)
        # Owner decision 2026-11-07: a bare direction directly after the agent and
        # directly before an explicit path is its placement: "start codex left in /x".
        # "right now" and "right here" are not placements, and "start claude up"
        # is the phrasal verb, so "up" is never a bare placement. After "the" or a
        # session noun the word may describe that session ("the Codex session left
        # in ~/proj"), so the request is refused.
        bare = re.match(r'\s+(right|left|down)(?=\s+(?:in|at|inside|within)\s+(?:"|~?/))', rest, re.I)
        bare_place = None
        if bare:
            if named_session:
                return None
            bare_place = bare[1].casefold()
            rest = ' \0' + rest[bare.end():]
        # A contract model name may follow the agent directly: "start codex gpt-6".
        named = re.match(r'\s+('+'|'.join(map(re.escape, _MODELS['start_'+head['agent'].casefold()]))+r')(?![\w.-])',
                         rest, re.I)
        if named:
            rest = ' --model '+named[1]+rest[named.end():]
        task = None
        quoted = re.search(r'\s+with\s+(?:this\s+)?(?:initial\s+)?(?:task|instruction)\s+(?=")', rest, re.I)
        if quoted and _outside_quotes(rest, quoted.start()):
            task = _quoted_payload(rest[quoted.end():])
            if task is None:return None
            rest = rest[:quoted.start()]
        markers = re.compile(r';\s*(?:initial\s+)?(?:task|instruction):\s*|'
                             r'\s+with\s+(?:this\s+)?(?:initial\s+)?(?:task|instruction):\s*|'
                             r':\s*|\s+and\s+(?:ask\s+it\s+to|give\s+it\s+this\s+task:)\s*|'
                             r'\s+to\s+', re.I)
        for marker in markers.finditer(rest):
            if not _outside_quotes(rest, marker.start()):continue
            # "to the right" is placement, not an initial task.
            tail = rest[marker.end():]
            if marker[0].strip().casefold()=='to' and re.match(r'(?:the |my )?(?:right|left)\b', tail, re.I):continue
            if task is not None:return None
            task = _payload(tail, closed=closed_payload)
            if task is None:return None
            rest = rest[:marker.start()]
            break
        without_courtesy = _without_courtesy(rest)
        sentence_end = task is None and without_courtesy == rest
        rest = without_courtesy
        # Removed spans leave a NUL gap that no model phrase can cross.
        # Requests never contain NUL: exact_calls refuses control characters.
        rest, directory = _take_location(rest, gap=' \0 ', sentence_end=sentence_end)
        if rest is None:return None
        located = directory is not None
        if front_directory is not None:
            if directory is not None:return None
            directory = front_directory
        args = {} if directory in (None,'here') else {'directory':directory}
        if task is not None:
            if not task or len(task.encode())>1024:return None
            args['task']=task
        for place, pattern in _PLACEMENTS:
            matches=list(re.finditer(r'\b(?:'+pattern+r')\b',rest.replace('\0',' '),re.I))
            if matches:
                if len(matches)!=1 or 'place' in args:return None
                match=matches[0];args['place']=place
                rest=rest[:match.start()]+' \0 '+rest[match.end():]
        if bare_place:
            if 'place' in args:return None
            args['place']=bare_place
        model = _MODEL.search(rest)
        inside = comma = False
        if model:
            args['model']=model[1]
            # A removed directory or placement after the model is the launch's own.
            inside = '\0' in rest[model.end():]
            comma = rest[:model.start()].replace('\0',' ').rstrip().endswith(',')
            rest=rest[:model.start()]+' '+rest[model.end():]
        rest, idle = _without_idle_clause(rest)
        if idle and task is not None:
            return None
        if rest.replace('\0',' ').strip(' ,.!'):return None
        if _meta is not None:
            _meta.update(front=front_directory is not None, located=located, inside=inside,
                         comma_model=comma and not inside)
        return [_call('start_'+head['agent'].casefold(),**args)]

    # A fronted location scopes one explicit launch, never an implicit action.
    if front:return None

    # Messages require a named agent; no pronoun or unnamed-session fallback.
    front = re.match(r'^(?:for|to)\s+(?:the\s+)?(?:running\s+|existing\s+)?(?P<agent>claude|codex)(?:\s+session)?\s+(?P<location>.+?),\s*send(?:\s+this\s+message)?:\s*',text,re.I)
    if front:
        rest,directory=_take_location(front['location'])
        if rest is not None and not rest.strip() and directory is not None:
            payload=_payload(text[front.end():], closed=closed_payload)
            if payload and len(payload.encode())<=1024:
                args={'agent':front['agent'].casefold(),'text':payload}
                if directory!='here':args['directory']=directory
                return [_call('message_agent',**args)]
        return None
    message = re.match(r'^(?:tell|message|ask|instruct|give|send|relay|pass)(?:\s+(?:this|the|following|exact|message|text|instruction|a|along))*'
                       r'(?:\s+to)?\s+(?:the\s+)?(?:running\s+|current\s+|existing\s+)?'
                       r'(?P<agent>claude|codex)\b(?:\s+session)?',text,re.I)
    if message:
        rest=text[message.end():]
        delimiter=re.compile(r'\s+with\s+this\s+exact\s+(?:text|message|instruction):\s*|'
                             r'\s+(?:with|saying|the following(?: instruction| text| message)?|this(?: exact)?(?: message| text| instruction)?):\s*|'
                             r'\s+(?:the|this)(?: exact)? (?:message|text|instruction)\s+(?=")|'
                             r':\s*|\s+to\s+',re.I)
        for marker in delimiter.finditer(rest):
            if not _outside_quotes(rest,marker.start()):continue
            prefix,directory=_take_location(rest[:marker.start()])
            if prefix is None or prefix.strip(' ,'):continue
            payload=rest[marker.end():]
            if marker[0].rstrip().endswith(('message', 'text', 'instruction')):
                payload = _quoted_payload(payload)
            else:
                payload = _payload(payload, closed=closed_payload)
            if not payload or len(payload.encode())>1024:return None
            args={'agent':message['agent'].casefold(),'text':payload}
            if directory not in (None,'here'):args['directory']=directory
            return [_call('message_agent',**args)]
        return None

    text = re.sub(r'^await\s+(?:the\s+)?end\s+of\s+(?:the\s+)?(claude|codex)\s+(?:current\s+)?turn\b',
                  r'wait for \1', text, flags=re.I)
    waiting=re.fullmatch(r'(?:wait(?:\s+(?:for|until|on))?|block until|hold(?:\s+(?:on|off))? until|pause until|let)\s+'
                         r'(?:the\s+)?(?:current\s+|running\s+|existing\s+)?(?P<agent>claude|codex)\b'
                         r'(?P<rest>.*)',text,re.I)
    if waiting:
        rest=waiting['rest']
        guard = re.search(r";\s*(?:do not|don['’]t)\s+(?:start|launch|open|create)\s+"
                          r"(?:(?:a\s+)?new|another)\s+(?:session|agent)[.!]?$", rest, re.I)
        if guard and _outside_quotes(rest, guard.start()):
            rest = rest[:guard.start()]
        rest=re.sub(r'^\s+(?:session|turn)\b','',rest,flags=re.I)
        without_courtesy = _without_courtesy(rest)
        sentence_end = guard is None and without_courtesy == rest
        rest,directory=_take_location(without_courtesy, sentence_end=sentence_end)
        if rest is None:return None
        tail=' '.join(rest.strip(' .!').casefold().split())
        if tail not in ('','is idle','is done','is finished','becomes idle','reaches idle',
                        'finishes','finishes its turn','finishes its current turn','to finish',
                        'to finish its turn','to finish its current turn','to become idle','to be idle',
                        'to complete its turn','completes its turn','completes its current turn','finish before continuing',
                        'finish before we continue','ends'):
            return None
        args={'agent':waiting['agent'].casefold()}
        if directory not in (None,'here'):args['directory']=directory
        return [_call('wait_for_agent',**args)]
    return None


def _call(name, **args):
    return {"name":name, "arguments":args}


def _app_calls(request):
    text = _without_courtesy(request.strip())
    sentence_end = text == request.strip()
    session = r'(?:\s+(?:in|for)\s+this\s+session)?'
    desired = re.fullmatch(r"(?:I would like|I['’]d like|I need|I want)\s+(?:the\s+)?("+_NOUN+
                           r")\s+(?:opened|launched|started)(?:\s+now)?"+session+r'[.!]?', text, re.I)
    if desired:
        return [_call('open_app', app=_APP_WORDS[desired[1].casefold()])]
    preamble = _PREAMBLE.match(text)
    polite = bool(re.search(r'\b(?:can|could|would|will)\s+you\b', preamble[0], re.I))
    text = text[preamble.end():]
    if text.endswith('?'):
        if not polite:return None
        text = text[:-1].rstrip()
    without_courtesy = _without_courtesy(text)
    sentence_end = sentence_end and without_courtesy == text
    text = without_courtesy
    text = re.sub(r'^bring\s+(?:the\s+)?('+_NOUN+r')\s+up$',r'bring up \1',text,flags=re.I)
    noun = re.fullmatch(r'(?:open|launch|start(?: up)?|bring up|show|get)\s+(?:the\s+)?('+_NOUN+r')(?:\s+application|\s+running|\s+open)?'+session+r'[.!]?', text, re.I)
    if noun:
        return [_call('open_app', app=_APP_WORDS[noun[1].casefold()])]
    shapes = [
        r'(?:open|load|show|view)\s+(?P<path>{path})\s+(?:in|with|using)\s+(?:the\s+)?PDF (?:viewer|reader)[.!]?',
        r'(?:use\s+)?(?:the\s+)?PDF (?:viewer|reader)\s+to\s+(?:open|load|show)\s+(?P<path>{path})[.!]?',
        r'open\s+(?P<path>{path})[.!]?',
        r'(?:launch|bring up|start)\s+(?:the\s+)?PDF (?:viewer|reader)\s+(?:with|for|and (?:load|show))\s+(?P<path>{path})[.!]?',
        r'(?:get\s+)?(?:the\s+)?PDF (?:viewer|reader)\s+to\s+(?:display|open|show)\s+(?P<path>{path})[.!]?',
        r'(?:display|show)\s+(?P<path>{path})\s+(?:in|with|using)\s+(?:the\s+)?PDF (?:viewer|reader)[.!]?',
    ]
    # An unquoted PDF path may hold single spaces when that exact file exists
    # (owner decision 2026-11-07). Single-word paths are tried first and keep
    # their reading.
    spaced = r'~?/[^\s;?"]+(?: [^\s;?"]+)+'
    for path_pattern, is_spaced in ((_PATH, False), (spaced, True)):
        for shape in shapes:
            matched = re.fullmatch(r'(?:'+shape.format(path=path_pattern)+r')[.!]?',text,re.I)
            if not matched:continue
            raw = matched['path']
            path = _literal(raw, sentence_end=sentence_end and matched.end('path')==len(text))
            if is_spaced and not (isinstance(path,str) and _path_exists(path, directory=False)):
                return None
            if (not isinstance(path,str) or not path.startswith(('/','~/'))
                    or not path.casefold().endswith('.pdf')
                    or any(unicodedata.category(ch) in ('Cc','Cf','Zl','Zp') for ch in path)):
                return None
            return [_call('open_app',app='kilix-pdf',file_path=path)]
    return None


def _outside_quotes(text, position):
    quote = None
    escaped = False
    for index, ch in enumerate(text[:position]):
        if escaped:escaped=False;continue
        if ch == '\\' and quote:escaped=True;continue
        if quote:
            if ch == quote:quote=None
        elif ch in ('"', "'"):
            if ch == "'" and index and text[index-1].isalnum() and text[index+1:index+2].isalnum():
                continue
            quote=ch
    return quote is None


def exact_calls(request, *, _depth=0, _bare=False):
    """A complete reading of supported actions, or None; no partial match.

    _bare: a launch earlier in the whole request states no model.
    """
    if _PATH_CHOICE.get() is not None:
        return _read_calls(request, _depth=_depth, _bare=_bare)
    # An unquoted spaced path takes its longest existing reading. When a shorter
    # existing path also reads the whole request, and the two readings differ,
    # the request is ambiguous and is refused; a reading only one of them
    # completes is that reading.
    choice = {'shortest': False, 'ambiguous': False}
    token = _PATH_CHOICE.set(choice)
    try:
        longest = _read_calls(request, _depth=_depth, _bare=_bare)
        if not choice['ambiguous']:
            return longest
        choice['shortest'] = True
        shortest = _read_calls(request, _depth=_depth, _bare=_bare)
    finally:
        _PATH_CHOICE.reset(token)
    if longest is None or shortest is None:
        return longest or shortest
    return longest if _canonical(longest) == _canonical(shortest) else None


def _read_calls(request, *, _depth=0, _bare=False):
    parts = _read_parts(request, _depth=_depth, _bare=_bare)
    return [call for call, _meta in parts] if parts else None


# A separator that ends a sentence or a step (";", "then") rather than joining
# a list ("," or "and"). A verbless launch after it is its own request, and a
# model set off by a comma after it cannot be shared with launches before it.
def _sequence(separator):
    return ';' in separator or separator.strip(' ,').casefold() == 'then'


# A right side that opens a new clause of its own: a request preamble
# ("please", "can you", "I'd like to") or "I need a new ...".
_OWN_CLAUSE = re.compile(r'(?:please|(?:can|could|would|will)\s+you|I\s+(?:want|need|would\s+like)|I[\'’]d\s+like)\b', re.I)
_GROUP_FIELDS = frozenset({'directory', 'place'})
_AGENT_CALLS = ('start_claude', 'start_codex', 'wait_for_agent', 'message_agent')


def _leaf(calls, meta=None):
    meta = meta or {}
    return [(call, {'shares': False, **meta}) for call in calls]


def _read_parts(request, *, _depth=0, _bare=False, _list_bare=False):
    """The reading as (call, meta) parts. meta['shares']: the call shares the
    verb of the call before it ("start codex and claude"); the other keys come
    from _extended_agent_calls.

    _bare: a launch earlier in the whole request states no model.
    _list_bare: a launch earlier in the same comma or "and" list states no model.
    """
    if (not isinstance(request,str) or not request.strip() or len(request)>2048 or _depth>3
            or any(unicodedata.category(ch) in ('Cc','Cf','Zl','Zp') for ch in request)):
        return None
    meta = {}
    found = _extended_agent_calls(request, _meta=meta) or _app_calls(request)
    # Fully matched actions without an open payload cannot swallow a clause.
    if found and (not any('task' in c['arguments'] or 'text' in c['arguments'] for c in found)
                  or _extended_agent_calls(request, closed_payload=True)):
        return _leaf(found, meta if len(found) == 1 else None)
    pair=re.fullmatch(r'give me\s+(claude|codex)\s+in\s+('+_DIRECTORY+r')\s+plus\s+(claude|codex)\s+in\s+('+_DIRECTORY+r')',request,re.I)
    if pair:
        first,second=_literal(pair[2]),_literal(pair[4], sentence_end=True)
        if first and second:
            return [(_call('start_'+pair[1].casefold(),directory=first), {'shares': False}),
                    (_call('start_'+pair[3].casefold(),directory=second), {'shares': True})]
    for separator in _SEPARATOR.finditer(request):
        if not _outside_quotes(request,separator.start()):continue
        left,right=request[:separator.start()].strip(),request[separator.end():].strip()
        left_meta = {}
        first=_extended_agent_calls(left, _meta=left_meta) or _app_calls(left)
        if not first:continue
        word = separator[0].strip(' ,').casefold()
        if (word=='and'
                and all(c['name'].startswith('start_') for c in first)
                and re.match(r'^(?:ask it to|give it this task:)\s+',right,re.I)):
            continue  # A task delimiter belonging to this launch, not a second action.
        if any('task' in x['arguments'] or 'text' in x['arguments'] for x in first):
            if not _extended_agent_calls(left, closed_payload=True):
                # A bare "wait" names no session and is not a Kilix action.
                # Keep it in literal messages such as 'say "ready" and wait'.
                # A named/qualified wait still follows the ambiguity guard.
                if re.fullmatch(r'wait[.!]?', right, re.I):
                    continue
                # With an unquoted payload, an apparent second instruction
                # could be data or a new action. Neither interpretation wins.
                if re.match(r'^(?:(?:please|then|next|also)\s+)*(?:'
                            r'open|launch|start|bring|show|get|wait|tell|send|message|ask|'
                            r'kick|run|create|delete|erase|remove|close|quit|reboot|'
                            r'do not|don[\x27’]t|if|unless)\b',right,re.I):
                    return None
                continue
        launches = all(c['name'].startswith('start_') for c in first)
        left_bare = any(x['name'].startswith('start_') and 'model' not in x['arguments'] for x in first)
        bare = _bare or left_bare
        sequence = _sequence(separator[0])
        list_bare = False if sequence else (_list_bare or left_bare)
        rest=_read_parts(right,_depth=_depth+1,_bare=bare,_list_bare=list_bare)
        shared_verb = (word in ('and', 'and then') and launches
                       and re.match(r'^(?:(?:a|an|the|new|fresh)\s+)*(?:claude|codex)\b',right,re.I))
        if (not rest and word in ('and', 'and then') and launches
                and re.match(r'^(?:claude|codex)\b', right, re.I)):
            rest=_read_parts('start '+right,_depth=_depth+1,_bare=bare,_list_bare=list_bare)
        if not rest or len(first)+len(rest)>4:
            return None
        rest = [(rest[0][0], {**rest[0][1], 'shares': bool(shared_verb)})] + rest[1:]
        lead = dict(first[0]['arguments'])
        group = 0       # how many calls of rest share the left launch's verb
        shared = False  # a directory reached the group by sharing
        if shared_verb:
            group = 1
            while group < len(rest) and rest[group][1]['shares']:
                group += 1
            # A field the left launch does not state may be meant for every
            # launch that shares the verb. Fields stated on both sides are
            # each launch's own.
            explicit_fields = set(lead)
            if any(_outside_quotes(left, m.start()) for m in _LOCATION.finditer(left)):
                explicit_fields.add('directory')  # An explicit "here" omits the call's default.
            members = [call['arguments'] for call, _meta in rest[:group]]
            extra = set().union(*(set(args) - explicit_fields for args in members))
            if not extra:
                pass
            elif (not explicit_fields and word == 'and' and members[0]
                    and set(members[0]) <= _GROUP_FIELDS
                    and all(args == members[0] for args in members)
                    and not re.search(r'\bas\s+its\s+working\s+directory\b', right, re.I)):
                # One directory or placement after a list of launches that share
                # a verb and state nothing else applies to all of them:
                # "start codex and claude in /w".
                lead = dict(members[0])
                shared = 'directory' in lead
            elif extra == {'model'} and all(
                    m.get('inside') for call, m in rest[:group] if 'model' in call['arguments']):
                # A model followed by the launch's own directory or placement,
                # of a kind the left launch also states, is that launch's own:
                # "start codex in /a and codex using gpt-6 in /b".
                pass
            else:
                return None
        if left_meta.get('front'):
            # "in /w, start codex and claude": a fronted directory scopes the
            # launches that share its verb when they state nothing themselves,
            # not even "here". Any other agent action after it must state its
            # own directory, since the fronted one may be meant for it too.
            for index, (call, m) in enumerate(rest):
                if call['name'] not in _AGENT_CALLS:
                    continue
                if index < group:
                    if word != 'and' or call['arguments'] or m.get('located'):
                        return None
                elif 'directory' not in call['arguments']:
                    return None
        if shared and any(call['name'] in ('wait_for_agent', 'message_agent')
                          and 'directory' not in call['arguments'] for call, _m in rest[group:]):
            # "start codex and claude in /w and wait for codex": the wait may be
            # meant for the codex just started in /w, as after a fronted one.
            return None
        first = [_call(first[0]['name'], **lead)] + first[1:]
        # Retain the integration base's model-scope guard across nested splits.
        head_call, head_meta = rest[0]
        own_clause = (sequence or re.match(_LAUNCH_VERB+r'\s',right[_PREAMBLE.match(right).end():],re.I)
                      or _OWN_CLAUSE.match(right))
        if (bare and not own_clause and 'model' in head_call['arguments']
                and not head_meta.get('inside')):
            return None
        # "start codex in /a, start codex in /b, model gpt-6": a model set off by
        # a comma at the end of a list may be meant for every launch in it.
        if list_bare and head_meta.get('comma_model') and 'model' in head_call['arguments']:
            return None
        if left_meta.get('front') and group:
            rest = [(_call(call['name'], **{**call['arguments'], 'directory': lead['directory']}), m)
                    if index < group else (call, m) for index, (call, m) in enumerate(rest)]
        return _leaf(first, left_meta) + rest
    return _leaf(found, meta if len(found) == 1 else None) if found else None


def _canonical(calls, cwd=None):
    if not isinstance(calls,list) or not 1<=len(calls)<=4:
        raise ValueError('calls must contain one to four operations')
    out=[]
    for call in calls:
        if not isinstance(call,dict) or set(call)!={'name','arguments'}:
            raise ValueError('invalid call object')
        name,args=call['name'],call['arguments']
        if not isinstance(name,str) or name not in _PROPERTIES or not isinstance(args,dict):
            raise ValueError('unknown operation or arguments')
        if (set(args)-_PROPERTIES[name] or _REQUIRED.get(name,set())-set(args)
                or any(not isinstance(v,str) or not v for v in args.values())):
            raise ValueError('unexpected, missing or non-string arguments')
        if any(unicodedata.category(ch) in ('Cc','Cf','Zl','Zp') for value in args.values() for ch in value):
            raise ValueError('control characters are not command arguments')
        args=dict(args)
        if name=='open_app':
            if args['app'] not in _APPS or ('file_path' in args and args['app']!='kilix-pdf'):
                raise ValueError('unknown application or incompatible file path')
        else:
            args.setdefault('directory','here')
            if args['directory']=='.':args['directory']='here'
            if cwd and args['directory']=='here':args['directory']=cwd
            if name.startswith('start_'):
                args.setdefault('place','tab')
                if args['place'] not in ('tab','right','left','up','down'):
                    raise ValueError('unknown placement')
                if 'model' in args and args['model'] not in _MODELS[name]:
                    raise ValueError('model outside the compact contract')
            elif args['agent'] not in ('claude','codex'):
                raise ValueError('unknown agent')
        out.append(_call(name,**args))
    return out


def admit(request, calls, *, cwd=None):
    wanted=exact_calls(request)
    if not wanted:return Admission(None,reason='the whole request has no supported reading')
    try:
        if _canonical(calls,cwd)!=_canonical(wanted,cwd):
            return Admission(None,reason='the operations or literal arguments differ from the request')
    except ValueError as error:return Admission(None,reason=str(error))
    actions=[];jobs=set()
    for c in wanted:
        name,args=c['name'],c['arguments']
        if name=='open_app':
            jobs.add('apps');actions.append(apps.Action('launch',dict(args)))
        elif name.startswith('start_'):
            jobs.add('agents')
            translated={'agent':name.removeprefix('start_'),'dir':args.get('directory','here')}
            translated.update({new:args[old] for old,new in [('place','place'),('task','prompt'),('model','model')] if old in args})
            actions.append(agents.Action('agent',translated))
        else:
            jobs.add('agents');translated={'session':args['agent']+'@'+args.get('directory','here')}
            if name=='wait_for_agent':translated['for']='idle';kind='wait'
            else:translated['text']=args['text'];kind='tell'
            actions.append(agents.Action(kind,translated))
    return Admission(next(iter(jobs)) if len(jobs)==1 else 'mixed',tuple(actions))
