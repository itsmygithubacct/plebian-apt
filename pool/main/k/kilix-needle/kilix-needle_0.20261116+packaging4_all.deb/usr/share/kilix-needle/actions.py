"""The tool set Needle sees, and what its calls are allowed to become.

Needle's confidence does not gate anything here. Measured on the pinned
engine, "close tab 2 and go to tab 1" produced two close_tab calls at
confidence 0.99 and "go to the left pane" produced close_pane at 0.41. So a
call becomes an action only through checks that do not depend on the model:

- a close needs a closing verb in the request, and typing a command needs a
  run/type verb;
- every free-text value must appear in the request (a program, name or
  command the user never said is refused, not guessed);
- the values are normalised to a small vocabulary before resolution.

Whether an admitted action then runs straight away or waits for a yes is
`Action.risky`, decided by kind and never by confidence.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import re
import unicodedata

SIDES = ("left", "right", "above", "below")
LAYOUTS = ("tall", "fat", "grid", "horizontal", "vertical", "splits", "stack")
DIRECTIONS = ("wider", "narrower", "taller", "shorter")


def inventory_unit(request: str) -> str | None:
    """Recognize a complete inventory request, including bare plural nouns."""
    match = re.fullmatch(
        r"\s*(?:(?:please|can you|could you|would you)\s+)*"
        r"(?:(?:list|show|get|enumerate)(?:\s+me)?\s+"
        r"(?:(?:all|the|my|open|existing|current|kilix)\s+)*|"
        r"(?:(?:all|the|my|existing|current|kilix)\s+)*)"
        r"(?P<unit>panes(?:\s+and\s+tabs)?|tabs(?:\s+and\s+panes)?)"
        r"(?:\s+please)?[\s.!?]*", request, re.I)
    return " ".join(match["unit"].lower().split()) if match else None


def _target(what: str, choices: str) -> dict:
    return {"type": "string", "description": f"{choices}, or the name or program of a {what}"}


TOOLS = [
    {"name": "open_pane",
     "description": "Split the window: open a new pane next to the current one. "
                    "Use for split, new pane, open X in a pane",
     "parameters": {"type": "object", "properties": {
         "side": {"type": "string", "enum": list(SIDES),
                  "description": "which side of the current pane"},
         "program": {"type": "string",
                     "description": "program to start in it, only if the user names one"},
         "name": {"type": "string",
                  "description": "what to call the pane, only if the user names it"}},
         "required": []}},
    {"name": "open_tab",
     "description": "Open a new tab. Use for new tab, open X in a tab",
     "parameters": {"type": "object", "properties": {
         "program": {"type": "string",
                     "description": "program to start in it, only if the user names one"},
         "name": {"type": "string",
                  "description": "what to call the tab, only if the user names it"}},
         "required": []}},
    {"name": "close_pane",
     "description": "Close, kill or quit a pane. Only when the user says close, kill, quit or exit",
     "parameters": {"type": "object", "properties": {
         "pane": _target("pane", "current, left, right, above, below")},
         "required": ["pane"]}},
    {"name": "close_tab",
     "description": "Close, kill or quit a tab. Only when the user says close, kill, quit or exit",
     "parameters": {"type": "object", "properties": {
         "tab": _target("tab", "current, a tab number")},
         "required": ["tab"]}},
    {"name": "go_to_pane",
     "description": "Go to, switch to, move to or focus another pane without changing it",
     "parameters": {"type": "object", "properties": {
         "pane": _target("pane", "left, right, above, below")},
         "required": ["pane"]}},
    {"name": "go_to_tab",
     "description": "Go to or switch to another tab without changing it",
     "parameters": {"type": "object", "properties": {
         "tab": _target("tab", "next, previous, a tab number")},
         "required": ["tab"]}},
    {"name": "arrange_panes",
     "description": "Rearrange the panes in this tab",
     "parameters": {"type": "object", "properties": {
         "layout": {"type": "string", "enum": list(LAYOUTS),
                    "description": "grid; stack shows one pane at a time; vertical is "
                                   "side by side; horizontal is one above another"}},
         "required": ["layout"]}},
    {"name": "rename_tab",
     "description": "Rename the requested tab; use 'tab id N' for a stable identity",
     "parameters": {"type": "object", "properties": {
         "name": {"type": "string", "description": "the new name"},
         "tab": {"type": "string", "description": "the requested tab, if explicit"}},
         "required": ["name"]}},
    {"name": "resize_pane",
     "description": "Make the requested pane wider, narrower, taller or shorter",
     "parameters": {"type": "object", "properties": {
         "pane": {"type": "string", "description": "the requested pane, if explicit"},
         "direction": {"type": "string", "enum": list(DIRECTIONS)},
         "amount": {"type": "integer", "minimum": 1, "maximum": 50,
                    "description": "number of cells, only if the user gives one"}},
         "required": ["direction"]}},
    {"name": "run_in_pane",
     "description": "Type a command into an existing pane and press enter. "
                    "Use for run X in a pane, type X",
     "parameters": {"type": "object", "properties": {
         "pane": _target("pane", "current, left, right, above, below"),
         "command": {"type": "string", "description": "the exact command text"}},
         "required": ["pane", "command"]}},
]

LEGACY_TOOLS = TOOLS.copy()  # Needle 2 checkpoints keep their original ten schemas.
TOOLS += [{'name': 'maximize_pane',
  'description': 'Show one pane full-size (zoom or maximize it), or restore the previous '
                 'layout',
  'parameters': {'type': 'object',
                 'properties': {'pane': {'type': 'string',
                                         'description': 'current, left, right, above, below, '
                                                        'or the name or program of a pane'},
                                'restore': {'type': 'boolean',
                                            'description': 'true to un-maximize and restore '
                                                           'the layout'}},
                 'required': []}},
 {'name': 'rename_pane',
  'description': 'Rename or title a pane',
  'parameters': {'type': 'object',
                 'properties': {'pane': {'type': 'string',
                                         'description': 'current, left, right, above, below, '
                                                        'or the name or program of a pane'},
                                'name': {'type': 'string', 'description': 'the new name'}},
                 'required': ['name']}},
 {'name': 'swap_panes',
  'description': 'Swap the current pane with its neighbour on one side',
  'parameters': {'type': 'object',
                 'properties': {'side': {'type': 'string',
                                         'enum': ['left', 'right', 'above', 'below'],
                                         'description': 'which neighbour to swap with'}},
                 'required': ['side']}},
 {'name': 'move_tab',
  'description': 'Move the current tab left or right in the tab bar, or to a position',
  'parameters': {'type': 'object',
                 'properties': {'direction': {'type': 'string', 'enum': ['left', 'right']},
                                'position': {'type': 'integer',
                                             'minimum': 1,
                                             'maximum': 9,
                                             'description': 'tab position, only if the user '
                                                            'gives one'}},
                 'required': []}}]

TOOL_NAMES = frozenset(tool["name"] for tool in TOOLS)
# Gerunds too ("would you mind closing the current tab", blind supplement). Not
# "running": it introduces a program name ("the pane running top").
_CLOSE_VERB = re.compile(r"\b(close|closing|kill|killing|quit|quitting|exit|exiting|shut|shutting)\b",
                         re.IGNORECASE)
_RUN_VERB = re.compile(r"\b(run|type|typing|execute|executing|enter|entering)\b", re.IGNORECASE)
_CURRENT = {"", "current", "this", "here", "active", "focused", "the current one"}
_ORDINALS = {"first": "1", "second": "2", "third": "3", "fourth": "4", "fifth": "5",
             "sixth": "6", "seventh": "7", "eighth": "8", "ninth": "9", "last": "last"}
_RELATIVE = {"next": "next", "previous": "previous", "prev": "previous", "last one": "previous",
             "back": "previous"}
_SIDE_WORDS = {"left": "left", "right": "right", "left-hand": "left", "right-hand": "right",
               "above": "above", "up": "above", "top": "above",
               "upper": "above", "below": "below", "down": "below", "bottom": "below",
               "under": "below", "underneath": "below", "beneath": "below", "lower": "below"}
_CARDINALS = {"one": "1", "two": "2", "three": "3", "four": "4", "five": "5", "six": "6",
              "seven": "7", "eight": "8", "nine": "9"}
_LEADING_VERBS = re.compile(r"^(?:running|run|with|start|starting|launch)\s+", re.IGNORECASE)
_FILLER = re.compile(r"\b(?:the|this|that|one|pane|panes|tab|tabs|window|on|to|of)\b",
                     re.IGNORECASE)


@dataclass(frozen=True)
class Action:
    kind: str
    args: dict = field(default_factory=dict)

    @property
    def risky(self) -> bool:
        """Closing, typing into a pane, or starting a program waits for a yes."""
        if self.kind in ("close_pane", "close_tab", "run_in_pane"):
            return True
        return self.kind in ("open_pane", "open_tab") and bool(self.args.get("program"))


@dataclass(frozen=True)
class Refusal:
    kind: str
    reason: str


_UNITS = ("zero one two three four five six seven eight nine ten eleven twelve thirteen "
          "fourteen fifteen sixteen seventeen eighteen nineteen").split()
_TENS = {2: "twenty", 3: "thirty", 4: "forty", 5: "fifty"}


# Number words up to fifty for tab references ("close tab number twelve":
# measured, the words stopped at nine and "twelve" became a tab name).
for _n in range(10, 51):
    _t, _u = divmod(_n, 10)
    for _w in ([_UNITS[_n]] if _n < 20 else
               [_TENS[_t]] if _u == 0 else [f"{_TENS[_t]} {_UNITS[_u]}", f"{_TENS[_t]}-{_UNITS[_u]}"]):
        _CARDINALS[_w] = str(_n)


_MOVE = re.compile(r"\b(?:go|goes|going|gone|switch|switching|focus|focusing|jump|move|"
                   r"hop|flip|show|select|head|take|bring|back|return|visit|cycle|"
                   r"moving|jumping|hopping|flipping|showing|selecting|heading|taking|"
                   r"bringing|returning|visiting|cycling|"
                   r"activate|change to|over to|into)\b", re.I)
_BARE_REFERENCE = re.compile(r"^\s*(?:the\s+)?(?:(?:next|previous|prev|last|first|"
                             r"left|right|upper|lower|top|bottom)\s+(?:tab|pane|split|window)|"
                             r"(?:tab|pane)\s+(?:\w+)|\w+\s+(?:tab|pane))[\s.!?]*$", re.I)


_DIRECTION_WORDS = {
    "wider": r"wider|widen|widens|broaden|broader|bigger|larger|expand|stretch|grow|extend|"
             r"more width",
    "narrower": r"narrower|narrow|thinner|slimmer|shrink|squeeze|smaller|less width",
    "taller": r"taller|higher|heighten|bigger|larger|grow|stretch|expand|extend|more height",
    "shorter": r"shorter|lower|flatten|squash|shrink|smaller|less height",
}
_WIDTH = re.compile(r"\b(?:width|wide|horizontal\w*|sideways|side to side)\b", re.I)
_HEIGHT = re.compile(r"\b(?:height|tall|high|vertical\w*|up and down|upwards?|downwards?)\b",
                     re.I)


def _says_direction(direction: str, prompt: str) -> bool:
    """The request says this direction; "shrink" or "grow" name the axis only
    together with width or height words."""
    if not re.search(rf"\b(?:{_DIRECTION_WORDS[direction]})\b", prompt, re.I):
        return False
    horizontal = direction in ("wider", "narrower")
    if re.search(r"\b(?:wider|widen|broaden|broader|narrower|narrow|thinner|taller|shorter|"
                 r"heighten)\b", prompt, re.I):
        exact = {"wider": r"wider|widen|widens|broaden|broader",
                 "narrower": r"narrower|narrow|thinner|slimmer",
                 "taller": r"taller|heighten", "shorter": r"shorter"}[direction]
        return bool(re.search(rf"\b(?:{exact})\b", prompt, re.I))
    if _WIDTH.search(prompt) and not horizontal or _HEIGHT.search(prompt) and horizontal:
        return False
    return True


def _moves(prompt: str) -> bool:
    """A go-to needs a movement verb, or a bare reference such as "next tab".
    Measured (tuned model): "write a haiku about terminals" -> go to the tab
    named terminals."""
    return bool(_MOVE.search(prompt) or any(_BARE_REFERENCE.match(_POLITE_SUFFIX.sub("", c))
                                            for c in _clauses(prompt)))


def _says_number(n: int, prompt: str) -> bool:
    """n appears as a whole number or in words ("by twenty-five"), never as part
    of another number: 5 is not said by "15"."""
    forms = [str(n)]
    if n < 20:
        forms.append(_UNITS[n])
    elif n <= 59:
        tens, unit = divmod(n, 10)
        forms += [_TENS[tens]] if unit == 0 else [f"{_TENS[tens]}[ -]{_UNITS[unit]}"]
    return any(re.search(rf"(?<![\w-]){form}(?![\w-])", prompt, re.I) for form in forms)


def _resize_amount(direction: str, prompt: str) -> int | None:
    """Read the size-change clause, never a pane ID or a number in its title."""
    text = re.sub(r'''\b(?:titled|named|called)\s+(?:"[^"\n]*"|'[^'\n]*'|`[^`\n]*`|[\w.+@:-]+)''',
                  ' ', prompt, flags=re.I)
    words = '|'.join(re.escape(w) for w in sorted(_CARDINALS, key=len, reverse=True))
    number = rf'(?:[+-]?\d+(?:\.\d+)?|{words})'
    values = []
    bound_by = 0
    for clause in _clauses(text):
        if not _says_direction(direction, clause):
            continue
        by = list(re.finditer(rf'\bby\s+({number})(?![\w-])', clause, re.I))
        bound_by += len(by)
        if re.search(r'\bby\b', clause, re.I) and not by:
            raise ValueError('the resize amount after by is not a supported cell count')
        adjectival = list(re.finditer(
            rf'(?<![\w-])({number})\s+(?:cells?|columns?|rows?)\s+{direction}\b', clause, re.I))
        for match in by + adjectival:
            if re.match(r'\s*(?:%|(?:pixels?|percent|times)\b)', clause[match.end():], re.I):
                raise ValueError('resize amounts must be cell counts')
            unit = re.match(r'\s*(columns?|rows?|lines?)\b', clause[match.end():], re.I)
            if unit and (unit[1].lower().startswith('column') != (direction in ('wider', 'narrower'))):
                raise ValueError('the cell unit conflicts with the resize direction')
            raw = match[1].lower()
            try:
                value = int(_CARDINALS.get(raw, raw))
            except ValueError:
                raise ValueError('resize amounts must be whole cell counts') from None
            if not 1 <= value <= 50:
                raise ValueError('the size change must be 1 to 50 cells')
            values.append(value)
    if bound_by != len(re.findall(r'\bby\b', text, re.I)):
        raise ValueError('a size amount is not bound to the resize direction')
    if len(values) > 1:
        raise ValueError('the request contains multiple resize amounts')
    return values[0] if values else None


def _grounded(value: str, prompt: str) -> bool:
    """The value occurs in the request as whole words, not inside a word.

    Measured (tuning run 2): "stack the panes" -> go_to pane "a", admitted by a
    substring match on the "a" in "stack".
    """
    return re.search(rf"(?<![\w]){re.escape(value.casefold())}(?![\w])",
                     prompt.casefold()) is not None


def _text(args: dict, key: str) -> str:
    value = args.get(key, "")
    return value.strip() if isinstance(value, str) else ""


def _target_value(raw: str, *, relative: bool) -> str | None:
    """Normalise a pane/tab reference; None if it is not usable."""
    lowered = " ".join(raw.casefold().split())
    if lowered in _CURRENT or lowered in ("this pane", "this tab", "current pane",
                                          "current tab", "this one"):
        return "current"
    words = re.sub(r"^(?:the\s+)?(?:tab\s+)?(?:number\s+)?", "", lowered).strip()
    if relative and words in _CARDINALS:
        return _CARDINALS[words]    # before fillers: "twenty-one" must keep its "one"
    stripped = " ".join(_FILLER.sub(" ", lowered).split()).rstrip(".,!?;:")
    if not stripped:
        # Only filler ("pane", "the tab"): no reference at all. Measured (five-tool
        # schema): pane "pane" with command "below" would otherwise mean "this pane".
        return None
    if stripped in _CURRENT:
        return "current"
    if stripped in _SIDE_WORDS:
        return _SIDE_WORDS[stripped]
    if stripped in _RELATIVE:
        return _RELATIVE[stripped]
    if relative and stripped in _ORDINALS:
        return _ORDINALS[stripped]
    if relative and stripped in _CARDINALS:
        return _CARDINALS[stripped]
    if relative and re.fullmatch(r"(?:number\s+)?[0-9]{1,2}", stripped):
        return stripped.split()[-1]
    if re.fullmatch(r"[\w.+-][\w .+-]{0,62}", stripped):
        return "name:" + stripped
    return None


_TYPOGRAPHY = str.maketrans({"\u2018": "'", "\u2019": "'", "\u201b": "'", "\u2032": "'",
                             "\u02bc": "'", "\u02b9": "'",   # review R12: "don\u02bct open doom"
                             "\u201c": '"', "\u201d": '"', "\u2033": '"',
                             "\u2010": "-", "\u2011": "-", "\u2012": "-", "\u2013": "-",
                             "\u2014": "-", "\u2015": "-", "\u2212": "-", "\u00a0": " "})


def normalize(prompt: str) -> str:
    """Typography as phones and word processors insert it, made plain: measured
    (review R2), "don\u2019t close tab 2" closed tab 2 because the checks
    knew only an ASCII apostrophe."""
    return unicodedata.normalize("NFKC", str(prompt)).translate(_TYPOGRAPHY)


# A plain instruction is one the request states in a canonical form of the
# admitted actions themselves: "close tab 2", "close the build pane", "run make
# in the left pane", "split right and run htop", optionally wrapped in
# politeness ("please", "can you", "thanks"). A yes given in advance (--yes,
# MCP confirm_risky) covers only that; anything else waits for a person whose
# question names the target.
#
# History, so it is not repeated. Review R1: refusal word lists were bypassed.
# Review R2: every list of words to refuse was one word short. Review R3: an
# allowlist of words still composes wrong meanings from allowed words alone
# ("would that close tab 2?", "close tab 2 in 5", "close tab 1 into tab 2").
# So the request is compared with what the actions say, not scanned for words.
_POLITE_HEAD = re.compile(r"^(?:(?:please|pls|kindly|ok|okay|alright|hey|just|can you|could you|"
                          r"would you|will you|go ahead and)[\s,]+)+")
_POLITE_TAIL = re.compile(r"(?:[\s,]+(?:please|pls|thanks|thank you|now|right now|for me))+$")
_CLAUSE_SPLIT = re.compile(r"\s*(?:,\s*and then|,\s*then|,\s*and|\s+and then|\s+then|\s+and|,|;)\s+")
_CLOSE_WORDS = r"(?:close|kill|shut|quit|exit)"
_RUN_WORDS = r"(?:run|type|execute|enter)"
# "top"/"bottom" are not canonical: Kilix resolves "above" to the adjacent
# pane, so in a stack of three "the top pane" would close the middle one
# (review KN-R4-02). Those requests wait for a person.
_SIDE_ALIAS = {"left": (), "right": (), "above": (), "below": ()}


def _alt(options) -> str:
    return "(?:" + "|".join(sorted(set(options), key=len, reverse=True)) + ")"


def _tab_phrases(target: str) -> list[str]:
    if target == "current":
        return [r"(?:this|the current|current) tab"]
    if target in ("next", "previous", "last"):
        return [rf"(?:the )?{target} tab"]
    if target.isascii() and target.isdigit():
        words = [w for w, n in _CARDINALS.items() if n == target]
        ordinals = [w for w, n in _ORDINALS.items() if n == target]
        out = [rf"tab (?:number )?{_alt([re.escape(target), *map(re.escape, words)])}"]
        if ordinals:
            out.append(rf"(?:the )?{_alt(ordinals)} tab")
        return out
    name = re.escape((target[5:] if target.startswith("name:") else target).casefold())
    return [rf"(?:the |that )?{name} tab", rf"(?:the )?tab (?:called|named|titled) {name}"]


def _pane_phrases(target: str) -> list[str]:
    unit = r"(?:pane|split|window)"
    if target == "current":
        return [rf"(?:this|the current|current) {unit}"]
    if target in ("next", "previous"):
        return [rf"(?:the )?{target} {unit}"]
    if target in SIDES:
        words = [target, *_SIDE_ALIAS[target]]
        out = [rf"(?:the )?{_alt(words)} {unit}"]
        if target in ("left", "right"):
            out.append(rf"(?:the )?{unit} (?:on|to) the {target}")
        else:
            out.append(rf"(?:the )?{unit} {target}")
        return out
    if target.startswith("id:"):
        n = target[3:]
        return [rf"(?:the )?(?:pane|window)\s*(?:id\s*)?[:#]?\s*{n}", rf"#{n}"]
    name = re.escape((target[5:] if target.startswith("name:") else target).casefold())
    here = r"(?: in (?:this|the current) tab)?"   # narrows, never widens
    return [rf"(?:the |that )?{name} {unit}{here}",
            rf"(?:the )?{unit} (?:called|named|titled|labell?ed|running) {name}{here}",
            rf"(?:the )?{unit} {name}{here}"]


# A word that is plainly an argument to a shell command, not English.
# Review KN-R6-03: "any word with . : @ ~ *" let "17:00", "@midnight",
# "~5min" and "9/25" through. Now: a flag; a path (/, ./, ../, ~/, or letters
# and a slash); a file name with an extension; VAR=value; a plain integer; an
# operator.
_SHELL_ARGUMENT = re.compile(
    r"-[\w-]*(?:=\S*)?"
    r"|(?:\.{1,2}|~)?/\S*"
    r"|[\w.-]*[A-Za-z][\w.-]*/[\w./-]*"
    r"|[\w-]+\.[A-Za-z][A-Za-z0-9]{0,7}"
    r"|[A-Za-z_][A-Za-z0-9_]*=\S*"
    r"|[0-9]+|\.{1,2}|\$[A-Za-z_]\w*|\$\{\w+\}"      # "cd ..", "echo $HOME" (R7 utility)
    r"|&&|\|\||\||;|>>?|<|2>&1")


def _quoted(value: str) -> str:
    """A command or program as the request gives it. Quoted, it is taken
    verbatim. Unquoted, it is plain only as one word, or when every later word
    is plainly a shell argument (a flag, a path, a number, `=`, an operator):
    English after a program may be a condition or a delay that would be typed
    along with it. Reviews KN-R4-05 and KN-R5-03 each found a list of such
    words one word short ("if", then "tomorrow"); this needs no list."""
    text = re.escape(value.casefold())
    words = value.split()
    if len(words) == 1 or all(_SHELL_ARGUMENT.fullmatch(w) for w in words[1:]):
        return rf"(?:{text}|`{text}`|\"{text}\"|'{text}')"
    return rf"(?:`{text}`|\"{text}\"|'{text}')"


def _clause_forms(action) -> list[str]:
    """Canonical wordings of one admitted action (regexes, whole clause)."""
    kind, args = action.kind, action.args
    if kind == "close_tab":
        return [rf"{_CLOSE_WORDS} {p}" for p in _tab_phrases(args["tab"])]
    if kind == "close_pane":
        return [rf"{_CLOSE_WORDS} {p}" for p in _pane_phrases(args["pane"])]
    if kind == "run_in_pane":
        command = _quoted(args["command"])
        forms = []
        for p in _pane_phrases(args["pane"]):
            forms += [rf"{_RUN_WORDS} (?:the command )?{command} (?:in|into) {p}",
                      rf"in {p},? {_RUN_WORDS} (?:the command )?{command}"]
        if args["pane"] == "current":
            forms.append(rf"{_RUN_WORDS} {command} here")
        return forms
    if kind in ("open_pane", "open_tab"):
        unit = "tab" if kind == "open_tab" else r"(?:pane|split)"
        program = _quoted(args["program"]) if args.get("program") else None
        name = re.escape(args["name"].casefold()) if args.get("name") else None
        side = args.get("side")
        where = ""
        if side:
            where = (rf" (?:on the |to the )?{side}" if side in ("left", "right")
                     else rf" {_alt([side, *_SIDE_ALIAS[side]])}")
        called = rf" (?:called|named) {name}" if name else ""
        new = r"(?:a |a new |new )"
        forms = []
        if program:
            forms += [rf"(?:open|start|launch) {new}{unit}{where}{called} (?:running|with) {program}",
                      rf"(?:open|start|launch|run) {program} in {new}{unit}{where}{called}"]
            if kind == "open_pane" and side:
                forms.append(rf"split {_alt([side, *_SIDE_ALIAS[side]])} and (?:run|start) {program}")
        else:
            forms += [rf"(?:open|start) {new}?{unit}{where}{called}"]
            if kind == "open_pane" and side:
                forms.append(rf"split {_alt([side, *_SIDE_ALIAS[side]])}")
        return forms
    if kind == "go_to_tab":
        return [rf"(?:(?:go|switch|jump|move) to|focus) {p}" for p in _tab_phrases(args["tab"])]
    if kind == "go_to_pane":
        return [rf"(?:(?:go|switch|jump|move) to|focus) {p}" for p in _pane_phrases(args["pane"])]
    return []   # no plain wording: beside a risky action, the request is not plain


_MOVES_FOCUS = ("go_to_tab", "go_to_pane", "open_pane", "open_tab")


def plain(prompt: str, actions: list) -> str | None:
    """None when the request is a plain instruction; otherwise why it is not,
    for the note that asks for a person's yes."""
    text = normalize(prompt).casefold().strip()
    # A question mark is plain only after "can/could/would/will you": a bare
    # "close tab 2?" asks (review R4, row D).
    asks = re.match(r"(?:please[\s,]+)?(?:can|could|would|will) you\b", text)
    # Anywhere in the closing punctuation (review KN-R5-04: "close tab 2?!").
    if re.search(r"\?[\s.!?]*$", text) and not asks:
        return "it ends in a question mark"
    text = _POLITE_HEAD.sub("", text)
    text = re.sub(r"[.!?]+$", "", text).strip()
    text = _POLITE_TAIL.sub("", text).strip()
    if any(a.kind == "run_in_pane" for a in actions):
        # Typing presses Enter already: "... and press enter" says nothing more.
        text = re.sub(r"(?:,?\s+(?:and\s+|then\s+|and then\s+)?|[.;]\s+)(?:press|hit)\s+"
                      r"(?:enter|return)(?:\s+(?:in|into)\s+(?:that|the|this)(?:\s+same)?\s+pane)?$",
                      "", text).strip()
    risky = [a for a in actions if getattr(a, "risky", False)]
    if not risky:
        return None
    moved = False
    for action in actions:
        target = action.args.get("tab") or action.args.get("pane")
        if action.risky and moved:
            # Named targets too (review KN-R4-03): a name resolves in the
            # caller's tab first, not in the tab the request just moved to.
            return "a risky action after focus has moved"
        if action.kind in _MOVES_FOCUS:
            moved = True
    # Split outside quotes: 'run "if true; then ls; fi" in the build pane' is one clause.
    bounds = list(_CLAUSE_SPLIT.finditer(_unquoted(text)))
    starts = [0] + [m.end() for m in bounds]
    ends = [m.start() for m in bounds] + [len(text)]
    # One action may be written across a separator ("split right and run
    # htop", "in the build pane, run make"): an action takes one clause, or
    # two joined by the text that separated them.
    i, verb = 0, None
    for action in actions:
        if i >= len(starts):
            return "it names more actions than it states"
        forms = _clause_forms(action)
        taken = None
        for span in (1, 2):
            if i + span > len(starts):
                break
            clause = text[starts[i]:ends[i + span - 1]]
            head = re.match(r"(close|kill|shut|quit|exit|run|type|execute|enter)\b", clause)
            candidate = clause if head or not (verb and action.risky) else f"{verb} {clause}"
            # A safe clause beside a risky one is held to its canonical
            # wording too (review KN-R4-04: its words alone let "at 5 go to
            # tab 1 and close tab 2" through, and let rename_tab's own value
            # carry "if the tests pass").
            if any(re.fullmatch(form, candidate) for form in forms):
                taken, verb = span, (head.group(1) if head else verb)
                break
        if taken is None:
            if not forms:
                return f"no plain wording is known for {action.kind}"
            return f"{text[starts[i]:ends[i]]!r} is not a plain way to say {action.kind}"
        i += taken
    if i != len(starts):
        return f"{text[starts[i]:]!r} is more than the actions say"
    return None


# A condition or a time says the action is not for now: "if the build fails,
# close the logs pane", "close it tomorrow" (review: held-out v10). "before"
# and "after" stay: "the tab before this one" is a place.
_WEEKDAY = r"(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)"
_COUNT = r"(?:a|an|one|two|three|four|five|ten|twenty|thirty|a few|a couple of|\d+)"
_UNIT = r"(?:seconds?|secs?|minutes?|mins?|hours?|hrs?|days?|weeks?|months?)"
_EVENT_VERB = (r"(?:finish(?:es|ed)?|complete[sd]?|end(?:s|ed)?|stop(?:s|ped)?|fail(?:s|ed)?|"
               r"pass(?:es|ed)?|succeed(?:s|ed)?|crash(?:es|ed)?|exit(?:s|ed)?|is done|are done|"
               r"is over|done)")
# A condition or a time says the action is not for now: "if the build fails,
# close the logs pane", "close it at noon", "after the backup finishes"
# (held-out v10, review R19). A place is no time: "the tab before this one",
# "the pane after this one" stay.
_WHEN = re.compile(
    rf"(?<![\w-])(?:if|unless|when|whenever|once|as soon as|provided|providing|assuming|"
    rf"in case|tomorrow|tonight|later|later on|soon|eventually|next {_WEEKDAY}|next week|"
    rf"next month|this (?:morning|afternoon|evening|weekend)|on {_WEEKDAY}|{_WEEKDAY}|"
    rf"at (?:noon|midnight|\d{{1,2}}(?::\d\d)?(?: ?[ap]\.?m\.?)?)|"
    rf"in {_COUNT} {_UNIT}|in an? (?:minute|hour|bit|while|moment|sec|second)|"
    rf"after (?:the |my |your |our |this |that |it |i |you |we )?[\w-]+(?: [\w-]+)? {_EVENT_VERB}|"
    rf"after (?:lunch|dinner|breakfast|work|the meeting|the call|a (?:while|bit|minute)))(?![\w-])",
    re.IGNORECASE)
# Courtesy that only sounds conditional (review R2's legitimate rows): "if
# you can", "when you get a chance", "once and for all". Only as a whole
# clause: "if you can reach the server, close ..." is a condition (review
# KN-R19-01).
_COURTEOUS_WHEN = re.compile(
    r"(?<![\w-])(?:if (?:you|u) (?:can|could|would|will|wouldn't mind|don't mind|do not mind|"
    r"please|like|want|have a (?:sec|second|moment|minute))|if (?:that's|that is|it's|it is) "
    r"(?:ok|okay|alright|all right|fine)|if possible|if you would|"
    r"when(?:ever)? (?:you're|you are|u r|ur) (?:done|finished|ready|free)|"
    r"when(?:ever)? (?:you|u) (?:get|have) a (?:chance|moment|sec|second|minute)|"
    r"whenever you can|when you can|once and for all|"
    # the executor already types only at a shell prompt
    r"if (?:it's|it is|its) (?:idle|free|at (?:a|the) prompt))"
    r"(?=\s*(?:$|[,.;!?]|\b(?:and|then|please|thanks)\b))", re.IGNORECASE)
# A name said as a name is data: "the pane named Tomorrow" (review KN-R19-02).
_SAID_NAME = re.compile(r"(?<![\w-])(?:named|called|titled|labell?ed)\s+\S+", re.IGNORECASE)


def _says_when(prompt: str, calls: list) -> bool:
    """A condition or time outside the text a call types or starts, and outside
    a name said as a name."""
    text = prompt
    for call in calls if isinstance(calls, list) else []:
        args = call.get("arguments") if isinstance(call, dict) else None
        for key in ("command", "program"):
            value = args.get(key) if isinstance(args, dict) else None
            if isinstance(value, str) and value.strip():
                text = text.replace(value.strip(), " ")
    text = re.sub(r"([\"'`]).*?\1", " ", text)
    text = _SAID_NAME.sub(" ", text)
    # "at once", "one at a time" say how many, not when (held-out v12).
    text = re.sub(r"(?<![\w-])(?:all )?at once|(?:one |two )?at a time(?![\w-])", " ", text,
                  flags=re.IGNORECASE)
    return bool(_WHEN.search(_COURTEOUS_WHEN.sub(" ", text)))


# Someone else's instruction, reported: "Sam keeps telling me to kill the logs
# pane but I like it" is not a request to close it (held-out v13).
_HEARSAY = re.compile(
    r"\b(?:keeps?|kept|keep on|always|was|were|is|are)?\s*(?:tell|tells|telling|told|ask|asks|asking|"
    r"asked|want|wants|wanted|suggest|suggests|suggesting|suggested|advise|advises|advised|"
    r"nag|nags|nagging|nagged|urge|urges|urged)\s+(?:me|us)\s+to\b", re.I)
_HEARSAY_SPEAKER = re.compile(r"^\s*(?:please\s+|can you\s+|could you\s+)?(?:i|we)\b", re.I)
# Written or third-party instructions: "our onboarding wiki instructs newcomers
# to type yarn build into the ci pane" (held-out v14).
_INSTRUCTS = re.compile(
    r"\b(?:instructs?|instructed|tells|told|asks|asked|wants|wanted|says|said|recommends?|"
    r"recommended|suggests|suggested|advises|advised|expects|expected|reminds|reminded)"
    r"\s+(?:[\w'-]+\s+){0,3}to\s", re.I)
_IMPERATIVE_LEAD = re.compile(r"^\s*(?:(?:please|pls|can you|could you|would you|kindly)\s*)*$", re.I)
# A request taken back runs nothing: "close tab 3 - no wait, never mind" (held-out v14).
_RETRACTED = re.compile(
    r"(?<![\w-])(?:never\s*mind|nevermind|forget (?:it|that|about it)|scratch that|cancel that|"
    r"no wait|belay that|on second thought|don'?t bother|ignore (?:that|this|me))(?![\w-])", re.I)


def _hearsay(prompt: str) -> bool:
    """Another person's instruction. "I want us to…" is the user speaking."""
    match = _HEARSAY.search(prompt)
    if match and not _HEARSAY_SPEAKER.match(prompt[:match.start()] + " "):
        return True
    match = _INSTRUCTS.search(prompt)
    lead = prompt[:match.start()] if match else ""
    return bool(match) and not _IMPERATIVE_LEAD.match(lead) \
        and not _HEARSAY_SPEAKER.match(lead + " ")


def _pane_colon_ids(prompt: str) -> str:
    """ "pane:70", the form `kilix pane` prints, read as "pane 70" (outside quotes)."""
    parts = re.split(r"""((?:`[^`]*`)|(?:"[^"]*")|(?:'[^']*'))""", prompt)
    return "".join(p if i % 2 else re.sub(r"(?<![\w-])(pane|window):([0-9]{1,6})(?![\w-])",
                                          r"\1 \2", p, flags=re.IGNORECASE)
                   for i, p in enumerate(parts))


def interpret(prompt: str, calls: list) -> list[Action | Refusal]:
    """Turn the engine's calls into admitted actions or named refusals."""
    prompt = _pane_colon_ids(normalize(prompt))
    results: list[Action | Refusal] = []
    if _says_when(prompt, calls):
        return [Refusal(str(call.get("name") if isinstance(call, dict) else call),
                        "the request says when or on what condition, not now")
                for call in (calls if isinstance(calls, list) else [])]
    if _hearsay(prompt):
        return [Refusal(str(call.get("name") if isinstance(call, dict) else call),
                        "the request reports someone else's instruction")
                for call in (calls if isinstance(calls, list) else [])]
    if _RETRACTED.search(prompt):
        return [Refusal(str(call.get("name") if isinstance(call, dict) else call),
                        "the request is taken back")
                for call in (calls if isinstance(calls, list) else [])]
    for call in calls if isinstance(calls, list) else []:
        name = call.get("name") if isinstance(call, dict) else None
        args = call.get("arguments") if isinstance(call, dict) else None
        if not isinstance(name, str) or name not in TOOL_NAMES or not isinstance(args, dict):
            results.append(Refusal(str(name), "not a kilix-needle action"))
            continue
        schema = next(t["parameters"] for t in TOOLS if t["name"] == name)
        error = _shape_error(args, schema)
        results.append(Refusal(name, error) if error else _admit(name, args, prompt))
    return _merge_split_then_run(_bind_programs(results, prompt), prompt)


_OPEN_PANE_WORD = re.compile(r"\b(?:panes?|splits?|splitting|windows?)\b", re.IGNORECASE)
# A phrasal up/down is not a direction: "open up a new pane" is not above
# (measured, tuned model), nor is "spin up", "fire up" or "pull up" (review R10).
_PHRASAL_UP_DOWN = re.compile(
    r"\b(?:open|opens|opening|pull|pulls|pulling|bring|brings|fire|fires|firing|spin|spins|"
    r"spinning|set|sets|setting|boot|boots|booting|start|starts|call|calls|look|looks|shut|"
    r"shuts|write|slow|calm|pop|pops|power|powers|light|lights|queue|queues|whip|rustle|"
    r"crank|cranks|throw|throws|put|puts)\s+(?:up|down)\b", re.IGNORECASE)


def _without_phrasals(text: str) -> str:
    return _PHRASAL_UP_DOWN.sub(" ", text)


def _real_clauses(prompt: str) -> list[str]:
    return [c for c in _clauses(prompt) if c.strip()]


def _says_whole(value: str) -> re.Pattern:
    return re.compile(rf"(?<![\w]){re.escape(value)}(?![\w])", re.IGNORECASE)


# Verbs that act on a pane or tab already there.
_NOT_OPENING = re.compile(r"\b(?:go|goes|going|switch|switching|jump|move|focus|focusing|head|hop|"
                          r"rename|retitle|title|label|resize|shrink|grow|widen|narrow|enlarge|"
                          r"maximi[sz]e|zoom|close|kill|quit|exit|swap|select|type|run|stays?|"
                          r"keeps?|leave|leaves|wait|waits)\b",
                          re.IGNORECASE)
_EXISTING_UNIT = re.compile(r"\b(?:the|this|that|my|current|active|focused|same)\s+(?:\w+\s+)?"
                            r"(?:tabs?|panes?|splits?|windows?)\b"
                            r"|\b(?:tabs?|panes?)\s+(?:number\s+)?(?:\d+|one|two|three|four|five|six|"
                            r"seven|eight|nine|ten)\b", re.IGNORECASE)
_NEW_UNIT = re.compile(r"\b(?:new|fresh|another|extra)\s+(?:\w+\s+)?(?:tabs?|panes?|splits?|windows?)\b",
                       re.IGNORECASE)


def _bind_programs(results: list, prompt: str) -> list:
    """A program starts only in the kind of open, and on the side, its clause asks for.

    Measured (Needle 3, held-out v6): "new tab, then split right with python3"
    -> open_tab, open_pane(right), open_tab(program=python3). Each call passed on
    its own, since python3 is in the request, so an extra tab started it. And
    (tuned Needle 3, v4) "split left with less and split right with watch" ->
    open_pane(left, program=watch): the program of the right split on the left.
    """
    clauses = _real_clauses(prompt)
    if len(clauses) < 2:
        return results
    units = re.compile(rf"{_TAB_WORD.pattern}|{_OPEN_PANE_WORD.pattern}", re.IGNORECASE)

    def places(text: str) -> bool:
        return any(_first(_mentions(s), text) for s in SIDES)

    def opens(text: str) -> bool:
        # A clause naming a unit or a side opens it, whatever the verb ("add a
        # pane on the right", "give me a tab"), unless it acts on one that exists:
        # "focus the left pane", "give the tab a new name", "make the left pane
        # smaller" (review R10, rounds 2-4).
        has_unit = bool(units.search(text))
        if not has_unit and not places(text):
            return False
        if _NOT_OPENING.search(text):
            return False
        return not (has_unit and _EXISTING_UNIT.search(text) and not _NEW_UNIT.search(text))

    def home(i: int, said: re.Pattern) -> str:
        text = _without_phrasals(said.sub(" ", clauses[i]))
        # "split right and run python3": a clause that names neither a unit nor a
        # side is read with the nearest clause before it that opens something
        # (review R10, KN-R10-01 and -08: not "name it py", not "rename this tab").
        if not units.search(text) and not places(text):
            before = [_without_phrasals(said.sub(" ", c)) for c in clauses[:i]]
            opener = next((c for c in reversed(before) if opens(c)), "")
            text = opener + " " + text
        return text

    out = []
    for item in results:
        program = item.args.get("program") if isinstance(item, Action) else None
        if program and item.kind in ("open_pane", "open_tab"):
            said = _says_whole(program)
            homes = [home(i, said) for i, c in enumerate(clauses) if said.search(c)]
            own, other = ((_TAB_WORD, _OPEN_PANE_WORD) if item.kind == "open_tab"
                          else (_OPEN_PANE_WORD, _TAB_WORD))
            if homes and all(other.search(h) and not own.search(h) for h in homes):
                unit = "tab" if item.kind == "open_tab" else "pane"
                out.append(Refusal(item.kind, f"{program!r} is asked for somewhere other than "
                                              f"a new {unit}"))
                continue
            side = item.args.get("side")
            if side and homes and all(
                    not _first(_mentions(side), h)
                    and any(_first(_mentions(s), h) for s in SIDES if s != side) for h in homes):
                out.append(Refusal(item.kind, f"{program!r} is asked for on another side"))
                continue
        out.append(item)
    return out


# A second pane asked for: never merged into the first (review R10, KN-R10-03).
_ANOTHER = re.compile(r"\b(?:another|again|second|too)\b", re.IGNORECASE)
_MORE = re.compile(r"\b(?:also|extra|plus|one more|additional)\b", re.IGNORECASE)


def _merge_split_then_run(results: list, prompt: str) -> list:
    """"split right and run htop" is one pane, even when it arrives as two calls.

    Measured (tuned five-tool model): open_pane(side=right) then
    open_pane(program=htop) for that request; admitted separately they open two
    panes, one running a program nobody asked to put there. The pair is merged
    only when the program's own clause is a bare start ("run htop"), never when
    it asks for another pane ("and open a pane running htop").
    """
    merged = []
    # One opening noun in the whole request means one new pane or tab: "a fresh
    # pane on the right, named logs, running tail" came back as two opens, one
    # with the name and one with the program (measured, tuned model).
    single = len(re.findall(r"\b(?:splits?|panes?|tabs?|windows?|terminals?)\b", prompt, re.I)) == 1
    for item in results:
        previous = merged[-1] if merged else None
        if (single and isinstance(item, Action) and isinstance(previous, Action)
                and previous.kind == item.kind and item.kind in ("open_pane", "open_tab")
                and all(previous.args.get(k, v) == v for k, v in item.args.items())):
            merged[-1] = Action(item.kind, {**previous.args, **item.args})
            continue
        if (isinstance(item, Action) and isinstance(previous, Action)
                and previous.kind == item.kind == "open_pane"
                and set(previous.args) == {"side"} and set(item.args) == {"program"}):
            clauses = _real_clauses(prompt)
            said = _says_whole(item.args["program"])
            # The program's clause, by whole word: "top" is not in "htop" (review R10).
            k = next((i for i, c in enumerate(clauses) if said.search(c)), None)
            if k is not None:
                rest = [_without_phrasals(said.sub(" ", c)) for c in clauses[:k + 1]]
                placing = [i for i, text in enumerate(rest)
                           if _first(_mentions(previous.args["side"]), text)]
                bare = not re.search(r"\b(?:open|pane|panes|split|window|tab)\b", rest[k], re.I)
                # "open a pane below running tail" in two calls, open_pane(below) then
                # open_pane(program=tail) (measured, tuned Needle 3): the program's own
                # clause places that one pane. A bare "run htop" belongs to the open
                # placed by the clause just before it, and to no other.
                placed = (placing == [k]
                          and len(_OPEN_PANE_WORD.findall(rest[k])) == 1
                          and not _TAB_WORD.search(rest[k]))
                # A second pane asked for in these clauses is never merged into
                # the first (review R10, KN-R10-03 and -07); only the clauses that
                # describe this pane count, not the rest of the request.
                span = " ".join(clauses[placing[-1]:k + 1]) if placing else ""
                bare = bare and not _ANOTHER.search(clauses[k])
                placed = placed and not _ANOTHER.search(span) and not _MORE.search(span)
                if (bare and placing and placing[-1] == k - 1) or placed:
                    merged[-1] = Action("open_pane", {**previous.args, **item.args})
                    continue
        merged.append(item)
    return merged


_AS_NAME = r"(?:running|named|called|titled|labell?ed|with)\s+(?:the\s+)?"
# Words that place or repeat, never name: a pane or tab called one of these
# must be introduced as a name ("the tab named over").
_NOT_A_NAME = frozenset({"over", "other", "another", "back", "again", "up", "down", "all", "both",
                         "it", "them", "there", "here", "now", "then", "too", "also", "instead",
                         "away", "off", "out", "over there", "over here", "ones", "same",
                         "please", "anyway", "afterwards", "yonder", "as well", "well", "behind",
                         "next door", "quickly", "now please", "everything", "anything",
                         "nothing", "something", "everyone", "others", "the others"})


# Before the unit noun, these already say which one: a word after it is not its name.
_POINTING = frozenset({"next", "previous", "prev", "last", "that", "this", "other", "first",
                       "second", "third", "current", "same", "active", "focused"})
# First words of a place, a manner or a courtesy, never of a name.
_PLACING = frozenset({"over", "down", "up", "back", "there", "here", "yonder", "behind", "next",
                      "away", "off", "out", "please", "now", "anyway", "afterwards", "too", "again",
                      "as", "right", "left", "below", "above", "also", "instead", "then", "too",
                      "for", "to", "on", "in", "at", "by", "from", "with", "and", "or", "so"})
# Determiners, not names, in any position: "the other tab", "the same pane".
_NEVER_A_NAME = frozenset({"other", "another", "same", "both", "all", "ones", "it", "them",
                           # the speaker, never a pane: "the pane i'm sitting in" (held-out v10)
                           "i", "i'm", "im", "me", "my", "mine", "you", "your", "we", "us",
                           "our", "he", "she", "they", "which", "where", "whichever"})


def _names_a_target(word: str, key: str, prompt: str) -> bool:
    """A name not introduced as one ("named X") is said as "the X tab", or bare.

    The word right after the unit noun is a place or a manner, never a name:
    "the next tab over", "that tab quickly", "the tab please" (review R10). A
    placing word is a name only in the "the X tab" form.
    """
    if word in _NEVER_A_NAME:
        return False
    units = r"tabs?" if key == "tab" else r"panes?|windows?|splits?"
    before = re.search(rf"(?<![\w]){re.escape(word)}\s+(?:{units})\b", prompt, re.IGNORECASE)
    if before:
        return True
    first = word.split()[0]
    after = re.search(rf"(?:\b(\w+)\s+)?\b(?:{units})\s+{re.escape(first)}(?![\w])", prompt,
                      re.IGNORECASE)
    if after:
        # "tab logs" names a tab (review R10, KN-R10-06); "the next tab over",
        # "that tab quickly" and "the tab please" do not.
        pointed = (after[1] or "").casefold() in _POINTING
        return not (pointed or first in _NOT_A_NAME or word in _NOT_A_NAME
                    or first in _PLACING)
    return word not in _NOT_A_NAME


_BROWSERS = frozenset({"browser", "web browser", "chrome", "chromium", "firefox", "safari", "edge",
                       "brave", "opera", "vivaldi", "web", "website", "webpage", "web page"})


def _pane_id(raw: str, prompt: str) -> str | None:
    """"pane 70", "pane:70", "pane id 70", "window 70", "#70": a pane id, only
    when the request itself says it that way (route benchmark 2026-09-29: "no
    pane is called or running '70'")."""
    m = re.fullmatch(r"\s*(?:(?:the\s+)?(?:pane|window)\s*(?:id\s*)?[:#]?\s*|#)?([0-9]{1,6})\s*",
                     raw, re.IGNORECASE)
    if not m:
        return None
    n = m.group(1)
    said = re.search(rf"(?<![\w-])(?:(?:pane|window)\s*(?:id\s*)?[:#]?\s*|#){n}(?![\w-])",
                     prompt, re.IGNORECASE)
    return f"id:{int(n)}" if said else None


def _mutation_target(name: str, key: str, args: dict, prompt: str) -> str | Refusal | None:
    """Bind explicit identities even when the small model omits its target slot.

    Bare tab numbers retain their historical positional meaning; ``tab id N``
    and ``tab containing pane N`` are stable identities. Never guess between
    conflicting identities, including a negated second target.
    """
    pane_ids = set(re.findall(r"\b(?:pane|window)\s*(?:id\s*)?[:#]?\s*([0-9]{1,6})\b", prompt, re.I))
    tab_ids = set(re.findall(r"\btab\s+id\s*[:#]?\s*([0-9]{1,6})\b", prompt, re.I))
    positions = set(re.findall(r"\btab\s+([0-9]{1,2})\b", prompt, re.I))
    refs = {f"id:{int(n)}" for n in (pane_ids if key == "pane" else tab_ids)}
    if key == "tab":
        refs.update(str(int(n)) for n in positions)
        refs.update(f"pane:{int(n)}" for n in re.findall(
            r"\btab\s+containing\s+(?:the\s+)?pane\s*(?:id\s*)?[:#]?\s*([0-9]{1,6})\b", prompt, re.I))
    if len(refs) > 1:
        return Refusal(name, f"conflicting {key} identities; name one target")
    if refs:
        return refs.pop()
    if args.get(key):
        return _named_target(name, key, args, prompt)
    # Do not turn an explicit name the model dropped into the caller's pane.
    if re.search(rf"\b{key}\s+(?:named|titled|called|id)\b", prompt, re.I):
        return Refusal(name, f"the explicit {key} target was not resolved")
    return None


def _named_target(name: str, key: str, args: dict, prompt: str) -> str | Refusal:
    raw = _text(args, key)
    if key == "pane":
        ident = _pane_id(raw, prompt)
        if ident:
            return ident
    # The introducing word is not part of the name: measured (fourteen tools),
    # "close the pane running top" -> pane "running top", which names no pane.
    raw = re.sub(rf"^{_AS_NAME}", "", raw.strip(), flags=re.IGNORECASE)
    word = " ".join(raw.casefold().split())
    introduced = re.search(rf"\b({_AS_NAME}){re.escape(word)}(?![\w])", prompt, re.IGNORECASE) \
        if word else None
    # "with" and "running" introduce programs, never a filler: "close the tab with
    # all of them" is not a tab named all (review R10, KN-R10-04).
    if introduced and (word not in _NOT_A_NAME
                       or not re.match(r"(?:with|running)\b", introduced[1], re.IGNORECASE)):
        # Introduced as a name, it is a name: measured (held-out v3), "close the
        # pane running top" became the side "above", and "close the tab named
        # two" became tab 2.
        return "name:" + word
    value = _target_value(raw, relative=key == "tab")
    if value is None:
        return Refusal(name, f"cannot tell which {key} {raw!r} means")
    if value == "right" and re.search(
            r"(?<![\w])right\s+(?:before|after|away|now|here|there|then|next to|behind|"
            r"in front of)(?![\w])", prompt, re.IGNORECASE) and not re.search(
            rf"(?<![\w])(?:(?:on|to|at) the right|right(?:\s+(?:hand|side|most|one|{key}s?|"
            rf"panes?))?(?:[.,!?;]|$))", prompt, re.IGNORECASE):
        # "the tab right before this one": right is how close, not where
        # (held-out v10).
        return Refusal(name, f"{value!r} does not say where here")
    if key == "tab" and value.startswith("name:") and value[5:] in _BROWSERS and re.search(
            rf"(?<![\w]){re.escape(value[5:])}\s+tabs?\b", prompt, re.IGNORECASE):
        # "close the browser tab with the docs" is a web browser's tab, not a
        # Kilix tab (held-out v11).
        return Refusal(name, f"a {value[5:]} tab belongs to the web browser, not Kilix")
    units = r"tabs?" if key == "tab" else r"panes?|windows?|splits?"
    if value.startswith("name:") and re.search(
            rf"\b(?:whichever|whatever|which ever|what ever)\s+(?:{units})\b", prompt, re.IGNORECASE):
        # "close whichever tab sat before this one": a description, not a name
        # (held-out v14: tab "sat").
        return Refusal(name, f"{value[5:]!r} describes a {key}; it does not name one")
    if value.startswith("name:") and not _names_a_target(value[5:], key, prompt):
        # Measured (tuned Needle 3, held-out v8): "close the next tab over" ->
        # close_tab("over"), grounded because the word is in the request.
        return Refusal(name, f"{value[5:]!r} does not name a {key} here")
    if value.startswith("name:") and not _grounded(value[5:], prompt):
        return Refusal(name, f"the {key} {value[5:]!r} is not in the request")
    # Names are matched without regard to case (kilix.Tree), so their case is
    # not kept. Reviews R6-R8 each found the previous rule for choosing a case
    # taking it from somewhere slightly wrong; there is no such rule now.
    return value


def _navigation_scope(prompt: str) -> str | Refusal | None:
    """Scope comes from the request, never a model-supplied target field.

    Quoted titles cannot introduce scope. Other tab/window qualifiers are not
    supported by pane navigation; declining them is safer than losing them.
    Explicit tab navigation and unscoped pane IDs keep their existing meaning.
    """
    unquoted = _unquoted(prompt)
    current = re.compile(r"\bin\s+(?:this|the\s+current)\s+tab\b", re.I)
    scoped = bool(current.search(unquoted))
    qualifiers = re.findall(
        r"\b(?:in|within|inside|across|outside|on|from|of)\s+"
        r"(?:(?![;.,]|\b(?:and|then|or)\b).)*?\b(?:tabs?|windows?)\b",
        current.sub("", unquoted), re.I)
    if qualifiers:
        return Refusal("go_to_pane", "that pane navigation scope is not supported")
    return "current" if scoped else None


_CLAUSE = re.compile(r"\s*(?:,|;|\band then\b|\bthen\b|\band\b)\s*", re.IGNORECASE)


_TAB_WORD = re.compile(r"\btabs?\b", re.IGNORECASE)
_PANE_WORD = re.compile(r"\b(?:panes?|windows?|splits?)\b", re.IGNORECASE)


_UNIT_NAMES = {"tab", "new tab", "a new tab", "pane", "new pane", "a new pane", "terminal",
               "new terminal", "window", "new window", "split"}
_LOCATIVE = re.compile(r"\b(?:in|inside|within|at|from|of)\b", re.IGNORECASE)
_BARE_OBJECT = {"this", "that", "here", "now", "please", "the", "current", "active", "focused", "one",
                "pane", "tab", "window", "split"}


def _mentions(target: str) -> list[str]:
    """Words the request may use for this target."""
    if target == "current":
        return ["this", "current", "here", "active", "focused"]
    if target.startswith("name:"):
        return [target[5:]]
    if target.startswith("id:"):
        return [target[3:]]
    token = target
    return [token,
            *(word for word, side in _SIDE_WORDS.items() if side == token),
            *(word for word, number in _ORDINALS.items() if number == token),
            *(word for word, number in _CARDINALS.items() if number == token)]


def _first(words: list[str], text: str) -> re.Match | None:
    found = [m for word in words
             for m in [re.search(rf"(?<![\w]){re.escape(word)}(?![\w])", text, re.IGNORECASE)]
             if m]
    return min(found, key=lambda m: m.start(), default=None)


def _bound_to_unit(mentions: list[str], text: str, unit_words: list[str]) -> bool:
    """The target is tied to a pane/tab word: "the vim pane", "the pane on the
    right", "tab 4", "the second tab", "the tab called logs".

    A bare word after a closing verb names a program, not its pane. Measured:
    "quit vim in the right pane" -> close_pane(vim), and "kill top in the left
    pane" -> close_pane(top), which a side word would have made "above".
    """
    units = "|".join(re.escape(word) for word in unit_words)
    for mention in mentions:
        word = re.escape(mention)
        if re.search(rf"(?<![\w]){word}[\"'`]?\s+(?:{units})\b"
                     rf"|\b(?:{units})\s+(?:(?:called|named|titled|labell?ed|running|with|number)\s+"
                     rf"|(?:on|to|at)\s+(?:the\s+)?)?[\"'`]?{word}(?![\w])",
                     text, re.IGNORECASE):
            return True
    return False


_LOCATION = re.compile(r"(?:(?:\s+over)?\s+(?:in|into|on|at)\s+(?:the\s+)?(?:[\w.+-]+\s+){0,2}"
                       r"(?:pane|panes|window|split|tab)\b.*"
                       r"|\s+(?:here|there|in\s+here|in\s+there|in\s+it))$",
                       re.IGNORECASE)


def _unquoted(text: str) -> str:
    return re.sub(r"(?<![\w])(['\"`])(?:\\.|(?!\1).)*?\1",
                  lambda m: " " * len(m[0]), text)


def _clauses(prompt: str) -> list[str]:
    """Split conjunctions outside quoted commands; apostrophes in words are not quotes."""
    # Quoted spans are blanked with a placeholder, not spaces: a separator's \s*
    # swallowed blank space, and "type `touch /x` and press Enter" lost its
    # command into the "and" between clauses.
    masked = re.sub(r"(?<![\w])(['\"`])(?:\\.|(?!\1).)*?\1", lambda m: "\x00" * len(m[0]), prompt)
    bounds = list(_CLAUSE.finditer(masked))
    starts = [0] + [m.end() for m in bounds]
    ends = [m.start() for m in bounds] + [len(prompt)]
    return [prompt[a:b] for a, b in zip(starts, ends)]


# "in the vim pane, run make": a location said before the command's clause.
_FRONTED = re.compile(r"^\s*(?:over\s+)?(?:in|into|on|at)\s+(?:the\s+)?(?:(?:[\w.+-]+\s+){0,2}"
                      r"(?:pane|window|split)|(?:pane|window|split)\s+(?:(?:titled|named|called|labell?ed)\s+)?"
                      r"[\"'`]?[\w.+@:-]+[\"'`]?)(?:\s+in\s+(?:this|the\s+current)\s+tab)?\s*$", re.I)
# "go to the chat pane and type clear there": "there" is the pane just gone to.
_GONE_TO = re.compile(r"^\s*(?:go|switch|jump|move|head|hop)\s+(?:over\s+)?to\s+"
                      r"((?:the\s+)?(?:[\w.+-]+\s+){0,2}(?:pane|window|split))\s*$", re.I)
# "tab five, close it": "it" is a bare reference in the clause before.
_DONE_WITH = re.compile(r"^\s*(?:i'?m\s+|i am\s+)?(?:done|finished)\s+with\s+", re.I)


def _run_units(prompt: str) -> list[str]:
    """The clauses, plus each run clause with a location its neighbour gives it."""
    clauses = _clauses(prompt)
    units = list(clauses)
    for before, clause in zip(clauses, clauses[1:]):
        if _FRONTED.match(before):
            units.append(f"{clause.rstrip(' .!?')} {before.strip()}")
        gone = _GONE_TO.match(before)
        if gone:
            there = re.sub(r"\b(?:in\s+)?there(?=[\s.!?]*$)", f"in {gone[1]}", clause,
                           count=1, flags=re.I)
            if there != clause:
                units.append(there)
    return units


def _resolve_it(verb: re.Pattern, clauses: list[str]) -> list[str]:
    """ "tab five, close it" -> "close tab five": only when the clause before is
    a bare reference, so "tab 2 has vim, close it" (vim) stays unsupported."""
    resolved = list(clauses)
    for i in range(1, len(clauses)):
        said = re.fullmatch(rf"\s*({verb.pattern})\s+it[\s.!?]*(?:please[\s.!?]*)?",
                            clauses[i], re.I)
        antecedent = _DONE_WITH.sub("", clauses[i - 1]).strip()
        if said and _BARE_REFERENCE.match(antecedent):
            resolved[i] = f"{said[1]} {antecedent}"
    return resolved


_NEGATION = re.compile(
    r"\b(?:not|never|don't|do not|dont|avoid|avoiding|without|stop|cannot|can't|cant|"
    r"won't|wont|shouldn't|no need to|neither|nor)\b", re.I)
# Reported or quoted speech before a close: "the error says close the left pane".
_REPORTED = re.compile(r"\b(?:echo|echoes|print|prints|says|said|say|saying|reads|writes|"
                       r"wrote|tells|told|note|notes)\b", re.I)


_OBJECT_END = re.compile(
    r"\s*(?:\(|(?<![\w-])(?:but|except|instead|rather|not|so|because|before|after|unless|"
    r"until|while|since|though|although|keep|keeping|leave|leaving|than|once|if|when|of|"
    r"next to|beside|besides|near)(?![\w-]))", re.I)   # "the leave-tracker tab" is a name


def _negated(prefix: str) -> bool:
    # Measured (review KN-02): "avoid closing tab 2" and "without closing tab
    # 2, go to tab 3" closed tab 2; the list knew five words.
    return bool(_NEGATION.search(prefix))


def _in_title(prefix: str) -> bool:
    # Names are data even without wrappers: renaming a pane to "close the
    # left pane" must not authorize an additional close proposed by a model.
    return bool(re.search(r"\b(?:rename|name|title|call|named|called|titled)\b", prefix, re.I))


_START_VERB = re.compile(r"\b(?:run|running|start|starting|launch|launching|with)\b|(?<!\S)w/", re.I)
_POLITE_SUFFIX = re.compile(r"\s+(?:please|pls|plz|thanks|thank you)[.!?]*$", re.I)
_OPEN_VERB = re.compile(r"\bopen\b", re.I)
_NAMED_SUFFIX = re.compile(r"\s+(?:called|named|titled)\s+\S.*$", re.I)


def _introduces_name(value: str, prompt: str) -> bool:
    """A new pane's or tab's name is said as a name: "called logs", "name it
    logs", "a tab for logs", "a logs tab". Measured (tuned model): "split the
    window and start less" -> name "the window".
    """
    v = re.escape(value)
    return re.search(rf"\b(?:called|named|titled|labelled|labeled|name it|call it|for)\s+"
                     rf"['\"`]?{v}['\"`]?(?![\w])"
                     rf"|\b(?:a|an|new|the)\s+{v}\s+(?:tab|pane|split|window)\b",
                     prompt, re.I) is not None


def _program_spans(prompt: str, name: str = "") -> set[str]:
    """What the request asks to start: the whole text after a start verb, up to a
    location or a name ("split right running htop -d 5 called mon" -> "htop -d 5"),
    or what "open" governs when a location follows ("open htop in a pane below").

    A program is started as argv, so it is held to the same standard as a typed
    command. Measured with the base model: "split the screen" -> program
    "screen", "open the pod bay doors" -> "bay doors", "type git status in the
    right pane" -> "type git", "switch to the next tab" -> "next".
    """
    spans = set()
    if name:
        # The admitted name is data, and nothing inside it is an instruction:
        # "open a tab called frontend running vim" starts vim, while in "open a
        # tab called run htop" the whole "run htop" is the name.
        prompt = re.sub(rf"\b(?:called|named|titled)\s+{re.escape(name)}(?![\w])", " ",
                        prompt, flags=re.I)
    for clause in _clauses(prompt):
        plain = _unquoted(clause)
        for verb, needs_location in ((_START_VERB, False), (_OPEN_VERB, True)):
            for match in verb.finditer(plain):
                if _negated(clause[:match.start()]) or _in_title(clause[:match.start()]):
                    continue
                rest = _POLITE_SUFFIX.sub("", _NAMED_SUFFIX.sub("", clause[match.end():]).strip())
                where = _LOCATION.search(" " + rest)
                if where and re.match(r"\s+(?:in|into|on|at)\s+the\s+", where.group(0), re.I):
                    continue    # "run ls -la in the right split": an existing pane, a command
                bare = _LOCATION.sub("", rest).strip().strip(".!?")
                # "with btop inside": where it runs, not an argument (held-out v14).
                bare = re.sub(r"\s+(?:inside|in it|in there|in here|there|inside it)$", "",
                              bare, flags=re.IGNORECASE)
                if needs_location and bare == rest.strip(".!?"):
                    continue    # "open the pod bay doors": nothing says where
                if bare and not re.match(r"(?:a|an|the|another)?\s*(?:new\s+)?"
                                         r"(?:pane|tab|window|split|terminal)\b", bare, re.I):
                    spans.add(bare)
    return spans


# Common shell commands and builtins. Deterministic on purpose: a PATH lookup
# would make the same request admissible on one host and not another.
_KNOWN_COMMANDS = frozenset("""
    alias apt awk bash bat btop bun cargo cat cd chmod chown clear cmake cp curl cut date
    deno df diff dig docker du echo emacs env exit export fd find fish free gcc gdb git
    glances go gradle grep gzip head helix history hostname htop hx ip ipython irb java
    jobs journalctl jq kill kubectl lazygit less ln ls lsblk lsof make man mc mkdir more
    mv nano ncdu nc nix node npm npx nvim nvtop pacman perl php pip pip3 ping pip pnpm
    podman printenv ps psql pwd pytest python python3 ranger rg rm rmdir rsync ruby rustc
    scp sed sh sleep sort source sqlite3 ssh sudo systemctl tail tar tee tig tmux top
    touch tree uname uniq unzip uptime uv vi vim watch wc wget which whoami xargs yarn
    yay zip zsh basename dirname dmesg dd file groups id lscpu lspci lsusb mount nproc
    printf readlink realpath seq stat sync test true false umount whereis yes
""".split())


def _looks_like_command(command: str, prompt: str = "") -> bool:
    """A known command, a path, an assignment, or text the user quoted as code."""
    first = command.split()[0] if command.split() else ""
    quoted = any(f"{q}{command}{q}" in prompt for q in ("`", "'", '"'))
    return quoted or first in _KNOWN_COMMANDS or bool(re.match(r"[./~$]|.*[/=]", first))


def _command_spans(prompt: str) -> set[str]:
    """Return exact, case-sensitive command spans, retaining punctuation inside quotes."""
    spans = set()
    for clause in _clauses(prompt):
        # Only the first run verb: `run npm run dev` must not also admit `dev`.
        match = _RUN_VERB.search(_unquoted(clause))
        if (match is None or _negated(clause[:match.start()])
                or _in_title(clause[:match.start()])):
            continue
        span = clause[match.end():].strip()
        span = re.sub(r"^(?:the\s+command\s+)", "", span, flags=re.I)
        if span[:1] in ("'", '"', "`"):
            quoted = re.fullmatch(r"(['\"`])((?:\\.|(?!\1).)*)\1(.*)", span)
            if quoted is None:
                continue
            suffix = re.sub(r"\s+please[.!?]*$", "", quoted[3], flags=re.I)
            suffix = _LOCATION.sub("", suffix).strip().strip(".!?")
            if suffix:
                continue
            span = quoted[2]
        else:
            span = re.sub(r"\s+please[.!?]*$", "", span, flags=re.I)
            span = _LOCATION.sub("", span).strip()
            span = re.sub(r"\s+please[.!?]*$", "", span, flags=re.I)
        if span:
            spans.add(span)
    return spans


def _clause_supports(verb: re.Pattern, target: str, prompt: str, *, unit: str,
                     typed: str = "") -> bool:
    """Some one clause of the request holds the verb, this target and its unit.

    "close tab 2 and go to tab 1" has a closing verb, but only in the clause
    naming tab 2; a close of tab 1 is not supported by anything the user said.
    The unit guards the other measured confusion: "close the htop pane" came
    back as close_tab, and a tab is titled after its active pane, so a tab
    called htop can exist. A tab close needs a clause that says tab; a pane
    action is refused from a clause that names only a tab.

    A close also needs the pane or tab as the verb's object: in "exit vim in
    the left pane" (measured: close_pane(left)) what is exited is vim, and the
    pane is only where. For a typed command the target must be named outside
    the command text: "run htop" does not name a pane called htop (measured:
    run_in_pane(pane=htop, command=htop)).
    """
    clauses = _clauses(prompt) if typed else _resolve_it(verb, _clauses(prompt))
    for clause in clauses:
        if unit == "tab" and not _TAB_WORD.search(clause):
            continue
        if unit == "pane" and _TAB_WORD.search(clause) and not _PANE_WORD.search(clause):
            continue
        if typed:
            index = clause.casefold().find(typed.casefold())
            if index >= 0:
                clause = clause[:index] + " " + clause[index + len(typed):]
        match = verb.search(_unquoted(clause))
        if (match is None or _negated(clause[:match.start()])
                or _in_title(clause[:match.start()])
                or (not typed and _REPORTED.search(clause[:match.start()]))):
            continue
        if typed:
            if target == "current":
                # A default target must not override an explicit other pane.
                rest = verb.sub(" ", clause).casefold()
                words = set(re.findall(r"[\w-]+", rest))
                if words <= {"the", "a", "pane", "panes", "window", "split", "current",
                             "this", "here", "active", "focused", "in", "into", "on",
                             "at", "inside", "within", "please", "command"}:
                    return True
            elif _first(_mentions(target), clause):
                return True
            continue
        if _RUN_VERB.search(_unquoted(clause[:match.start()])):
            continue  # a close mentioned inside a command is not a pane instruction
        tail = clause[match.end():]
        # The verb's object ends where another thought begins. Measured (review
        # KN-01): "close tab 1 so I can focus on tab 2" closed tab 2, because
        # the target only had to be named somewhere after the verb.
        cut = _OBJECT_END.search(tail)
        if cut:
            tail = tail[:cut.start()]
        if target == "current":
            words = set(tail.casefold().strip().rstrip(".!?").split())
            if words and words <= _BARE_OBJECT and words - {"please", "now", "the"}:
                return True
            continue
        # The object is the first pane/tab word or target mention after the
        # verb, reached without a locative; the target itself must be named.
        unit_words = ["tab", "tabs"] if unit == "tab" else ["pane", "panes", "window", "split"]
        first = _first(_mentions(target) + unit_words, tail)
        if first is None or _LOCATIVE.search(tail[:first.start()]):
            continue
        # A directional alias inside an explicitly named target is not evidence
        # for a side: `pane running top` must never authorize `pane=above`.
        evidence = tail if target.startswith("name:") else re.sub(
            rf"\b{_AS_NAME}[\w.+-]+", "", tail, flags=re.I)
        # Bound to the unit implies the target is named at all.
        if not _bound_to_unit(_mentions(target), evidence, unit_words):
            continue
        return True
    return False


def _shape_error(args: dict, schema: dict) -> str:
    if set(args) - set(schema["properties"]):
        return "unknown argument"
    if any(key not in args for key in schema.get("required", [])):
        return "missing required argument"
    for key, value in args.items():
        kind = schema["properties"][key]["type"]
        if (kind == "string" and not isinstance(value, str)
                or kind == "integer" and type(value) is not int
                or kind == "boolean" and type(value) is not bool):
            return f"{key} must be {kind}"
        if isinstance(value, str) and any(ord(c) < 32 or ord(c) == 127 for c in value):
            return f"{key} contains a control character"
    return ""


def _new_action(name: str, args: dict, prompt: str) -> Action | Refusal:
    if name in ("maximize_pane", "rename_pane"):
        target = _named_target(name, "pane", {"pane": args.get("pane", "current")}, prompt)
        if isinstance(target, Refusal):
            return target
        if name == "rename_pane":
            title = _text(args, "name")
            if not title or title.casefold() in _UNIT_NAMES:
                return Refusal(name, "the request needs a pane title")
            for clause in _clauses(prompt):
                # Strip the new title before looking for the target: a title cannot
                # double as evidence that the user named a different pane to rename.
                match = re.search(r"(?:['\"`]?)" + re.escape(title) +
                                  r"(?:['\"`]?)[.!?]*$", clause)
                if not match:
                    continue
                prefix = re.sub(r"\s+(?:to|as|read)\s*$", "", clause[:match.start()]).strip()
                # "set the title of the pane left": the pane after "of" is the object.
                prefix = re.sub(r"\b(title|name|label) of\b", r"\1", prefix, flags=re.I)
                if _clause_supports(re.compile(r"\b(?:rename|retitle|title|call|name|label)\b",
                                               re.I), target, prefix, unit="pane"):
                    return Action(name, {"pane": target, "name": title})
                # The pane named before a noun: "set this pane title", "change the
                # pane name", "give the current pane the name" (blind corpus).
                if target == "current" and re.fullmatch(
                        r"(?:please )?(?:set|change|make|give) (?:the )?(?:(?:this|current|"
                        r"active|focused) )?pane(?:'s)? (?:the )?(?:title|name|label)", prefix, re.I):
                    return Action(name, {"pane": target, "name": title})
        else:
            restore = args.get("restore", False)
            pattern = (r"\b(?:restore|unmaximize|un-maximize|unzoom|un-zoom)\b" if restore
                       else r"(?<![\w-])(?:maximize|zoom)\b")
            verb = re.compile(pattern, re.I)
            # Phrasings that name no verb from the list but only mean this action.
            # Blind-authored corpus (kilix-ml): "make this pane fill the window",
            # "expand this pane to full size", "bring back the split view".
            whole = (re.compile(r"\b(?:bring back|return to|go back to) (?:the )?"
                                r"(?:split view|normal (?:pane )?layout|previous (?:pane )?layout)"
                                r"|\brestore all panes\b", re.I) if restore else
                     re.compile(r"\b(?:fill(?:s)? the (?:whole )?window|(?:to |at )?full[- ]"
                                r"(?:size|screen)|show only)\b", re.I))
            for clause in _clauses(prompt):
                if _clause_supports(verb, target, clause, unit="pane"):
                    return Action(name, {"pane": target, "restore": restore})
                if (whole.search(_unquoted(clause)) and _PANE_WORD.search(clause)
                        and not _TAB_WORD.search(clause) and not _negated(clause)
                        and not _RUN_VERB.search(_unquoted(clause))
                        and (target == "current" and not any(
                            _first(_mentions(side), clause) for side in SIDES)
                             or target != "current" and _first(_mentions(target), clause))):
                    return Action(name, {"pane": target, "restore": restore})
                if restore and target == "current" and whole.search(clause) \
                        and not _TAB_WORD.search(clause) and not _negated(clause):
                    return Action(name, {"pane": target, "restore": True})
                if restore and target == "current" and re.fullmatch(
                        r"(?:please )?restore (?:the )?(?:previous |last )?(?:pane )?layout[.!?]*",
                        clause, re.I):
                    return Action(name, {"pane": target, "restore": True})
    elif name == "swap_panes":
        side = _text(args, "side")
        if side in SIDES:
            # A swap names two panes, and clauses split at "and": "exchange this
            # pane | the lower pane". Adjacent clauses are also tried joined, but
            # never across a close or run: "swap this pane and close the left one".
            clauses = _clauses(prompt)
            joined = [f"{a} and {b}" for a, b in zip(clauses, clauses[1:])
                      if not _CLOSE_VERB.search(f"{a} {b}") and not _RUN_VERB.search(f"{a} {b}")]
            for clause in clauses + joined:
                verb = re.search(r"\b(?:swap|exchange|trade|reverse the positions)\b"
                                 r"|\bswitch (?:places|positions|this pane with|with)\b"
                                 r"|\bput this pane where\b", _unquoted(clause), re.I)
                if (verb and not _negated(clause[:verb.start()])
                        and not _RUN_VERB.search(_unquoted(clause[:verb.start()]))
                        and (_PANE_WORD.search(clause)
                             or re.search(r"\bneighbou?r\b", clause, re.I))
                        and not _TAB_WORD.search(clause) and _first(_mentions(side), clause)):
                    return Action(name, {"side": side})
    elif name == "move_tab":
        if ("direction" in args) == ("position" in args):
            return Refusal(name, "give exactly one of direction or position")
        direction, position = args.get("direction"), args.get("position")
        if direction is not None and direction not in ("left", "right"):
            return Refusal(name, "tab direction must be left or right")
        if position is not None and not 1 <= position <= 9:
            return Refusal(name, "tab position must be 1 to 9")
        for clause in _clauses(prompt):
            verb = re.search(r"\b(?:move|shift|reorder)\b", _unquoted(clause), re.I)
            if (not verb or _negated(clause[:verb.start()]) or not _TAB_WORD.search(clause)
                    or _RUN_VERB.search(_unquoted(clause[:verb.start()]))):
                continue
            # This action moves only the caller's tab. Never reinterpret a named
            # or numbered source tab as the current one.
            tail = clause[verb.end():].strip()
            source = re.match(r"(?:the )?(?:this |current |active |focused )?tab\b", tail, re.I)
            if not source:
                continue
            destination = tail[source.end():].strip()
            if direction and re.fullmatch(r"(?:to (?:the )?)?" + direction + r"[.!?]*", destination, re.I):
                return Action(name, {"direction": direction})
            if position is not None:
                forms = "|".join(re.escape(x) for x in _mentions(str(position)))
                if re.fullmatch(r"to (?:the )?(?:(?:position|slot) )?(?:" + forms +
                                r")(?: (?:position|slot))?[.!?]*", destination, re.I):
                    return Action(name, {"position": position})
    return Refusal(name, "no part of the request supports this action and its arguments")


def _admit(name: str, args: dict, prompt: str) -> Action | Refusal:
    if name in ("maximize_pane", "rename_pane", "swap_panes", "move_tab"):
        return _new_action(name, args, prompt)
    if name in ("close_pane", "close_tab") and not _CLOSE_VERB.search(prompt):
        return Refusal(name, "the request does not ask to close anything")
    if name == "run_in_pane" and not _RUN_VERB.search(prompt):
        return Refusal(name, "the request does not ask to run or type a command")
    if name == "run_in_pane":
        command = _text(args, "command")
        # An unquoted command does not run on into English: "type git status so
        # I can see what's staged" would type the reason too (held-out v12).
        quoted = [inner for _quote, inner in re.findall(r"([\"'`])(.*?)\1", prompt)]
        if command and command not in quoted and re.search(
                r"(?<![\w-])(?:so (?:that )?(?:i|we|you)|so i can|because|since i|in order to|"
                r"to (?:see|check|find|know|make sure))(?![\w-])", command, re.IGNORECASE):
            return Refusal(name, "the command runs on into the reason for it")

    if name in ("open_pane", "open_tab"):
        # A grounded title alone does not authorize creation.
        if inventory_unit(prompt) is not None:
            return Refusal(name, "an inventory request does not authorize opening a pane or tab; use kilix pane list")
        unquoted = _unquoted(prompt)
        inspection = re.match(
            r"^(?:(?:please|can you|could you)\s+)*(?:find|list|show|read|inspect|locate|search)\s+"
            r"(?:(?:the|all|my|existing|current)\s+)*(?:panes?|tabs?)\b", unquoted, re.I)
        if inspection and not re.search(r"\b(?:open|create|split|spawn|add|make)\s+(?:a\s+|new\s+|another\s+|the\s+)*(?:pane|tab)\b", unquoted, re.I):
            return Refusal(name, "an inspection request does not authorize opening a pane or tab; use kilix pane list")
        out = {}
        if name == "open_pane":
            side = _text(args, "side")
            if side and side not in SIDES:
                return Refusal(name, f"unknown side {side!r}")
            if side:
                out["side"] = side
        for key in ("program", "name"):
            value = _LEADING_VERBS.sub("", _text(args, key)) if key == "program" else _text(args, key)
            if key == "name" and value.casefold() in _UNIT_NAMES:
                value = ""  # measured: "new tab" -> open_tab(name="new tab")
            if value:
                if not _grounded(value, prompt):
                    return Refusal(name, f"the {key} {value!r} is not in the request")
                out[key] = value
        if name == "open_tab" and not _TAB_WORD.search(prompt):
            return Refusal(name, "the request does not ask for a tab")
        if name == "open_pane" and _TAB_WORD.search(prompt) and not re.search(
                r"\b(?:panes?|splits?|splitting|windows?|terminals?)\b", prompt, re.I):
            return Refusal(name, "the request asks for a tab, not a pane")
        if "name" in out and not _introduces_name(out["name"], prompt):
            return Refusal(name, f"nothing in the request names it {out['name']!r}")
        if "program" in out and out["program"] not in _program_spans(prompt, out.get("name", "")):
            return Refusal(name, f"the program {out['program']!r} is not what the request "
                                 "asks to start")
        if "side" in out:
            # The side must be said outside the program and the name: in "open a
            # pane running bottom" the model read "bottom" as below (measured).
            rest = prompt
            for key in ("program", "name"):
                if key in out:
                    rest = re.sub(rf"(?<![\w]){re.escape(out[key])}(?![\w])", " ", rest,
                                  flags=re.I)
            # "open up a new pane": a phrasal up/down is not a direction (measured,
            # tuned model: side above from "open up").
            rest = _without_phrasals(rest)
            if not _first(_mentions(out["side"]), rest):
                return Refusal(name, f"the request does not say {out['side']}")
        return Action(name, out)

    if name in ("close_pane", "go_to_pane", "run_in_pane"):
        target = _named_target(name, "pane", args, prompt)
        if isinstance(target, Refusal):
            return target
        command = _text(args, "command") if name == "run_in_pane" else ""
        if name == "run_in_pane":
            if not command or not _grounded(command, prompt):
                return Refusal(name, f"the command {command!r} is not in the request")
            if _RUN_VERB.fullmatch(command):
                # measured: "run make test in the left pane" -> command "run"
                return Refusal(name, f"the command {command!r} is only the verb")
            if (target == "current" and not re.search(
                    r"\b(?:here|there|this (?:pane|window|split)|current (?:pane|window))\b",
                    prompt, re.I) and not _looks_like_command(command, prompt)):
                # Only implied "this pane" and no location: measured (tuned model),
                # "type faster, I'm bored" -> command "faster".
                return Refusal(name, f"{command!r} does not look like a command")
        if name == "run_in_pane":
            # One clause must hold the verb, this pane and exactly this command.
            # Measured (tuned model): "run make in the left pane and run make test
            # in the right pane" -> "make test" in both panes; each half was
            # supported somewhere, but not together.
            if not any(command in _command_spans(clause)
                       and _clause_supports(_RUN_VERB, target, clause, unit="pane", typed=command)
                       for clause in _run_units(prompt)):
                return Refusal(name, "no part of the request asks to type that into that pane")
        elif name == "close_pane" and not _clause_supports(_CLOSE_VERB, target, prompt,
                                                           unit="pane"):
            return Refusal(name, "no part of the request asks for this on that pane")
        if name == "go_to_pane" and not _moves(prompt):
            return Refusal(name, "the request does not ask to go anywhere")
        out = {"pane": target}
        if name == "go_to_pane":
            scope = _navigation_scope(prompt)
            if isinstance(scope, Refusal):
                return scope
            if scope:
                out["pane_scope"] = scope
        if name == "run_in_pane":
            out["command"] = command
        return Action(name, out)

    if name in ("close_tab", "go_to_tab"):
        target = _named_target(name, "tab", args, prompt)
        if isinstance(target, Refusal):
            return target
        if name == "close_tab" and not _clause_supports(_CLOSE_VERB, target, prompt, unit="tab"):
            return Refusal(name, "no part of the request asks to close that tab")
        if name == "go_to_tab" and not _moves(prompt):
            return Refusal(name, "the request does not ask to go anywhere")
        return Action(name, {"tab": target})

    if name == "arrange_panes":
        layout = _text(args, "layout")
        if layout not in LAYOUTS:
            return Refusal(name, f"unknown layout {layout!r}")
        return Action(name, {"layout": layout})

    if name == "rename_tab":
        title = _text(args, "name")
        if not title or not _grounded(title, prompt):
            return Refusal(name, f"the name {title!r} is not in the request")
        if title.casefold() in _UNIT_NAMES or title.casefold() in ("panes", "tabs"):
            # measured (five-tool schema): "make this pane wider by 10" -> tab_name "pane"
            return Refusal(name, f"{title!r} is not a name for a tab")
        # The new title is a value, not another target. In particular, renaming
        # the caller to "tab 2" must never choose the second tab.
        value = re.search(r"\b(?:to|as)\s+(['\"`]?)" + re.escape(title)
                          + r"\1(?![\w-])", prompt, re.I)
        target_prompt = prompt[:value.start()] + prompt[value.end():] if value else prompt
        if not value and re.search(r"\b(?:tab|pane|window)\s+(?:id\s+)?[0-9]", title, re.I):
            return Refusal(name, "the new title contains target syntax; use 'rename tab id N to TITLE'")
        target = _mutation_target(name, "tab", args, target_prompt)
        if isinstance(target, Refusal):
            return target
        rename_args = {"name": title, **({"tab": target} if target else {})}
        # The request must ask for a rename in the clause that holds the new name:
        # measured (route benchmark, qat-6): "in the pane titled bench-target, type
        # `touch /x` and press Enter" renamed the tab to the command, "type into
        # the pane named t: ... Press Enter" renamed it "enter", and "rename the
        # active pane to x" renamed the tab. A name that is typed, run or pressed
        # is not a title, and a clause that names only a pane renames a pane.
        for clause in _clauses(prompt):
            at = re.search(r"(?<![\w-])" + re.escape(title) + r"(?![\w-])", clause, re.I)
            if not at:
                continue
            before = clause[:at.start()]
            if re.search(r"\b(?:type|typing|run|running|execute|enter|send|press|hit|paste)\b"
                         r"[^,;]*$", before, re.I) and not re.search(
                             r"\b(?:rename|retitle|relabel|call|name|title|label)\b[^,;]*$",
                             before, re.I):
                continue
            rest = clause[:at.start()] + " " + clause[at.end():]
            verb = re.search(r"\b(?:rename[sd]?|renaming|retitle|relabel|title[sd]?|call(?:ed)?|"
                             r"name[sd]?|label(?:l?ed)?|reads)\b|\bmake (?:this |the |current |my )*tab\b",
                             rest, re.I)
            if verb is None or _negated(rest[:verb.start()]) or _REPORTED.search(rest[:verb.start()]):
                continue
            if _PANE_WORD.search(rest) and not _TAB_WORD.search(rest):
                return Refusal(name, "the request renames a pane, not a tab")
            return Action(name, rename_args)
        # Terse or split forms from the training corpus: "tab: logs", and "tab's
        # for api, rename it accordingly" (the verb in the next clause).
        if re.fullmatch(r"\s*tab\s*:\s*" + re.escape(title) + r"[.!?]*\s*", prompt, re.I):
            return Action(name, rename_args)
        verb_anywhere = re.search(r"\b(?:rename|retitle|relabel)\b", prompt, re.I)
        for clause in _clauses(prompt):
            at = re.search(r"(?<![\w-])" + re.escape(title) + r"(?![\w-])", clause, re.I)
            if (verb_anywhere and at and _TAB_WORD.search(clause) and not _PANE_WORD.search(clause)
                    and not re.search(r"\b(?:type|typing|run|running|execute|enter|send|press|hit|"
                                      r"paste)\b", clause[:at.start()], re.I)
                    and not _negated(prompt) and not _REPORTED.search(clause[:at.start()])):
                return Action(name, rename_args)
        return Refusal(name, f"no part of the request renames the tab to {title!r}")

    # resize_pane
    direction = _text(args, "direction")
    if direction not in DIRECTIONS:
        return Refusal(name, f"unknown direction {direction!r}")
    if not _says_direction(direction, prompt):
        # Measured (tuned model): "increase the font size" -> narrower, and
        # "widen this pane by 20" -> narrower. The direction was never checked.
        return Refusal(name, f"the request does not ask for {direction}")
    try:
        requested_amount = _resize_amount(direction, prompt)
    except ValueError as error:
        return Refusal(name, str(error))
    amount = args.get("amount", requested_amount if requested_amount is not None else 2)
    if isinstance(amount, bool) or not isinstance(amount, int) or not 1 <= amount <= 50:
        return Refusal(name, "the size change must be 1 to 50 cells")
    if "amount" in args and amount != requested_amount:
        return Refusal(name, f"the amount {amount} is not the requested size change")
    target = _mutation_target(name, "pane", args, prompt)
    if isinstance(target, Refusal):
        return target
    return Action(name, {"direction": direction, "amount": amount,
                         **({"pane": target} if target else {})})
