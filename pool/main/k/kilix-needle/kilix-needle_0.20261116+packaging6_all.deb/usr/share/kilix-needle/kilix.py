"""Resolve admitted actions against the live Kilix tree and run them.

Everything goes through `kilix @` over the instance socket, as argv, never a
shell. A reference is resolved against one `kilix @ ls` snapshot to exactly
one pane or tab by id; anything ambiguous or missing is refused with the
candidates named, not guessed.

Submitting a command into an existing pane requires the shell editor to verify
its input state at submission. Kilix only exposes prompt marks, so a legacy
run_in_pane request resolves its target and refuses before any terminal input.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
import os
import re
import shlex
import subprocess
import time

from actions import Action

KILIX = os.environ.get("KILIX_NEEDLE_KILIX", "kilix")
MAX_TYPED = 1024
_LOCATION = {"right": "vsplit", "left": "vsplit-before",
             "below": "hsplit", "above": "hsplit-before"}
_NEIGHBOR = {"left": "left", "right": "right", "above": "top", "below": "bottom"}
_RESIZE = {"wider": ("horizontal", 1), "narrower": ("horizontal", -1),
           "taller": ("vertical", 1), "shorter": ("vertical", -1)}


class KilixError(RuntimeError):
    """Kilix could not be read, or an action could not be resolved or run."""


class ShellInputUnverified(KilixError):
    """The target editor cannot verify a fresh command line."""

    def __init__(self, target: str):
        super().__init__(f"Kilix cannot verify the shell input state in {target}. "
                         "Enter the command manually at a fresh shell prompt.")


@dataclass(frozen=True)
class Step:
    """One resolved action: what it will do, in words, and the argv that does it."""
    action: Action
    summary: str
    commands: tuple[tuple[tuple[str, ...], bytes | None], ...]
    closes: frozenset = frozenset()   # ids of every pane this step would close
    # The target was found only as a whole word of a title, not by an exact
    # title or program: never enough for a yes given in advance (KN-R5-01).
    fuzzy: bool = False
    # The name also fits a pane in another tab; the current tab's was chosen.
    # A person must see which one (review KN-R9-01).
    elsewhere: bool = False
    verification: dict | None = None  # explicit mutation identity and observed baseline


def _ancestors() -> list[int]:
    """This process and its parents, nearest first, from /proc."""
    chain, pid = [], os.getpid()
    while pid > 1 and len(chain) < 64:
        chain.append(pid)
        try:
            with open(f"/proc/{pid}/stat", encoding="ascii", errors="replace") as stat:
                # the command name is parenthesised and may contain spaces
                pid = int(stat.read().rsplit(")", 1)[1].split()[1])
        except (OSError, ValueError, IndexError):
            break
    return chain


def _comm(pid: int) -> str:
    try:
        with open(f"/proc/{pid}/comm", encoding="ascii", errors="replace") as comm:
            return comm.read().strip()
    except OSError:
        return ""


def _target() -> list[str]:
    """How to reach this Kilix instance.

    A pane has KITTY_LISTEN_ON. An agent harness may start kilix-needle as a
    tool with a stripped environment (Codex passes only listed variables), so
    the instance is then found as the nearest `kitty` ancestor, whose socket
    Kilix names `unix:@kilix-<pid>`. Anything else is refused, never guessed.
    """
    if os.environ.get("KITTY_LISTEN_ON"):
        return []
    for pid in _ancestors()[1:]:
        if _comm(pid) == "kitty":
            return ["--to", f"unix:@kilix-{pid}"]
    raise KilixError("not running inside Kilix: no KITTY_LISTEN_ON and no Kilix ancestor")


def _run(argv: list[str], data: bytes | None = None) -> str:
    try:
        done = subprocess.run([KILIX, "@", *_target(), *argv], input=data, capture_output=True,
                              timeout=15, check=False)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise KilixError(f"kilix @ {argv[0]} failed: {error}") from error
    if done.returncode != 0:
        detail = done.stderr.decode("utf-8", "replace").strip() or f"status {done.returncode}"
        raise KilixError(f"kilix @ {argv[0]}: {detail}")
    return done.stdout.decode("utf-8", "replace")


def _identities(tree: "Tree") -> dict:
    return {w["id"]: (tab["id"], w.get("pid"), w.get("child_pid"),
                      (w.get("env") or {}).get("KITTY_PTY_BROKER_SESSION"))
            for tab, w in tree._all_panes()}


def _mutation_baseline(tree: "Tree", kind: str, target: dict, args: dict) -> dict:
    value = {"kind": kind, "target_id": target["id"], "identities": _identities(tree),
             "tab_titles": {t["id"]: t.get("title") for t in tree.tabs}}
    if kind == "rename_tab":
        value["expected"] = args["name"]
    else:
        axis, sign = _RESIZE[args["direction"]]
        field = "columns" if axis == "horizontal" else "lines"
        before = target.get(field)
        if not isinstance(before, int) or before <= 0:
            raise KilixError("target geometry is unavailable; no resize attempted")
        value.update(field=field, before=before, expected=before + sign * args["amount"],
                     increment=sign * args["amount"], axis=axis)
    return value


def snapshot(*, under_overlay: bool = False) -> "Tree":
    try:
        data = json.loads(_run(["ls"]))
    except ValueError as error:
        raise KilixError("kilix @ ls returned malformed JSON") from error
    return Tree(data, under_overlay=under_overlay)


def _program(window: dict) -> str:
    processes = window.get("foreground_processes") or []
    for process in processes:
        cmdline = process.get("cmdline") or []
        if cmdline:
            return os.path.basename(str(cmdline[0]))
    return ""


def _describe_pane(window: dict) -> str:
    program = _program(window)
    title = str(window.get("title") or "")
    label = title if not program or program in title else f"{title} ({program})"
    return f"pane {window.get('id')} '{label}'"


class Tree:
    """One `kilix @ ls` snapshot, focused on the OS window being used."""

    def __init__(self, data, *, under_overlay: bool = False):
        if not isinstance(data, list) or not data:
            raise KilixError("kilix reported no windows")
        # "This pane" is the pane kilix-needle was started from, not whichever
        # tab the user happens to be looking at: run from a background tab, the
        # focused pane is someone else's session. Without KITTY_WINDOW_ID (a
        # harness may strip it) the pane is the window whose process is one of
        # ours; that match is exact, so an unrelated window is never chosen.
        own = os.environ.get("KITTY_WINDOW_ID", "")
        ancestry = set(_ancestors()) if not own else set()
        os_window = own_tab = own_pane = None
        for candidate in data:
            for tab in candidate.get("tabs") or []:
                for window in tab.get("windows") or []:
                    if (own and str(window.get("id")) == own) or \
                            (not own and window.get("pid") in ancestry):
                        os_window, own_tab, own_pane = candidate, tab, window
        self.caller = own_pane
        self.fuzzy = False
        self.elsewhere = False
        self._own_tab = own_tab
        if own_pane is not None and under_overlay:
            # Opened from a hotkey as an overlay, the overlay is the active
            # window; the pane the user means is the one it covers.
            history = [wid for wid in own_tab.get("active_window_history") or []
                       if wid != own_pane.get("id")]
            under = next((w for w in own_tab.get("windows") or []
                          if history and w.get("id") == history[-1]), None)
            if under is None:
                raise KilixError("cannot tell which pane the overlay was opened over")
            own_pane = under
        if os_window is None:
            os_window = next((w for w in data if w.get("is_focused")), None) \
                or next((w for w in data if w.get("is_active")), data[0])
        self.tabs = list(os_window.get("tabs") or [])
        if not self.tabs:
            raise KilixError("the Kilix window has no tabs")
        self.active_tab = own_tab or next((t for t in self.tabs if t.get("is_active")),
                                          self.tabs[0])
        windows = self.active_tab.get("windows") or []
        if not windows:
            raise KilixError("the active tab has no panes")
        self.active_pane = own_pane or next((w for w in windows if w.get("is_active")),
                                            windows[0])

    def _all_panes(self):
        for tab in self.tabs:
            for window in tab.get("windows") or []:
                yield tab, window

    def pane(self, ref: str, *, wrap: bool = True, scope: str | None = None) -> dict:
        if scope not in (None, "current"):
            raise KilixError("unsupported pane scope")
        # Filter before ranking or disambiguation: an exact match outside the
        # allowed tab must not hide a unique whole-word match inside it.
        panes = [(tab, window) for tab, window in self._all_panes()
                 if scope is None or tab is self.active_tab]
        if ref == "current":
            return self.active_pane
        if (ref in ("next", "previous") or ref in _NEIGHBOR) and any(
                ref in (_program(w).casefold(), str(w.get("title") or "").strip().casefold())
                for _tab, w in panes):
            # As for tabs: a pane titled or running "next" makes "the next pane"
            # ambiguous (review KN-R9-02).
            raise KilixError(f"'the {ref} pane' is ambiguous: a pane is called {ref!r}")
        if ref in ("next", "previous"):
            windows = self.active_tab.get("windows") or []
            if len(windows) < 2:
                raise KilixError("there is no other pane in this tab")
            index = windows.index(self.active_pane)
            step = 1 if ref == "next" else -1
            if not wrap and not 0 <= index + step < len(windows):
                # Review KN-R6-02: as for tabs, a close or a typed command never
                # wraps round the panes of a tab.
                raise KilixError(f"there is no {ref} pane: this is the "
                                 f"{'last' if ref == 'next' else 'first'} one")
            return windows[(index + step) % len(windows)]
        if ref in _NEIGHBOR:
            # Kitty reports neighbours as window *group* ids (measured: window 31's
            # right neighbour 122 is the group holding window 114). A group's
            # visible window is its last one; an overlay sits on top of the rest.
            ids = (self.active_pane.get("neighbors") or {}).get(_NEIGHBOR[ref]) or []
            if len(ids) != 1:
                raise KilixError(f"there is {'no' if not ids else 'more than one'} pane {ref} "
                                 "of the current one")
            group = next((g for g in self.active_tab.get("groups") or [] if g.get("id") == ids[0]),
                         None)
            members = (group or {}).get("windows") or []
            for window in self.active_tab.get("windows") or []:
                if members and window.get("id") == members[-1]:
                    return window
            raise KilixError(f"the pane {ref} of the current one is not listed")
        if ref.startswith("id:"):
            # A pane id the request states ("pane 70", "pane:70", "#70"): the
            # ids `kilix panes` prints are kitty window ids (route benchmark).
            wanted = int(ref[3:])
            for _tab, window in panes:
                if window.get("id") == wanted:
                    return window
            raise KilixError(f"there is no pane {wanted}")
        name = ref[5:].casefold()

        # Review KN-04: a substring of a title, preferred in the current tab,
        # chose "pleb@host: ~/src/catalog (vim)" for "the log pane" while `log`
        # ran in another tab. An exact program or title wins anywhere (the
        # current tab first); otherwise a whole word of a title, only if unique.
        def exact(window):
            return name in (_program(window).casefold(),
                            str(window.get("title") or "").strip().casefold())

        # Without regard to case, the current tab first. A case-exact
        # preference was tried (review R5, row D) and regressed in three rounds
        # (KN-R6-04, KN-R7-03, KN-R8-01); it is gone.
        local = [w for w in self.active_tab.get("windows") or [] if exact(w)]
        found = local or [w for _tab, w in panes if exact(w)]
        # The current tab's pane wins, but not silently: when the name also
        # fits a pane in another tab ("build" here, "Build" there), a yes given
        # in advance does not cover the choice (review KN-R9-01).
        self.elsewhere = bool(local) and any(
            exact(w) for tab, w in panes if tab is not self.active_tab)
        if not found:
            # Never the requester's own pane: while kilix-needle runs, Kilix
            # titles it with the request itself (review KN-R5-01: "close the
            # webhooks tab" closed its own tab).
            own = {id(w) for w in (self.caller, self.active_pane) if w is not None}
            found = [w for _tab, w in panes
                     if id(w) not in own and _whole_word(name, str(w.get("title") or ""))]
            self.fuzzy = bool(found)
        if len(found) == 1:
            return found[0]
        if not found:
            raise KilixError(f"no pane is called or running {name!r}")
        raise KilixError(f"{name!r} matches several panes: "
                         + ", ".join(_describe_pane(w) for w in found))

    def tab(self, ref: str, *, wrap: bool = True) -> dict:
        index = self.tabs.index(self.active_tab)
        if ref == "current":
            return self.active_tab
        if re.fullmatch(r"id:[0-9]+", ref):
            found = [tab for tab in self.tabs if tab.get("id") == int(ref[3:])]
            if len(found) == 1:
                return found[0]
            raise KilixError(f"tab identity {ref} is absent or ambiguous")
        if re.fullmatch(r"pane:[0-9]+", ref):
            window = self.pane("id:" + ref[5:])
            return next(tab for tab, pane in self._all_panes() if pane is window)
        if ref in ("next", "previous", "last") and any(
                str(t.get("title") or "").strip().casefold() == ref for t in self.tabs):
            # A tab titled "next" makes "the next tab" ambiguous (review R5, row D).
            raise KilixError(f"'the {ref} tab' is ambiguous: a tab is titled {ref!r}")
        if ref in ("next", "previous"):
            step = 1 if ref == "next" else -1
            if not wrap and not 0 <= index + step < len(self.tabs):
                # Review KN-R5-05: a close must not wrap round the tab bar.
                raise KilixError(f"there is no {ref} tab: this is the "
                                 f"{'last' if ref == 'next' else 'first'} one")
            return self.tabs[(index + step) % len(self.tabs)]
        if ref == "last":
            return self.tabs[-1]
        if ref.isascii() and ref.isdigit():   # review KN-R4-07: "\u09ea" is not a 4 here
            number = int(ref)
            if not 1 <= number <= len(self.tabs):
                raise KilixError(f"there is no tab {number}; there are {len(self.tabs)}")
            return self.tabs[number - 1]
        name = ref[5:].casefold() if ref.startswith("name:") else ref.casefold()
        found = [t for t in self.tabs if str(t.get("title") or "").strip().casefold() == name]
        if not found:
            found = [t for t in self.tabs if t is not self._own_tab
                     and _whole_word(name, str(t.get("title") or ""))]
            self.fuzzy = bool(found)
        if len(found) == 1:
            return found[0]
        if not found:
            raise KilixError(f"no tab is called {name!r}")
        raise KilixError(f"{name!r} matches several tabs: "
                         + ", ".join(f"{self.tabs.index(t) + 1} '{t.get('title')}'"
                                     for t in found))

    def describe_tab(self, tab: dict) -> str:
        count = len(tab.get("windows") or [])
        return (f"tab {self.tabs.index(tab) + 1} '{tab.get('title')}' "
                f"({count} pane{'s' if count != 1 else ''})")


def _whole_word(name: str, title: str) -> bool:
    """`name` as whole words of `title`; path characters join a word, so
    "log" is not in "~/src/catalog" and "host" is not in "pleb@host:"."""
    edge = r"[\w./~@:-]"
    return re.search(rf"(?<!{edge}){re.escape(name)}(?!{edge})", title, re.I) is not None


def _program_argv(program: str) -> list[str]:
    try:
        argv = shlex.split(program)
    except ValueError as error:
        raise KilixError(f"cannot split the program {program!r}: {error}") from error
    if not argv:
        raise KilixError("the program is empty")
    return argv


def resolve(action: Action, tree: Tree) -> Step:
    """Bind an admitted action to concrete ids and the argv that performs it."""
    import dataclasses
    tree.fuzzy = tree.elsewhere = False
    step = _resolve(action, tree)
    return dataclasses.replace(step, fuzzy=tree.fuzzy, elsewhere=tree.elsewhere)


def _resolve(action: Action, tree: Tree) -> Step:
    kind, args = action.kind, action.args
    if kind == "open_pane":
        # Measured live: without a tab match, launch opens the pane in whichever
        # tab is active, and --cwd=current takes that tab's directory. Both are
        # bound to the anchor pane explicitly.
        anchor = tree.active_pane
        argv = ["launch", "--type=window", f"--match=window_id:{anchor['id']}",
                f"--source-window=id:{anchor['id']}", "--cwd=current",
                f"--next-to=id:{anchor['id']}"]
        side = args.get("side")
        if side:
            argv.append(f"--location={_LOCATION[side]}")
        if args.get("name"):
            argv.append(f"--title={args['name']}")
        words = f"open a pane{' ' + side if side else ''} of {_describe_pane(anchor)}"
        if args.get("program"):
            argv += ["--", *_program_argv(args["program"])]
            words += f" running {args['program']!r}"
        return Step(action, words, ((tuple(argv), None),))
    if kind == "open_tab":
        argv = ["launch", "--type=tab", f"--source-window=id:{tree.active_pane['id']}",
                "--cwd=current"]
        if args.get("name"):
            argv.append(f"--tab-title={args['name']}")
        words = "open a new tab" + (f" called {args['name']!r}" if args.get("name") else "")
        if args.get("program"):
            argv += ["--", *_program_argv(args["program"])]
            words += f" running {args['program']!r}"
        return Step(action, words, ((tuple(argv), None),))
    if kind in ("close_pane", "go_to_pane"):
        window = tree.pane(args["pane"], wrap=kind == "go_to_pane", scope=args.get("pane_scope"))
        verb = "close" if kind == "close_pane" else "go to"
        command = "close-window" if kind == "close_pane" else "focus-window"
        return Step(action, f"{verb} {_describe_pane(window)}",
                    (((command, f"--match=id:{window['id']}"), None),),
                    frozenset({window["id"]}) if kind == "close_pane" else frozenset())
    if kind in ("close_tab", "go_to_tab"):
        tab = tree.tab(args["tab"], wrap=kind == "go_to_tab")
        verb = "close" if kind == "close_tab" else "go to"
        command = "close-tab" if kind == "close_tab" else "focus-tab"
        return Step(action, f"{verb} {tree.describe_tab(tab)}",
                    (((command, f"--match=id:{tab['id']}"), None),),
                    frozenset(w["id"] for w in tab.get("windows") or [])
                    if kind == "close_tab" else frozenset())
    if kind == "arrange_panes":
        tab = tree.active_tab
        enabled = tab.get("enabled_layouts") or []
        if args["layout"] not in enabled:
            raise KilixError(f"the {args['layout']} layout is not enabled here; "
                             f"enabled: {', '.join(enabled) or 'none'}")
        return Step(action, f"arrange {tree.describe_tab(tab)} as {args['layout']}",
                    ((("goto-layout", f"--match=id:{tab['id']}", args["layout"]), None),))
    if kind == "rename_tab":
        tab = tree.tab(args.get("tab", "current"))
        return Step(action, f"rename {tree.describe_tab(tab)} to {args['name']!r}",
                    ((("set-tab-title", f"--match=id:{tab['id']}", args["name"]), None),),
                    verification=_mutation_baseline(tree, kind, tab, args) if "tab" in args else None)
    if kind == "rename_pane":
        window = tree.pane(args["pane"])
        return Step(action, f"rename {_describe_pane(window)} to {args['name']!r}",
                    ((("set-window-title", f"--match=id:{window['id']}", "--", args["name"]), None),))
    if kind == "maximize_pane":
        window = tree.pane(args["pane"])
        tab = next(t for t, w in tree._all_panes() if w["id"] == window["id"])
        stacked = tab.get("layout") == "stack"
        if args["restore"]:
            commands = ((("last-used-layout", f"--match=id:{tab['id']}"), None),) if stacked else ()
            return Step(action, f"restore the layout of {tree.describe_tab(tab)}", commands)
        if "stack" not in (tab.get("enabled_layouts") or []):
            raise KilixError("the stack layout is not enabled in the target tab")
        commands = ((("focus-window", f"--match=id:{window['id']}"), None),)
        if not stacked:
            commands += ((("goto-layout", f"--match=id:{tab['id']}", "stack"), None),)
        return Step(action, f"maximize {_describe_pane(window)}", commands)
    if kind == "swap_panes":
        anchor = tree.active_pane
        other = tree.pane(args["side"])  # refuses missing or ambiguous neighbours
        # Tab.move_window operates on the tab's active group, not the matched
        # window. Focus the anchor explicitly before invoking it.
        return Step(action, f"swap {_describe_pane(anchor)} with {_describe_pane(other)}",
                    ((("focus-window", f"--match=id:{anchor['id']}"), None),
                     (("action", f"--match=id:{anchor['id']}",
                       f"move_window {_NEIGHBOR[args['side']]}"), None)))
    if kind == "move_tab":
        tab, anchor = tree.active_tab, tree.active_pane
        index = tree.tabs.index(tab)
        destination = (args["position"] - 1 if "position" in args else
                       index + (-1 if args["direction"] == "left" else 1))
        if not 0 <= destination < len(tree.tabs):
            raise KilixError("the requested tab position is outside this window")
        distance = destination - index
        commands = ()
        if distance:
            # Boss.move_tab_forward uses the active OS window. An action match
            # alone does not select either the tab or its OS window.
            commands = ((("focus-window", f"--match=id:{anchor['id']}"), None),)
            verb = "move_tab_forward" if distance > 0 else "move_tab_backward"
            commands += ((("action", f"--match=id:{anchor['id']}", verb), None),) * abs(distance)
        return Step(action, f"move {tree.describe_tab(tab)} to position {destination + 1}", commands)
    if kind == "resize_pane":
        window = tree.pane(args.get("pane", "current"))
        axis, sign = _RESIZE[args["direction"]]
        return Step(action, f"make {_describe_pane(window)} {args['direction']} "
                            f"by {args['amount']}",
                    ((("resize-window", f"--match=id:{window['id']}", f"--axis={axis}",
                       f"--increment={sign * args['amount']}"), None),),
                    verification=_mutation_baseline(tree, kind, window, args) if "pane" in args else None)
    if kind == "run_in_pane":
        window = tree.pane(args["pane"], wrap=False)
        if len(args["command"].encode("utf-8")) > MAX_TYPED:
            raise KilixError("the command is too long to type")
        # A foreground shell and OSC 133 marks can also describe vi command
        # mode, reverse search or PS2. Re-reading them before Enter cannot
        # verify the editor or bind a check to the eventual submission.
        raise ShellInputUnverified(_describe_pane(window))
    raise KilixError(f"no kilix command for {kind}")


def perform(step: Step) -> dict | None:
    if step.action.kind == "run_in_pane":
        raise ShellInputUnverified("the target pane")
    expected = step.verification
    if expected:
        fresh = snapshot()
        if _identities(fresh) != expected["identities"]:
            raise KilixError("pane identity changed; no mutation attempted")
        target = fresh.tab(f"id:{expected['target_id']}") if expected["kind"] == "rename_tab" else fresh.pane(f"id:{expected['target_id']}")
        if (expected["kind"] == "resize_pane" and
                target.get(expected["field"]) != expected["before"]):
            raise KilixError("target geometry changed; no resize attempted")
        if {t["id"]: t.get("title") for t in fresh.tabs} != expected["tab_titles"]:
            raise KilixError("tab titles changed; no mutation attempted")
    for argv, data in step.commands:
        _run(list(argv), data)
    if not expected:
        return None
    # A nested split scales the native increment by its parent's share of the
    # viewport. Correct only an observed nonzero effect, with fresh identities,
    # a fixed final size, and a strict command bound; never retry a clamped/no-op.
    previous = expected.get("before")
    increment = expected.get("increment")
    adjustments = 0
    stable = 0
    last_observed = None
    for attempt in range(20):
        fresh = snapshot()
        if _identities(fresh) != expected["identities"]:
            raise KilixError("mutation sent, but pane identities changed; completion unverified")
        titles = {t["id"]: t.get("title") for t in fresh.tabs}
        wanted_titles = dict(expected["tab_titles"])
        if expected["kind"] == "rename_tab":
            wanted_titles[expected["target_id"]] = expected["expected"]
            observed = titles.get(expected["target_id"])
        else:
            observed = fresh.pane(f"id:{expected['target_id']}").get(expected["field"])
        if titles == wanted_titles and observed == expected["expected"]:
            return {"schema": "kilix.needle.mutation.v1", "target_id": expected["target_id"],
                    "action": expected["kind"], "observed": observed,
                    "expected": expected["expected"], "completion_verified": True,
                    "identities_preserved": True, "other_tab_titles_preserved": True,
                    "resize_corrections": adjustments}
        stable = stable + 1 if observed == last_observed else 0
        last_observed = observed
        if (expected["kind"] == "resize_pane" and titles == wanted_titles
                and isinstance(observed, int) and observed != previous
                and stable >= 2 and adjustments < 4):
            gain = (observed - previous) / increment
            if gain <= 0:
                raise KilixError("resize changed in the wrong direction; completion unverified")
            remaining = expected["expected"] - observed
            correction = round(remaining / gain)
            correction = max(1, min(50, abs(correction))) * (1 if remaining > 0 else -1)
            _run(["resize-window", f"--match=id:{expected['target_id']}",
                  f"--axis={expected['axis']}", f"--increment={correction}"])
            previous, increment, stable = observed, correction, 0
            adjustments += 1
        if attempt < 19:
            time.sleep(0.1)
    raise KilixError("mutation sent, but exact effect or neighboring titles were not verified; do not repeat blindly")
