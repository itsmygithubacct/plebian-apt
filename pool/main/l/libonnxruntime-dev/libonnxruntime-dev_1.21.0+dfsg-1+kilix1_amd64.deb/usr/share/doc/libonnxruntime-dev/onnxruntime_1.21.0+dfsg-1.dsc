-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: onnxruntime
Binary: libonnxruntime1.21, libonnxruntime-dev, onnxruntime-tools, python3-onnxruntime
Architecture: any all
Version: 1.21.0+dfsg-1
Maintainer: Debian Deep Learning Team <debian-ai@lists.debian.org>
Uploaders: Mo Zhou <lumin@debian.org>, Dylan Aïssi <daissi@debian.org>, Shengqi Chen <harry@debian.org>
Homepage: https://github.com/microsoft/onnxruntime
Standards-Version: 4.7.2
Vcs-Browser: https://salsa.debian.org/deeplearning-team/onnxruntime
Vcs-Git: https://salsa.debian.org/deeplearning-team/onnxruntime.git
Testsuite: autopkgtest
Testsuite-Triggers: build-essential, pkgconf, python3-numpy, python3-onnx, python3-torch
Build-Depends: debhelper-compat (= 13), dh-exec, dh-sequence-python3, dh-sequence-numpy3, cmake, libboost-dev, libcpuinfo-dev (>= 0.0~git20240830.fa1c679), libdlpack-dev, libeigen3-dev (>= 3.4.0), libflatbuffers-dev, libhowardhinnant-date-dev, libmsgsl-dev, libonnx-dev, libpng-dev, libprotobuf-dev, libpthreadpool-dev, libsafeint-dev, libre2-dev, libdnnl-dev [amd64 arm64 ppc64el s390x], libxnnpack-dev (>= 0.0~git20241108.4ea82e5~) [amd64 arm64 armhf i386 riscv64 x32], ninja-build, nlohmann-json3-dev, protobuf-compiler, pkgconf, python3-all, python3-all-dev, python3-numpy, python3-onnx, python3-packaging, python3-protobuf, python3-pybind11, python3-setuptools, python3-wheel, zlib1g-dev
Package-List:
 libonnxruntime-dev deb libdevel optional arch=any
 libonnxruntime1.21 deb libs optional arch=any
 onnxruntime-tools deb science optional arch=all
 python3-onnxruntime deb python optional arch=any
Checksums-Sha1:
 1affe31666bf7e6ed3ca235b19dae8170ecc9cd8 37970624 onnxruntime_1.21.0+dfsg.orig.tar.xz
 585f19482e4676123a61cd33a96051ed1d072f8f 21704 onnxruntime_1.21.0+dfsg-1.debian.tar.xz
Checksums-Sha256:
 32df1f82bd6b07b18372c0f387133214905cbde7a586b3ad83f0ed0075f80273 37970624 onnxruntime_1.21.0+dfsg.orig.tar.xz
 8bd81c87dea02ed3d27cc479a4fb1c1ae7f2f5bd5fc8c573cb4d5c8a052889bf 21704 onnxruntime_1.21.0+dfsg-1.debian.tar.xz
Files:
 3b5e44fc802ab8df6aa24c18138f138e 37970624 onnxruntime_1.21.0+dfsg.orig.tar.xz
 ea20b9b75cf229797e22ee900fe33dc1 21704 onnxruntime_1.21.0+dfsg-1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEE+Fg++qmpHzqjSzySzhGnsHs6uUYFAmfS+nEACgkQzhGnsHs6
uUYDaA/+JqlR4iZ+yRBdUPy7Wen8kpOFuBw/0lPFLMSl28epvejfL0Ps3P71jt+K
JW5/yXCPfO2XJaUld4lwkXpv/blIw8Fk2YVxi6n1vJbapoKr+WCdPDXj3onkrSlt
EsyfAPJtYAiNFRR8ZdMonBAzkyRoJ8ZYq78U3RprgxEFlDb4dhU5Ds1Z6Wv7Rx2l
blR+njKayp8touGvm/7h0Ja8cbM8tFEITqP0hqknZefkIXbEavUJBfx43FnEp4Yd
6DtAgTzoIVDYnJNXULSooVKQSmwYBhGRjK1hfdNeptJdepvySc9AhYc1m4T4C7Mx
pb9VDVdr7KwbQSUk6Lw+CxPHYH7pDuHL8uEhgZJQ0K1dDsP8QfEujl2TSXCw8345
OlBz/SIqjPIHPRSFT+QUaOQBSKxfXYu9e7YTwOg+YDQHTd9SZ1ULQQ7rwLkslc1I
4G7sTvNznUIuFPdx8VpqleP5kmf+2aqigYrwNH0IKbeACgzu23YNdCMFTcbykO8v
M73e7ywbMFrtMlziVseAxuv/a5d2Ybcqxv1JRd8dV3KGrws8FHfstjvpkATvfFx3
3/RmApu/MsGdHxmPlRU8LajyTgMnlK6a4PgVnvtHPe1v0T/Nr+gUE+955NeXUw0q
ABDdj1JDLOwRdq09rkR0Rkk/FhJ8uvjMVcpm0gRWVi2Odv+HTFU=
=GUWn
-----END PGP SIGNATURE-----
